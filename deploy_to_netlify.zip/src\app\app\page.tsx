'use client';

import React, { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useSearchParams, useRouter } from 'next/navigation';
import {
  Building2,
  GraduationCap,
  Users,
  CreditCard,
  CalendarCheck,
  ShieldCheck,
  BarChart3,
  Database,
  Plus,
  Search,
  Trash2,
  CheckCircle2,
  Clock,
  AlertTriangle,
  RefreshCw,
  LogOut,
  Layers,
  BookOpen,
  Bell,
  Settings,
  Printer,
  FileText,
  Check,
  X,
  Edit,
  UserCheck,
  MessageSquare,
  Phone,
  Mail,
  MoreVertical,
  Calendar,
  ArrowUpDown,
  Filter,
  Grid,
  List,
  ChevronLeft,
  ChevronRight,
  Eye,
  CheckSquare,
  Square,
  Download,
  Menu,
  SlidersHorizontal,
  Save
} from 'lucide-react';
import { School, Student, Teacher, ClassRoom, Notice, FeeInvoice, AttendanceRecord, SchoolOverview } from '@/lib/types';
import { DashboardOverview } from '@/components/blocks/dashboard-overview';

function ERPWorkspaceContent() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const [activeTab, setActiveTab] = useState<'overview' | 'students' | 'teachers' | 'classes' | 'attendance' | 'fees' | 'notices' | 'settings'>('overview');
  const [selectedSchool, setSelectedSchool] = useState<School | null>(null);
  const [overview, setOverview] = useState<SchoolOverview | null>(null);
  const [students, setStudents] = useState<Student[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [classes, setClasses] = useState<ClassRoom[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [invoices, setInvoices] = useState<FeeInvoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  // Modals & Active Edit States
  const [showStudentModal, setShowStudentModal] = useState(false);
  const [editingStudentId, setEditingStudentId] = useState<string | null>(null);
  const [studentModalTab, setStudentModalTab] = useState<'basic' | 'cbse_academic' | 'cbse_personal' | 'cbse_parents' | 'cbse_address'>('basic');

  const [showTeacherModal, setShowTeacherModal] = useState(false);
  const [editingTeacherId, setEditingTeacherId] = useState<string | null>(null);
  const [teacherModalTab, setTeacherModalTab] = useState<'basic' | 'cbse_credentials' | 'cbse_personal' | 'cbse_statutory'>('basic');

  const [showAddClass, setShowAddClass] = useState(false);
  const [editingClassId, setEditingClassId] = useState<string | null>(null);
  const [showAddNotice, setShowAddNotice] = useState(false);
  const [showAddInvoice, setShowAddInvoice] = useState(false);
  const [viewInvoice, setViewInvoice] = useState<FeeInvoice | null>(null);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showPromotionStudio, setShowPromotionStudio] = useState(false);
  const [promotionSourceClass, setPromotionSourceClass] = useState<string>('Class 9');
  const [promotionSourceSection, setPromotionSourceSection] = useState<string>('ALL');
  const [promotionTargetClass, setPromotionTargetClass] = useState<string>('Class 10');
  const [promotionTargetSection, setPromotionTargetSection] = useState<string>('SAME');
  const [promotionTargetSession, setPromotionTargetSession] = useState<string>('2027-28');
  const [promotionActionsMap, setPromotionActionsMap] = useState<Record<string, { action: 'PROMOTE' | 'RETAIN' | 'GRADUATE' | 'LEFT'; targetSection: string }>>({});
  const [promotionExecuting, setPromotionExecuting] = useState(false);

  // Individual Student Promotion Modal
  const [individualPromotionStudent, setIndividualPromotionStudent] = useState<Student | null>(null);
  const [individualPromotionAction, setIndividualPromotionAction] = useState<'PROMOTE' | 'RETAIN' | 'GRADUATE' | 'LEFT'>('PROMOTE');
  const [individualTargetClass, setIndividualTargetClass] = useState<string>('Class 10');
  const [individualTargetSection, setIndividualTargetSection] = useState<string>('A');
  const [individualTargetRoll, setIndividualTargetRoll] = useState<string>('');
  const [individualTargetSession, setIndividualTargetSession] = useState<string>('2027-28');
  const [settingsSuccess, setSettingsSuccess] = useState('');
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [userRole, setUserRole] = useState<'SUPERADMIN' | 'PRINCIPAL' | 'TEACHER' | 'ACCOUNTANT' | 'STUDENT'>('SUPERADMIN');
  const [showExportMenu, setShowExportMenu] = useState<'students' | 'teachers' | 'classes' | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [actionSuccessMsg, setActionSuccessMsg] = useState('');
  const [pinModal, setPinModal] = useState<{ type: 'student' | 'teacher'; id: string; name: string; currentPin: string } | null>(null);
  const [customPinInput, setCustomPinInput] = useState('123456');

  // Students List Controls & Filters
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);
  const [studentRowsPerPage, setStudentRowsPerPage] = useState<number>(10);
  const [studentPage, setStudentPage] = useState<number>(1);
  const [studentSortBy, setStudentSortBy] = useState<string>('A-Z');
  const [studentViewMode, setStudentViewMode] = useState<'list' | 'grid'>('list');
  const [studentStatusFilter, setStudentStatusFilter] = useState<'ALL' | 'ACTIVE' | 'INACTIVE'>('ALL');
  const [studentClassFilter, setStudentClassFilter] = useState<string>('ALL');
  const [studentSectionFilter, setStudentSectionFilter] = useState<string>('ALL');
  const [studentFeeFilter, setStudentFeeFilter] = useState<'ALL' | 'PAID' | 'PENDING' | 'OVERDUE'>('ALL');
  const [studentGenderFilter, setStudentGenderFilter] = useState<'ALL' | 'Male' | 'Female'>('ALL');
  const [studentHouseFilter, setStudentHouseFilter] = useState<string>('ALL');
  const [showStudentFilterMenu, setShowStudentFilterMenu] = useState(false);
  const [activeStudentMenuId, setActiveStudentMenuId] = useState<string | null>(null);

  // Teachers List Controls & Filters
  const [selectedTeacherIds, setSelectedTeacherIds] = useState<string[]>([]);
  const [teacherRowsPerPage, setTeacherRowsPerPage] = useState<number>(10);
  const [teacherPage, setTeacherPage] = useState<number>(1);
  const [teacherSortBy, setTeacherSortBy] = useState<string>('A-Z');
  const [teacherViewMode, setTeacherViewMode] = useState<'list' | 'grid'>('list');
  const [teacherStatusFilter, setTeacherStatusFilter] = useState<'ALL' | 'ACTIVE' | 'INACTIVE'>('ALL');
  const [teacherDeptFilter, setTeacherDeptFilter] = useState<string>('ALL');
  const [teacherDesignationFilter, setTeacherDesignationFilter] = useState<string>('ALL');
  const [teacherCtetFilter, setTeacherCtetFilter] = useState<'ALL' | 'YES' | 'NO'>('ALL');
  const [teacherGenderFilter, setTeacherGenderFilter] = useState<'ALL' | 'Male' | 'Female'>('ALL');
  const [showTeacherFilterMenu, setShowTeacherFilterMenu] = useState(false);
  const [activeTeacherMenuId, setActiveTeacherMenuId] = useState<string | null>(null);

  // Classes List Controls & Filters
  const [selectedClassIds, setSelectedClassIds] = useState<string[]>([]);
  const [classRowsPerPage, setClassRowsPerPage] = useState<number>(10);
  const [classPage, setClassPage] = useState<number>(1);
  const [classSortBy, setClassSortBy] = useState<string>('A-Z');
  const [classStatusFilter, setClassStatusFilter] = useState<'ALL' | 'ACTIVE' | 'INACTIVE'>('ALL');
  const [classWingFilter, setClassWingFilter] = useState<string>('ALL');
  const [classSectionFilter, setClassSectionFilter] = useState<string>('ALL');
  const [showClassFilterMenu, setShowClassFilterMenu] = useState(false);
  const [activeClassMenuId, setActiveClassMenuId] = useState<string | null>(null);

  // Fee Invoices Controls & Filters
  const [feeStatusFilter, setFeeStatusFilter] = useState<'ALL' | 'PAID' | 'PENDING' | 'OVERDUE'>('ALL');
  const [feeClassFilter, setFeeClassFilter] = useState<string>('ALL');
  const [feePaymentModeFilter, setFeePaymentModeFilter] = useState<string>('ALL');
  const [feeRowsPerPage, setFeeRowsPerPage] = useState<number>(10);
  const [feePage, setFeePage] = useState<number>(1);
  const [feeSortBy, setFeeSortBy] = useState<'Date-Desc' | 'Date-Asc' | 'Amount-Desc' | 'Amount-Asc'>('Date-Desc');
  const [showFeeFilterMenu, setShowFeeFilterMenu] = useState(false);

  // Attendance Controls, Interactive Rosters & Filters
  const [attendanceMode, setAttendanceMode] = useState<'students' | 'faculty' | 'logs'>('students');
  const [selectedAttendanceClass, setSelectedAttendanceClass] = useState<string>('Class 10');
  const [selectedAttendanceSection, setSelectedAttendanceSection] = useState<string>('A');
  const [selectedAttendanceDate, setSelectedAttendanceDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [studentAttendanceMap, setStudentAttendanceMap] = useState<Record<string, 'PRESENT' | 'ABSENT' | 'LATE' | 'HALF_DAY'>>({});
  const [facultyAttendanceMap, setFacultyAttendanceMap] = useState<Record<string, 'PRESENT' | 'LEAVE' | 'HALF_DAY' | 'ABSENT'>>({});
  const [attendanceFacultyDeptFilter, setAttendanceFacultyDeptFilter] = useState<string>('ALL');
  const [attendanceSaving, setAttendanceSaving] = useState(false);
  const [attendanceClassFilter, setAttendanceClassFilter] = useState<string>('ALL');
  const [attendanceDateFilter, setAttendanceDateFilter] = useState<string>('');

  // MongoDB Cloud Sync & Diagnostic State
  const [mongoSyncLoading, setMongoSyncLoading] = useState(false);
  const [mongoSyncData, setMongoSyncData] = useState<any>(null);
  const [mongoSyncMsg, setMongoSyncMsg] = useState('');

  // Notices Controls & Filters
  const [noticeAudienceFilter, setNoticeAudienceFilter] = useState<'ALL' | 'TEACHERS' | 'STUDENTS' | 'PARENTS'>('ALL');

  // Clean time-based greeting without emojis
  const getISTGreeting = () => {
    const now = new Date();
    const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
    const istTime = new Date(utc + (3600000 * 5.5));
    const hour = istTime.getHours();

    if (hour >= 4 && hour < 12) {
      return 'Good Morning';
    } else if (hour >= 12 && hour < 17) {
      return 'Good Afternoon';
    } else if (hour >= 17 && hour < 21) {
      return 'Good Evening';
    } else {
      return 'Good Night';
    }
  };

  // User Profile Form State
  const [profileForm, setProfileForm] = useState({
    full_name: '',
    username: '',
    admin_pin: '',
    email: '',
    phone: ''
  });

  // Comprehensive CBSE Student Form (Basic fields required, CBSE fields optional)
  const initialStudentForm: Partial<Student> = {
    full_name: '',
    admission_no: '',
    class_name: 'Class 10',
    section: 'A',
    roll_no: '',
    gender: 'Male',
    guardian_name: '',
    guardian_phone: '',
    fee_status: 'PENDING',
    passcode: '123456',
    dob: '',
    blood_group: 'O+',
    aadhaar_no: '',
    apaar_id: '',
    house: 'Red House',
    nationality: 'Indian',
    religion: 'Hindu',
    category: 'GENERAL',
    mother_tongue: 'Hindi',
    single_girl_child: 'NO',
    cwsn_status: 'NO',
    admission_date: new Date().toISOString().split('T')[0],
    medium_of_instruction: 'ENGLISH',
    previous_school: '',
    previous_class: '',
    transfer_certificate_no: '',
    father_name: '',
    father_qualification: '',
    father_occupation: '',
    father_income: '',
    father_phone: '',
    father_aadhaar: '',
    mother_name: '',
    mother_qualification: '',
    mother_occupation: '',
    mother_income: '',
    mother_phone: '',
    mother_aadhaar: '',
    residential_address: '',
    permanent_address: '',
    city: '',
    state: '',
    pincode: '',
    transport_opted: 'NO',
    bus_route_no: '',
    pickup_point: '',
    emergency_contact_name: '',
    emergency_contact_phone: '',
    medical_conditions: ''
  };
  const [studentForm, setStudentForm] = useState<Partial<Student>>(initialStudentForm);

  // CBSE Standard Options Constants
  const STANDARD_DESIGNATIONS = [
    'PGT - Post Graduate Teacher (Classes XI-XII)',
    'TGT - Trained Graduate Teacher (Classes VI-X)',
    'PRT - Primary Teacher (Classes I-V)',
    'NTT - Nursery / Kindergarten Teacher',
    'Principal / Head of School',
    'Vice-Principal / Academic Coordinator',
    'Special Educator (Mandatory CBSE Norm)',
    'School Counselor & Wellness Teacher (Mandatory)',
    'PET - Physical Education Teacher / Sports Master',
    'Librarian / Head of Library',
    'Computer / IT & AI Faculty',
    'Art & Craft Teacher',
    'Music & Performing Arts Teacher',
    'Lab Assistant / Science Technician',
    'Administrative Officer / Accounts Head'
  ];

  const STANDARD_QUALIFICATIONS = [
    'Post Graduate (M.A / M.Sc / M.Com) + B.Ed (CBSE PGT Norm)',
    'Graduate (B.A / B.Sc / B.Com) + B.Ed (CBSE TGT Norm)',
    'D.El.Ed / JBT / BTC / B.El.Ed (CBSE PRT Norm)',
    'M.Ed / Master of Education',
    'B.Ed / Bachelor of Education',
    'B.P.Ed / M.P.Ed (Physical Education Norm)',
    'B.Lib / M.Lib (Library Science Norm)',
    'B.Tech / B.E / MCA / M.Sc CS/IT (Computer Norm)',
    'RCI Recognized Degree / Diploma in Special Ed (Special Educator Norm)',
    'NTT / Early Childhood Care Education - ECCE (Pre-Primary Norm)',
    'Ph.D / Doctorate in Subject / Education',
    'MBA / M.Com / B.Com / CA Inter (Administrative / Accounts)'
  ];

  const STANDARD_DEPARTMENTS = [
    'Mathematics & Applied Mathematics',
    'Science (Physics / Chemistry / Biology)',
    'English Language & Literature',
    'Hindi & Sanskrit (Indian Languages)',
    'Social Sciences (History / Geography / Civics / Economics)',
    'Computer Science & Artificial Intelligence / IT',
    'Commerce, Accountancy & Business Studies',
    'Physical Education, Yoga & Sports',
    'Fine Arts, Performing Arts & Music',
    'Special Education & Inclusive Learning',
    'Pre-Primary & Foundational Learning (ECCE)',
    'School Administration, Accounts & Operations'
  ];

  const STANDARD_SUBJECTS = [
    'Mathematics / Applied Mathematics',
    'Physics',
    'Chemistry',
    'Biology / Life Sciences',
    'Computer Science / Information Technology / AI',
    'English Core & Literature',
    'Hindi Core & Sahitya',
    'Sanskrit',
    'Social Studies / History / Pol Science / Geography',
    'Accountancy & Business Studies',
    'Economics',
    'Physical Education & Sports',
    'Psychology & Child Development',
    'Fine Arts & Commercial Art',
    'Music (Vocal / Instrumental)',
    'Environmental Studies (EVS) & General Science',
    'General Pre-Primary Subjects (All in One)',
    'General Administration & Office Operations'
  ];

  // Comprehensive CBSE Teacher / Staff Form (Basic fields required, CBSE fields optional)
  const initialTeacherForm: Partial<Teacher> = {
    full_name: '',
    staff_code: '',
    department: 'Mathematics & Applied Mathematics',
    designation: 'TGT - Trained Graduate Teacher (Classes VI-X)',
    phone: '',
    email: '',
    teacher_type: 'TGT',
    subject_specialization: 'Mathematics / Applied Mathematics',
    classes_taught: 'Classes 9 & 10 (Secondary Stage - TGT)',
    ctet_qualified: 'YES',
    ctet_roll_no: '',
    professional_degree: 'Graduate (B.A / B.Sc / B.Com) + B.Ed (CBSE TGT Norm)',
    experience_years: 5,
    date_of_joining: new Date().toISOString().split('T')[0],
    employment_type: 'PERMANENT',
    dob: '',
    gender: 'Female',
    blood_group: 'B+',
    aadhaar_no: '',
    pan_no: '',
    father_or_spouse_name: '',
    epf_uan_no: '',
    bank_name: 'State Bank of India',
    bank_account_no: '',
    bank_ifsc: '',
    basic_pay: 45000,
    address: '',
    city: '',
    pincode: '',
    emergency_contact_phone: '',
    passcode: '123456'
  };
  const [teacherForm, setTeacherForm] = useState<Partial<Teacher>>(initialTeacherForm);
  const [isCustomRole, setIsCustomRole] = useState(false);
  const [customRoleText, setCustomRoleText] = useState('');
  const [isCustomQual, setIsCustomQual] = useState(false);
  const [customQualText, setCustomQualText] = useState('');
  const [isCustomDept, setIsCustomDept] = useState(false);
  const [customDeptText, setCustomDeptText] = useState('');
  const [isCustomSubject, setIsCustomSubject] = useState(false);
  const [customSubjectText, setCustomSubjectText] = useState('');

  // Class Form
  const [classForm, setClassForm] = useState({
    class_name: 'Class 10',
    section: 'A',
    class_teacher: '',
    room_no: 'Room 101',
    capacity: 40
  });

  // Notice Form
  const [noticeForm, setNoticeForm] = useState({
    title: '',
    content: '',
    target_audience: 'ALL' as 'ALL' | 'TEACHERS' | 'STUDENTS' | 'PARENTS',
    posted_by: 'Principal Office'
  });

  // Invoice Form
  const [invoiceForm, setInvoiceForm] = useState({
    student_id: '',
    student_name: '',
    admission_no: '',
    class_name: 'Class 10 - A',
    tuition_fee: 12000,
    transport_fee: 2000,
    exam_fee: 1000,
    amount: 15000,
    payment_mode: 'UPI / Online',
    due_date: new Date().toISOString().split('T')[0],
    status: 'PENDING' as 'PAID' | 'PENDING' | 'OVERDUE'
  });

  // Settings Form
  const [settingsForm, setSettingsForm] = useState({
    school_name: '',
    principal_name: '',
    board: 'CBSE',
    city: '',
    admin_pin: ''
  });

  useEffect(() => {
    fetchAuthenticatedSchool();
  }, [searchParams]);

  const fetchAuthenticatedSchool = async () => {
    setLoading(true);
    try {
      const schoolParam = searchParams.get('school');
      let targetSchool: School | null = null;

      if (typeof window !== 'undefined') {
        const storedUser = localStorage.getItem('current_user');
        if (storedUser) {
          try {
            setCurrentUser(JSON.parse(storedUser));
          } catch (e) {}
        }
        const stored = localStorage.getItem('current_school');
        if (stored) {
          try {
            let parsed = JSON.parse(stored);
            if (parsed.school_code === 'DPS-2026' || parsed.id === 'DPS-2026') {
              parsed.school_code = 'DPS2026';
              parsed.id = 'DPS2026';
              localStorage.setItem('current_school', JSON.stringify(parsed));
            }
            if (!schoolParam || parsed.school_code === schoolParam || parsed.id === schoolParam || parsed.school_code?.replace(/[^A-Z0-9]/gi, '') === schoolParam?.replace(/[^A-Z0-9]/gi, '')) {
              targetSchool = parsed;
            }
          } catch (e) {}
        }
      }

      if (!targetSchool || (schoolParam && targetSchool.school_code?.replace(/[^A-Z0-9]/gi, '') !== schoolParam?.replace(/[^A-Z0-9]/gi, ''))) {
        const res = await fetch('/api/schools');
        const data = await res.json();
        if (data.success && data.schools.length > 0) {
          if (schoolParam) {
            const cleanParam = schoolParam.replace(/[^A-Z0-9]/gi, '').toUpperCase();
            targetSchool = data.schools.find((s: School) => 
              s.school_code?.replace(/[^A-Z0-9]/gi, '').toUpperCase() === cleanParam || 
              s.id?.replace(/[^A-Z0-9]/gi, '').toUpperCase() === cleanParam
            ) || data.schools[0];
          } else {
            targetSchool = data.schools[0];
          }
        }
      }

      if (targetSchool) {
        setSelectedSchool(targetSchool);
        setSettingsForm({
          school_name: targetSchool.school_name,
          principal_name: targetSchool.principal_name || '',
          board: targetSchool.board || 'CBSE',
          city: targetSchool.city || '',
          admin_pin: targetSchool.admin_pin || '123456'
        });
        setProfileForm({
          full_name: targetSchool.principal_name || targetSchool.admin_name || 'Administrator',
          username: targetSchool.admin_id || 'admin',
          admin_pin: targetSchool.admin_pin || '123456',
          email: `admin@${(targetSchool.school_code || 'dps2026').toLowerCase()}.edu`,
          phone: ''
        });
        if (typeof window !== 'undefined') {
          localStorage.setItem('current_school', JSON.stringify(targetSchool));
        }
        loadSchoolData(targetSchool.school_code || targetSchool.id || 'DPS2026');
      } else {
        router.push('/login');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSchool) return;
    try {
      const res = await fetch('/api/school/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          school_id: selectedSchool.id,
          principal_name: profileForm.full_name,
          admin_name: profileForm.full_name,
          admin_id: profileForm.username,
          admin_pin: profileForm.admin_pin
        })
      });
      const data = await res.json();
      if (data.success) {
        const updatedUser = {
          ...(currentUser || {}),
          full_name: profileForm.full_name,
          username: profileForm.username,
          email: profileForm.email,
          phone: profileForm.phone
        };
        setCurrentUser(updatedUser);
        setSelectedSchool(data.school);
        if (typeof window !== 'undefined') {
          localStorage.setItem('current_user', JSON.stringify(updatedUser));
          localStorage.setItem('current_school', JSON.stringify(data.school));
        }
        setShowProfileModal(false);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const loadSchoolData = async (schoolId: string) => {
    const cleanId = (schoolId || '').replace(/[^A-Z0-9]/gi, '') || 'DPS2026';
    setLoading(true);
    try {
      const [ovRes, stRes, tcRes, clRes, noRes, atRes, inRes] = await Promise.all([
        fetch(`/api/overview?school_id=${cleanId}`),
        fetch(`/api/students?school_id=${cleanId}`),
        fetch(`/api/teachers?school_id=${cleanId}`),
        fetch(`/api/classes?school_id=${cleanId}`),
        fetch(`/api/notices?school_id=${cleanId}`),
        fetch(`/api/attendance?school_id=${cleanId}`),
        fetch(`/api/fees?school_id=${cleanId}`)
      ]);

      const [ovData, stData, tcData, clData, noData, atData, inData] = await Promise.all([
        ovRes.json(),
        stRes.json(),
        tcRes.json(),
        clRes.json(),
        noRes.json(),
        atRes.json(),
        inRes.json()
      ]);

      if (ovData.success) setOverview(ovData.overview);
      if (stData.success) setStudents(stData.students || []);
      if (tcData.success) setTeachers(tcData.teachers || []);
      if (clData.success) setClasses(clData.classes || []);
      if (noData.success) setNotices(noData.notices || []);
      if (atData.success) setAttendance(atData.attendance || []);
      if (inData.success) setInvoices(inData.invoices || []);
    } catch (e) {
      console.error('Failed to load school data:', e);
    } finally {
      setLoading(false);
    }
  };

  // Student Actions: Add or Edit CBSE Profile
  const handleSaveStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSchool) return;
    try {
      const isEditing = !!editingStudentId;
      const url = '/api/students';
      const method = isEditing ? 'PATCH' : 'POST';
      const payload = isEditing
        ? { id: editingStudentId, school_id: selectedSchool.id, ...studentForm }
        : { school_id: selectedSchool.id, ...studentForm };

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        setShowStudentModal(false);
        setEditingStudentId(null);
        setStudentForm(initialStudentForm);
        loadSchoolData(selectedSchool.id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const openStudentModal = (studentToEdit?: Student) => {
    if (studentToEdit) {
      setEditingStudentId(studentToEdit.id);
      setStudentForm({
        ...initialStudentForm,
        ...studentToEdit,
        passcode: studentToEdit.passcode || '123456'
      });
    } else {
      setEditingStudentId(null);
      setStudentForm({
        ...initialStudentForm,
        admission_no: `ADM-${Date.now().toString().slice(-4)}`,
        passcode: '123456'
      });
    }
    setStudentModalTab('basic');
    setShowStudentModal(true);
  };

  const showAdminToast = (msg: string) => {
    setActionSuccessMsg(msg);
    setTimeout(() => setActionSuccessMsg(''), 4000);
  };

  const handleDeleteStudent = async (id: string) => {
    if (!confirm('Are you sure you want to delete this student record?')) return;
    try {
      await fetch(`/api/students?id=${id}`, { method: 'DELETE' });
      showAdminToast('Student record deleted successfully.');
      if (selectedSchool) loadSchoolData(selectedSchool.id);
    } catch (e) {
      console.error(e);
    }
  };

  // Student Admin Powers: 1-Click Toggle Active/Inactive & Bulk
  const handleToggleStudentStatus = async (student: Student, targetStatus?: 'ACTIVE' | 'INACTIVE') => {
    const nextStatus = targetStatus || (student.status === 'INACTIVE' ? 'ACTIVE' : 'INACTIVE');
    try {
      const res = await fetch('/api/students', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: student.id, status: nextStatus })
      });
      const data = await res.json();
      if (data.success && selectedSchool) {
        showAdminToast(`Student "${student.full_name}" is now ${nextStatus}!`);
        loadSchoolData(selectedSchool.id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleBulkStudentStatus = async (targetStatus: 'ACTIVE' | 'INACTIVE') => {
    if (selectedStudentIds.length === 0 || !selectedSchool) return;
    try {
      await Promise.all(
        selectedStudentIds.map(id =>
          fetch('/api/students', {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, status: targetStatus })
          })
        )
      );
      showAdminToast(`Updated ${selectedStudentIds.length} students to ${targetStatus}!`);
      setSelectedStudentIds([]);
      loadSchoolData(selectedSchool.id);
    } catch (e) {
      console.error(e);
    }
  };

  const handleBulkDeleteStudents = async () => {
    if (selectedStudentIds.length === 0 || !selectedSchool) return;
    if (!confirm(`Are you sure you want to permanently delete ${selectedStudentIds.length} selected students?`)) return;
    try {
      await Promise.all(
        selectedStudentIds.map(id =>
          fetch(`/api/students?id=${id}`, { method: 'DELETE' })
        )
      );
      showAdminToast(`Successfully deleted ${selectedStudentIds.length} student records.`);
      setSelectedStudentIds([]);
      loadSchoolData(selectedSchool.id);
    } catch (e) {
      console.error(e);
    }
  };

  // PIN / Passcode Reset Powers
  const handleOpenPinModal = (type: 'student' | 'teacher', id: string, name: string, currentPin = '123456') => {
    setPinModal({ type, id, name, currentPin });
    setCustomPinInput(currentPin);
  };

  const handleSaveCustomPin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pinModal || !selectedSchool) return;
    try {
      const url = pinModal.type === 'student' ? '/api/students' : '/api/teachers';
      const res = await fetch(url, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: pinModal.id, passcode: customPinInput })
      });
      const data = await res.json();
      if (data.success) {
        showAdminToast(`Login PIN for ${pinModal.name} updated to "${customPinInput}"!`);
        setPinModal(null);
        loadSchoolData(selectedSchool.id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Teacher Actions: Add or Edit CBSE Staff Profile
  const handleSaveTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSchool) return;
    try {
      const isEditing = !!editingTeacherId;
      const url = '/api/teachers';
      const method = isEditing ? 'PATCH' : 'POST';
      const payload = isEditing
        ? { id: editingTeacherId, school_id: selectedSchool.id, ...teacherForm }
        : { school_id: selectedSchool.id, ...teacherForm };

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        setShowTeacherModal(false);
        setEditingTeacherId(null);
        setTeacherForm(initialTeacherForm);
        showAdminToast(isEditing ? 'Faculty profile updated.' : 'New faculty member registered.');
        loadSchoolData(selectedSchool.id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Faculty Admin Powers: 1-Click Toggle Active/Inactive & Bulk
  const handleToggleTeacherStatus = async (teacher: Teacher, targetStatus?: 'ACTIVE' | 'INACTIVE') => {
    const nextStatus = targetStatus || (teacher.status === 'INACTIVE' ? 'ACTIVE' : 'INACTIVE');
    try {
      const res = await fetch('/api/teachers', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: teacher.id, status: nextStatus })
      });
      const data = await res.json();
      if (data.success && selectedSchool) {
        showAdminToast(`Faculty "${teacher.full_name}" is now ${nextStatus}!`);
        loadSchoolData(selectedSchool.id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleBulkTeacherStatus = async (targetStatus: 'ACTIVE' | 'INACTIVE') => {
    if (selectedTeacherIds.length === 0 || !selectedSchool) return;
    try {
      await Promise.all(
        selectedTeacherIds.map(id =>
          fetch('/api/teachers', {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, status: targetStatus })
          })
        )
      );
      showAdminToast(`Updated ${selectedTeacherIds.length} faculty members to ${targetStatus}!`);
      setSelectedTeacherIds([]);
      loadSchoolData(selectedSchool.id);
    } catch (e) {
      console.error(e);
    }
  };

  const handleBulkDeleteTeachers = async () => {
    if (selectedTeacherIds.length === 0 || !selectedSchool) return;
    if (!confirm(`Are you sure you want to delete ${selectedTeacherIds.length} selected faculty records?`)) return;
    try {
      await Promise.all(
        selectedTeacherIds.map(id =>
          fetch(`/api/teachers?id=${id}`, { method: 'DELETE' })
        )
      );
      showAdminToast(`Deleted ${selectedTeacherIds.length} faculty records.`);
      setSelectedTeacherIds([]);
      loadSchoolData(selectedSchool.id);
    } catch (e) {
      console.error(e);
    }
  };

  const openTeacherModal = (teacherToEdit?: Teacher) => {
    if (teacherToEdit) {
      setEditingTeacherId(teacherToEdit.id);
      setTeacherForm({ ...initialTeacherForm, ...teacherToEdit });

      const roleIsCustom = !!teacherToEdit.designation && !STANDARD_DESIGNATIONS.includes(teacherToEdit.designation);
      setIsCustomRole(roleIsCustom);
      setCustomRoleText(roleIsCustom ? teacherToEdit.designation : '');

      const qualIsCustom = !!teacherToEdit.professional_degree && !STANDARD_QUALIFICATIONS.includes(teacherToEdit.professional_degree);
      setIsCustomQual(qualIsCustom);
      setCustomQualText(qualIsCustom ? teacherToEdit.professional_degree : '');

      const deptIsCustom = !!teacherToEdit.department && !STANDARD_DEPARTMENTS.includes(teacherToEdit.department);
      setIsCustomDept(deptIsCustom);
      setCustomDeptText(deptIsCustom ? teacherToEdit.department : '');

      const subjIsCustom = !!teacherToEdit.subject_specialization && !STANDARD_SUBJECTS.includes(teacherToEdit.subject_specialization);
      setIsCustomSubject(subjIsCustom);
      setCustomSubjectText(subjIsCustom ? teacherToEdit.subject_specialization : '');
    } else {
      setEditingTeacherId(null);
      setTeacherForm({
        ...initialTeacherForm,
        staff_code: `STF-${Date.now().toString().slice(-4)}`
      });
      setIsCustomRole(false);
      setCustomRoleText('');
      setIsCustomQual(false);
      setCustomQualText('');
      setIsCustomDept(false);
      setCustomDeptText('');
      setIsCustomSubject(false);
      setCustomSubjectText('');
    }
    setTeacherModalTab('basic');
    setShowTeacherModal(true);
  };

  const handleDeleteTeacher = async (id: string) => {
    if (!confirm('Are you sure you want to remove this faculty record?')) return;
    try {
      await fetch(`/api/teachers?id=${id}`, { method: 'DELETE' });
      if (selectedSchool) loadSchoolData(selectedSchool.id);
    } catch (e) {
      console.error(e);
    }
  };

  // Class Handlers
  const handleAddClass = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSchool) return;
    try {
      const url = '/api/classes';
      const method = editingClassId ? 'PUT' : 'POST';
      const payload = editingClassId 
        ? { id: editingClassId, ...classForm } 
        : { school_id: selectedSchool.id, ...classForm };

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        setShowAddClass(false);
        setEditingClassId(null);
        setClassForm({ class_name: 'Class 10', section: 'A', class_teacher: '', room_no: 'Room 101', capacity: 40 });
        loadSchoolData(selectedSchool.id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteClass = async (id: string) => {
    if (!confirm('Are you sure you want to delete this class & section?')) return;
    try {
      await fetch(`/api/classes?id=${id}`, { method: 'DELETE' });
      showAdminToast('Class & division deleted successfully.');
      if (selectedSchool) loadSchoolData(selectedSchool.id);
    } catch (e) {
      console.error(e);
    }
  };

  // Class Admin Powers: 1-Click Toggle Active/Inactive & Bulk
  const handleToggleClassStatus = async (cls: ClassRoom, targetStatus?: 'ACTIVE' | 'INACTIVE') => {
    const nextStatus = targetStatus || (cls.status === 'INACTIVE' ? 'ACTIVE' : 'INACTIVE');
    try {
      const res = await fetch('/api/classes', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: cls.id, status: nextStatus })
      });
      const data = await res.json();
      if (data.success && selectedSchool) {
        showAdminToast(`Class "${cls.class_name} - ${cls.section}" is now ${nextStatus}!`);
        loadSchoolData(selectedSchool.id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleBulkClassStatus = async (targetStatus: 'ACTIVE' | 'INACTIVE') => {
    if (selectedClassIds.length === 0 || !selectedSchool) return;
    try {
      await Promise.all(
        selectedClassIds.map(id =>
          fetch('/api/classes', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, status: targetStatus })
          })
        )
      );
      showAdminToast(`Updated ${selectedClassIds.length} classes to ${targetStatus}!`);
      setSelectedClassIds([]);
      loadSchoolData(selectedSchool.id);
    } catch (e) {
      console.error(e);
    }
  };

  const handleBulkDeleteClasses = async () => {
    if (selectedClassIds.length === 0 || !selectedSchool) return;
    if (!confirm(`Are you sure you want to delete ${selectedClassIds.length} selected classes?`)) return;
    try {
      await Promise.all(
        selectedClassIds.map(id =>
          fetch(`/api/classes?id=${id}`, { method: 'DELETE' })
        )
      );
      showAdminToast(`Deleted ${selectedClassIds.length} classes.`);
      setSelectedClassIds([]);
      loadSchoolData(selectedSchool.id);
    } catch (e) {
      console.error(e);
    }
  };

  // Notice Handlers
  const handleAddNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSchool) return;
    try {
      const res = await fetch('/api/notices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ school_id: selectedSchool.id, ...noticeForm })
      });
      const data = await res.json();
      if (data.success) {
        setShowAddNotice(false);
        setNoticeForm({ title: '', content: '', target_audience: 'ALL', posted_by: 'Principal Office' });
        loadSchoolData(selectedSchool.id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteNotice = async (id: string) => {
    if (!confirm('Are you sure you want to delete this notice?')) return;
    try {
      await fetch(`/api/notices?id=${id}`, { method: 'DELETE' });
      if (selectedSchool) loadSchoolData(selectedSchool.id);
    } catch (e) {
      console.error(e);
    }
  };

  // Invoice Handlers
  const handleAddInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSchool) return;
    const totalCalc = Number(invoiceForm.tuition_fee || 0) + Number(invoiceForm.transport_fee || 0) + Number(invoiceForm.exam_fee || 0);
    try {
      const res = await fetch('/api/fees', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          school_id: selectedSchool.id,
          student_name: invoiceForm.student_name,
          admission_no: invoiceForm.admission_no,
          class_name: invoiceForm.class_name,
          tuition_fee: Number(invoiceForm.tuition_fee),
          transport_fee: Number(invoiceForm.transport_fee),
          exam_fee: Number(invoiceForm.exam_fee),
          amount: totalCalc > 0 ? totalCalc : Number(invoiceForm.amount),
          payment_mode: invoiceForm.payment_mode,
          due_date: invoiceForm.due_date,
          status: invoiceForm.status
        })
      });
      const data = await res.json();
      if (data.success) {
        setShowAddInvoice(false);
        setInvoiceForm({
          student_id: '',
          student_name: '',
          admission_no: '',
          class_name: 'Class 10 - A',
          tuition_fee: 12000,
          transport_fee: 2000,
          exam_fee: 1000,
          amount: 15000,
          payment_mode: 'UPI / Online',
          due_date: new Date().toISOString().split('T')[0],
          status: 'PENDING'
        });
        loadSchoolData(selectedSchool.id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleInvoiceStatus = async (invoice: FeeInvoice) => {
    const nextStatus = invoice.status === 'PAID' ? 'PENDING' : 'PAID';
    try {
      const res = await fetch('/api/fees', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          invoice_id: invoice.id,
          status: nextStatus,
          payment_mode: invoice.payment_mode || 'Cash/UPI'
        })
      });
      const data = await res.json();
      if (data.success && selectedSchool) {
        loadSchoolData(selectedSchool.id);
        if (viewInvoice && viewInvoice.id === invoice.id) {
          setViewInvoice(data.invoice);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteInvoice = async (id: string) => {
    if (!confirm('Are you sure you want to delete this invoice?')) return;
    try {
      await fetch(`/api/fees?id=${id}`, { method: 'DELETE' });
      if (selectedSchool) loadSchoolData(selectedSchool.id);
    } catch (e) {
      console.error(e);
    }
  };

  // Interactive Attendance Handlers (Students & Faculty)
  const handleToggleStudentAttendanceStatus = (studentId: string, status: 'PRESENT' | 'ABSENT' | 'LATE' | 'HALF_DAY') => {
    setStudentAttendanceMap(prev => ({
      ...prev,
      [studentId]: status
    }));
  };

  const handleMarkAllClassStudents = (targetStatus: 'PRESENT' | 'ABSENT' | 'LATE' | 'HALF_DAY') => {
    const targetStudents = students.filter(s => {
      const clsMatch = s.class_name?.toLowerCase().replace(/^class\s*/i, '').trim() === selectedAttendanceClass.toLowerCase().replace(/^class\s*/i, '').trim() || s.class_name?.toLowerCase() === selectedAttendanceClass.toLowerCase();
      const secMatch = (s.section || 'A').toUpperCase() === selectedAttendanceSection.toUpperCase();
      return clsMatch && secMatch;
    });

    const newMap = { ...studentAttendanceMap };
    targetStudents.forEach(s => {
      newMap[s.id] = targetStatus;
    });
    setStudentAttendanceMap(newMap);
    showAdminToast(`Marked all ${targetStudents.length} students in ${selectedAttendanceClass}-${selectedAttendanceSection} as ${targetStatus}!`);
  };

  const handleSaveClassAttendance = async () => {
    if (!selectedSchool) return;
    const targetStudents = students.filter(s => {
      const clsMatch = s.class_name?.toLowerCase().replace(/^class\s*/i, '').trim() === selectedAttendanceClass.toLowerCase().replace(/^class\s*/i, '').trim() || s.class_name?.toLowerCase() === selectedAttendanceClass.toLowerCase();
      const secMatch = (s.section || 'A').toUpperCase() === selectedAttendanceSection.toUpperCase();
      return clsMatch && secMatch;
    });

    if (targetStudents.length === 0) {
      alert(`No students found enrolled in ${selectedAttendanceClass} - Section ${selectedAttendanceSection}`);
      return;
    }

    setAttendanceSaving(true);
    try {
      let presentCount = 0;
      let absentCount = 0;

      targetStudents.forEach(s => {
        const st = studentAttendanceMap[s.id] || 'PRESENT';
        if (st === 'PRESENT' || st === 'LATE' || st === 'HALF_DAY') {
          presentCount++;
        } else {
          absentCount++;
        }
      });

      const res = await fetch('/api/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          school_id: selectedSchool.id,
          date: selectedAttendanceDate,
          class_name: selectedAttendanceClass,
          section: selectedAttendanceSection,
          total_students: targetStudents.length,
          present_count: presentCount,
          absent_count: absentCount,
          marked_by: currentUser?.full_name || 'Admin Directorate'
        })
      });

      const data = await res.json();
      if (data.success) {
        showAdminToast(`Saved ${selectedAttendanceClass}-${selectedAttendanceSection} Attendance: ${presentCount} Present, ${absentCount} Absent!`);
        loadSchoolData(selectedSchool.id);
      }
    } catch (e) {
      console.error(e);
      alert('Failed to save attendance ledger session.');
    } finally {
      setAttendanceSaving(false);
    }
  };

  const handleToggleFacultyAttendanceStatus = (teacherId: string, status: 'PRESENT' | 'LEAVE' | 'HALF_DAY' | 'ABSENT') => {
    setFacultyAttendanceMap(prev => ({
      ...prev,
      [teacherId]: status
    }));
  };

  const handleMarkAllFaculty = (targetStatus: 'PRESENT' | 'LEAVE' | 'HALF_DAY' | 'ABSENT') => {
    const activeFaculty = teachers.filter(t => t.status !== 'INACTIVE');
    const newMap = { ...facultyAttendanceMap };
    activeFaculty.forEach(t => {
      newMap[t.id] = targetStatus;
    });
    setFacultyAttendanceMap(newMap);
    showAdminToast(`Marked all ${activeFaculty.length} faculty members as ${targetStatus}!`);
  };

  const handleSaveFacultyAttendance = async () => {
    if (!selectedSchool) return;
    const activeFaculty = teachers.filter(t => t.status !== 'INACTIVE');
    if (activeFaculty.length === 0) {
      alert('No active faculty members available in roster.');
      return;
    }

    setAttendanceSaving(true);
    try {
      let presentCount = 0;
      let absentCount = 0;

      activeFaculty.forEach(t => {
        const st = facultyAttendanceMap[t.id] || 'PRESENT';
        if (st === 'PRESENT' || st === 'HALF_DAY') {
          presentCount++;
        } else {
          absentCount++;
        }
      });

      const res = await fetch('/api/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          school_id: selectedSchool.id,
          date: selectedAttendanceDate,
          class_name: 'Faculty & Staff Roster',
          section: 'All Depts',
          total_students: activeFaculty.length,
          present_count: presentCount,
          absent_count: absentCount,
          marked_by: currentUser?.full_name || 'Principal Office'
        })
      });

      const data = await res.json();
      if (data.success) {
        showAdminToast(`Faculty Daily Attendance Synced: ${presentCount} On Duty, ${absentCount} On Leave/Absent!`);
        loadSchoolData(selectedSchool.id);
      }
    } catch (e) {
      console.error(e);
      alert('Failed to save faculty attendance.');
    } finally {
      setAttendanceSaving(false);
    }
  };

  const handleDeleteAttendanceLog = async (id: string) => {
    if (!confirm('Are you sure you want to delete this attendance session record?')) return;
    try {
      const res = await fetch(`/api/attendance?id=${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success && selectedSchool) {
        showAdminToast('Attendance log removed from database!');
        loadSchoolData(selectedSchool.id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Settings Update
  const handleUpdateSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSchool) return;
    setSettingsSuccess('');
    try {
      const res = await fetch('/api/school/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ school_id: selectedSchool.id, ...settingsForm })
      });
      const data = await res.json();
      if (data.success) {
        setSelectedSchool(data.school);
        if (typeof window !== 'undefined') {
          localStorage.setItem('current_school', JSON.stringify(data.school));
        }
        setSettingsSuccess('Institutional settings and security PIN updated successfully!');
        setTimeout(() => setSettingsSuccess(''), 3000);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // MongoDB Cloud Sync Handlers
  const handleCheckMongoCloud = async () => {
    setMongoSyncLoading(true);
    setMongoSyncMsg('');
    try {
      const res = await fetch('/api/sync/mongodb');
      const data = await res.json();
      setMongoSyncData(data);
      if (data.mongoStatus?.connected) {
        showAdminToast('MongoDB Atlas Cloud is Connected & Ready!');
      } else {
        setMongoSyncMsg(data.mongoStatus?.error || 'MongoDB Atlas connection could not be established.');
      }
    } catch (e: any) {
      setMongoSyncMsg(e.message);
    } finally {
      setMongoSyncLoading(false);
    }
  };

  const handlePushAllToMongo = async () => {
    setMongoSyncLoading(true);
    setMongoSyncMsg('');
    try {
      const res = await fetch('/api/sync/mongodb', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        showAdminToast(data.message || 'All records successfully synchronized to MongoDB Atlas!');
        handleCheckMongoCloud();
      } else {
        setMongoSyncMsg(data.error || 'Failed to sync with MongoDB Atlas.');
      }
    } catch (e: any) {
      setMongoSyncMsg(e.message);
    } finally {
      setMongoSyncLoading(false);
    }
  };

  const NEXT_CLASS_MAP: Record<string, string> = {
    'Nursery': 'LKG',
    'LKG': 'UKG',
    'UKG': 'Class 1',
    'Class 1': 'Class 2',
    'Class 2': 'Class 3',
    'Class 3': 'Class 4',
    'Class 4': 'Class 5',
    'Class 5': 'Class 6',
    'Class 6': 'Class 7',
    'Class 7': 'Class 8',
    'Class 8': 'Class 9',
    'Class 9': 'Class 10',
    'Class 10': 'Class 11',
    'Class 11': 'Class 12',
    'Class 12': 'GRADUATED'
  };

  // Student Promotion Studio Handler
  const handleExecutePromotion = async () => {
    if (!selectedSchool) return;
    const targetStudents = students.filter(s => {
      const clsMatch = s.class_name?.toLowerCase().replace(/^class\s*/i, '').trim() === promotionSourceClass.toLowerCase().replace(/^class\s*/i, '').trim() || s.class_name?.toLowerCase() === promotionSourceClass.toLowerCase();
      const secMatch = promotionSourceSection === 'ALL' || (s.section || 'A').toUpperCase() === promotionSourceSection.toUpperCase();
      return clsMatch && secMatch;
    });

    if (targetStudents.length === 0) {
      alert(`No scholars found currently enrolled in ${promotionSourceClass}`);
      return;
    }

    const payload = targetStudents.map(s => {
      const cfg = promotionActionsMap[s.id] || {
        action: promotionSourceClass === 'Class 12' ? 'GRADUATE' : 'PROMOTE',
        targetSection: promotionTargetSection === 'SAME' ? (s.section || 'A') : promotionTargetSection
      };
      return {
        student_id: s.id,
        action: cfg.action,
        target_class: cfg.action === 'PROMOTE' ? promotionTargetClass : s.class_name,
        target_section: cfg.action === 'PROMOTE' ? (cfg.targetSection || s.section || 'A') : s.section,
        target_session: promotionTargetSession
      };
    });

    const isGraduating = promotionSourceClass === 'Class 12';
    const confirmPrompt = isGraduating
      ? `Confirm Graduation / Passing out of ${payload.length} Class 12 scholars into Alumni directory?`
      : `Confirm batch promotion of ${payload.length} students from ${promotionSourceClass} to ${promotionTargetClass} for Session ${promotionTargetSession}?`;

    if (!confirm(confirmPrompt)) {
      return;
    }

    setPromotionExecuting(true);
    try {
      const res = await fetch('/api/students/promote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          school_id: selectedSchool.id,
          promotions: payload
        })
      });
      const data = await res.json();
      if (data.success) {
        showAdminToast(data.message || 'Promotion Studio executed successfully!');
        setShowPromotionStudio(false);
        loadSchoolData(selectedSchool.id);
      } else {
        alert(data.error || 'Failed to execute promotion.');
      }
    } catch (e: any) {
      console.error(e);
      alert('Error executing promotion studio: ' + e.message);
    } finally {
      setPromotionExecuting(false);
    }
  };

  const handleSetAllPromotionAction = (targetAction: 'PROMOTE' | 'RETAIN' | 'GRADUATE' | 'LEFT') => {
    const targetStudents = students.filter(s => {
      const clsMatch = s.class_name?.toLowerCase().replace(/^class\s*/i, '').trim() === promotionSourceClass.toLowerCase().replace(/^class\s*/i, '').trim() || s.class_name?.toLowerCase() === promotionSourceClass.toLowerCase();
      const secMatch = promotionSourceSection === 'ALL' || (s.section || 'A').toUpperCase() === promotionSourceSection.toUpperCase();
      return clsMatch && secMatch;
    });

    const newMap = { ...promotionActionsMap };
    targetStudents.forEach(s => {
      newMap[s.id] = {
        action: targetAction,
        targetSection: promotionTargetSection === 'SAME' ? (s.section || 'A') : promotionTargetSection
      };
    });
    setPromotionActionsMap(newMap);
    showAdminToast(`Set all ${targetStudents.length} scholars in ${promotionSourceClass} to ${targetAction}!`);
  };

  const handleOpenIndividualPromotion = (s: Student) => {
    setIndividualPromotionStudent(s);
    const autoNext = NEXT_CLASS_MAP[s.class_name || 'Class 9'] || 'Class 10';
    setIndividualPromotionAction(s.class_name === 'Class 12' ? 'GRADUATE' : 'PROMOTE');
    setIndividualTargetClass(autoNext === 'GRADUATED' ? 'Class 12' : autoNext);
    setIndividualTargetSection(s.section || 'A');
    setIndividualTargetRoll(String(s.roll_no || ''));
    setIndividualTargetSession('2027-28');
  };

  const handleExecuteIndividualPromotion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!individualPromotionStudent || !selectedSchool) return;

    setPromotionExecuting(true);
    try {
      const payload = [{
        student_id: individualPromotionStudent.id,
        action: individualPromotionAction,
        target_class: individualPromotionAction === 'PROMOTE' ? individualTargetClass : individualPromotionStudent.class_name,
        target_section: individualTargetSection,
        target_session: individualTargetSession,
        roll_no: individualTargetRoll || undefined
      }];

      const res = await fetch('/api/students/promote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          school_id: selectedSchool.id,
          promotions: payload
        })
      });
      const data = await res.json();
      if (data.success) {
        showAdminToast(`Scholar '${individualPromotionStudent.full_name}' promoted/updated successfully!`);
        setIndividualPromotionStudent(null);
        loadSchoolData(selectedSchool.id);
      } else {
        alert(data.error || 'Failed to update student promotion.');
      }
    } catch (e: any) {
      console.error(e);
      alert('Error updating student: ' + e.message);
    } finally {
      setPromotionExecuting(false);
    }
  };

  const handleLogout = () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('current_user');
      localStorage.removeItem('current_school');
    }
    router.push('/login');
  };

  const formatClassDisplay = (cls?: string) => {
    if (!cls) return 'I';
    const c = cls.replace(/Class\s*/i, '').trim();
    const romanMap: Record<string, string> = {
      '1': 'I', '2': 'II', '3': 'III', '4': 'IV', '5': 'V',
      '6': 'VI', '7': 'VII', '8': 'VIII', '9': 'IX', '10': 'X',
      '11': 'XI', '12': 'XII'
    };
    return romanMap[c] || c;
  };

  const formatDateDisplay = (dateStr?: string, fallback = '14 Mar 2024') => {
    if (!dateStr) return fallback;
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    } catch (e) {
      return dateStr;
    }
  };

  const handleQuickCollectFee = (s: Student) => {
    setInvoiceForm({
      student_id: s.id,
      student_name: s.full_name,
      admission_no: s.admission_no,
      class_name: `${s.class_name} - ${s.section}`,
      tuition_fee: 12000,
      transport_fee: s.transport_opted === 'YES' ? 2000 : 0,
      exam_fee: 1000,
      amount: s.transport_opted === 'YES' ? 15000 : 13000,
      payment_mode: 'UPI / Online',
      due_date: new Date().toISOString().split('T')[0],
      status: 'PAID'
    });
    setShowAddInvoice(true);
  };

  // Helper to reliably resolve faculty gender
  const resolveTeacherGender = (t: Teacher): 'Female' | 'Male' => {
    if (t.gender) {
      const g = t.gender.trim().toLowerCase();
      if (g === 'female' || g === 'f') return 'Female';
      if (g === 'male' || g === 'm') return 'Male';
    }
    const name = (t.full_name || '').toLowerCase();
    if (name.includes('mrs.') || name.includes('ms.') || name.includes('miss') || name.includes('sister') || name.includes('smt') || name.includes('shmt')) {
      return 'Female';
    }
    if (name.includes('mr.') || name.includes('shri') || name.includes('master')) {
      return 'Male';
    }
    const femaleKeywords = [
      'sunita', 'pooja', 'nalini', 'meenakshi', 'ananya', 'priya', 'kavita', 'shweta',
      'deepa', 'ritu', 'sneha', 'divya', 'anjali', 'archana', 'kiran', 'neeta',
      'sangeeta', 'geeta', 'asha', 'rekha', 'sarita', 'swati', 'komal', 'radha',
      'seema', 'preeti', 'rani', 'kumari', 'devi', 'kaur', 'begum', 'fatima', 'aisha', 'neha', 'tanvi'
    ];
    if (femaleKeywords.some(kw => name.includes(kw))) {
      return 'Female';
    }
    const num = parseInt((t.staff_code || t.id || '').replace(/\D/g, '') || '0');
    return (num % 3 !== 0) ? 'Female' : 'Male';
  };

  // CBSE Hierarchical Class Sorter Helper
  const CLASS_HIERARCHY: Record<string, number> = {
    'nursery': 0, 'lkg': 1, 'ukg': 2,
    'class 1': 3, '1': 3, 'class 2': 4, '2': 4, 'class 3': 5, '3': 5, 'class 4': 6, '4': 6, 'class 5': 7, '5': 7,
    'class 6': 8, '6': 8, 'class 7': 9, '7': 9, 'class 8': 10, '8': 10, 'class 9': 11, '9': 11, 'class 10': 12, '10': 12,
    'class 11': 13, '11': 13, 'class 12': 14, '12': 14
  };

  // 1. FILTERED STUDENTS
  const filteredStudents = (students || []).filter(s => {
    if (!s) return false;
    if (studentStatusFilter !== 'ALL' && s.status !== studentStatusFilter) return false;
    if (studentClassFilter !== 'ALL') {
      const targetClass = studentClassFilter.toLowerCase().replace(/^class\s*/i, '').trim();
      const sClass = (s.class_name || '').toLowerCase().replace(/^class\s*/i, '').trim();
      if (targetClass !== sClass && s.class_name?.toLowerCase() !== studentClassFilter.toLowerCase()) return false;
    }
    if (studentSectionFilter !== 'ALL' && s.section?.toUpperCase() !== studentSectionFilter.toUpperCase()) return false;
    if (studentFeeFilter !== 'ALL' && s.fee_status?.toUpperCase() !== studentFeeFilter.toUpperCase()) return false;
    if (studentGenderFilter !== 'ALL' && s.gender?.toLowerCase() !== studentGenderFilter.toLowerCase()) return false;
    if (studentHouseFilter !== 'ALL') {
      const sHouse = s.house || (['Red House', 'Blue House', 'Green House', 'Yellow House'][(students.indexOf(s)) % 4]);
      if (sHouse !== studentHouseFilter) return false;
    }
    
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    const name = (s.full_name || '').toLowerCase();
    const adm = (s.admission_no || '').toLowerCase();
    const cls = (s.class_name || '').toLowerCase();
    const sec = (s.section || '').toLowerCase();
    const roll = String(s.roll_no || '').toLowerCase();
    const guardian = (s.guardian_name || '').toLowerCase();
    const apaar = (s.apaar_id || '').toLowerCase();
    return name.includes(q) || adm.includes(q) || cls.includes(q) || sec.includes(q) || roll.includes(q) || guardian.includes(q) || apaar.includes(q);
  }).sort((a, b) => {
    if (studentSortBy === 'A-Z' || studentSortBy === 'name-asc') return (a.full_name || '').localeCompare(b.full_name || '');
    if (studentSortBy === 'Z-A' || studentSortBy === 'name-desc') return (b.full_name || '').localeCompare(a.full_name || '');
    if (studentSortBy === 'Adm-Asc' || studentSortBy === 'adm-asc') return (a.admission_no || '').localeCompare(b.admission_no || '', undefined, { numeric: true });
    if (studentSortBy === 'adm-desc') return (b.admission_no || '').localeCompare(a.admission_no || '', undefined, { numeric: true });
    if (studentSortBy === 'roll-asc') return (Number(a.roll_no) || 0) - (Number(b.roll_no) || 0);
    if (studentSortBy === 'roll-desc') return (Number(b.roll_no) || 0) - (Number(a.roll_no) || 0);
    if (studentSortBy === 'class-asc') {
      const ca = CLASS_HIERARCHY[(a.class_name || '').toLowerCase()] ?? 99;
      const cb = CLASS_HIERARCHY[(b.class_name || '').toLowerCase()] ?? 99;
      return ca - cb;
    }
    if (studentSortBy === 'class-desc') {
      const ca = CLASS_HIERARCHY[(a.class_name || '').toLowerCase()] ?? 99;
      const cb = CLASS_HIERARCHY[(b.class_name || '').toLowerCase()] ?? 99;
      return cb - ca;
    }
    if (studentSortBy === 'sec-asc') return (a.section || '').localeCompare(b.section || '');
    if (studentSortBy === 'sec-desc') return (b.section || '').localeCompare(a.section || '');
    if (studentSortBy === 'gender-asc') return (a.gender || '').localeCompare(b.gender || '');
    if (studentSortBy === 'gender-desc') return (b.gender || '').localeCompare(a.gender || '');
    if (studentSortBy === 'status-asc') return (a.status || 'ACTIVE').localeCompare(b.status || 'ACTIVE');
    if (studentSortBy === 'status-desc') return (b.status || 'ACTIVE').localeCompare(a.status || 'ACTIVE');
    if (studentSortBy === 'Date-Asc' || studentSortBy === 'date-asc') return new Date(a.admission_date || a.created_at || 0).getTime() - new Date(b.admission_date || b.created_at || 0).getTime();
    if (studentSortBy === 'date-desc') return new Date(b.admission_date || b.created_at || 0).getTime() - new Date(a.admission_date || a.created_at || 0).getTime();
    if (studentSortBy === 'dob-asc') return new Date(a.dob || 0).getTime() - new Date(b.dob || 0).getTime();
    if (studentSortBy === 'dob-desc') return new Date(b.dob || 0).getTime() - new Date(a.dob || 0).getTime();
    return 0;
  });

  const totalStudentEntries = filteredStudents.length;
  const totalStudentPages = Math.ceil(totalStudentEntries / studentRowsPerPage) || 1;
  const paginatedStudents = filteredStudents.slice(
    (studentPage - 1) * studentRowsPerPage,
    studentPage * studentRowsPerPage
  );

  // 2. FILTERED TEACHERS
  const filteredTeachers = (teachers || []).filter(t => {
    if (!t) return false;
    if (teacherStatusFilter !== 'ALL' && t.status !== teacherStatusFilter) return false;
    if (teacherDeptFilter !== 'ALL' && !t.department?.toLowerCase().includes(teacherDeptFilter.toLowerCase())) return false;
    if (teacherDesignationFilter !== 'ALL' && !t.designation?.toLowerCase().includes(teacherDesignationFilter.toLowerCase())) return false;
    if (teacherCtetFilter !== 'ALL' && (t.ctet_qualified || 'NO').toUpperCase() !== teacherCtetFilter.toUpperCase()) return false;
    if (teacherGenderFilter !== 'ALL' && resolveTeacherGender(t).toLowerCase() !== teacherGenderFilter.toLowerCase()) return false;
    
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    const name = (t.full_name || '').toLowerCase();
    const code = (t.staff_code || '').toLowerCase();
    const subj = (t.subject_specialization || t.department || '').toLowerCase();
    const cls = (t.classes_taught || '').toLowerCase();
    const desig = (t.designation || '').toLowerCase();
    const phone = (t.phone || '').toLowerCase();
    const email = (t.email || '').toLowerCase();
    return name.includes(q) || code.includes(q) || subj.includes(q) || cls.includes(q) || desig.includes(q) || phone.includes(q) || email.includes(q);
  }).sort((a, b) => {
    if (teacherSortBy === 'A-Z' || teacherSortBy === 'name-asc') return (a.full_name || '').localeCompare(b.full_name || '');
    if (teacherSortBy === 'Z-A' || teacherSortBy === 'name-desc') return (b.full_name || '').localeCompare(a.full_name || '');
    if (teacherSortBy === 'ID-Asc' || teacherSortBy === 'id-asc') return (a.staff_code || '').localeCompare(b.staff_code || '', undefined, { numeric: true });
    if (teacherSortBy === 'id-desc') return (b.staff_code || '').localeCompare(a.staff_code || '', undefined, { numeric: true });
    if (teacherSortBy === 'desig-asc') return (a.designation || '').localeCompare(b.designation || '');
    if (teacherSortBy === 'desig-desc') return (b.designation || '').localeCompare(a.designation || '');
    if (teacherSortBy === 'dept-asc') return (a.department || '').localeCompare(b.department || '');
    if (teacherSortBy === 'dept-desc') return (b.department || '').localeCompare(a.department || '');
    if (teacherSortBy === 'status-asc') return (a.status || 'ACTIVE').localeCompare(b.status || 'ACTIVE');
    if (teacherSortBy === 'status-desc') return (b.status || 'ACTIVE').localeCompare(a.status || 'ACTIVE');
    if (teacherSortBy === 'Date-Asc' || teacherSortBy === 'date-asc') return new Date(a.date_of_joining || 0).getTime() - new Date(b.date_of_joining || 0).getTime();
    if (teacherSortBy === 'date-desc') return new Date(b.date_of_joining || 0).getTime() - new Date(a.date_of_joining || 0).getTime();
    return 0;
  });

  const totalTeacherEntries = filteredTeachers.length;
  const totalTeacherPages = Math.ceil(totalTeacherEntries / teacherRowsPerPage) || 1;
  const paginatedTeachers = filteredTeachers.slice(
    (teacherPage - 1) * teacherRowsPerPage,
    teacherPage * teacherRowsPerPage
  );

  // 3. FILTERED CLASSES
  const filteredClasses = (classes || []).filter(c => {
    if (!c) return false;
    if (classStatusFilter !== 'ALL' && c.status !== classStatusFilter) return false;
    if (classSectionFilter !== 'ALL' && c.section?.toUpperCase() !== classSectionFilter.toUpperCase()) return false;
    
    if (classWingFilter !== 'ALL') {
      const cls = (c.class_name || '').toLowerCase();
      if (classWingFilter === 'PRE_PRIMARY' && !(cls.includes('nursery') || cls.includes('lkg') || cls.includes('ukg') || cls.includes('kg') || cls.includes('prep'))) return false;
      if (classWingFilter === 'PRIMARY' && !(cls.includes('class 1') || cls.includes('class 2') || cls.includes('class 3') || cls.includes('class 4') || cls.includes('class 5') || cls === '1' || cls === '2' || cls === '3' || cls === '4' || cls === '5')) return false;
      if (classWingFilter === 'MIDDLE' && !(cls.includes('class 6') || cls.includes('class 7') || cls.includes('class 8') || cls === '6' || cls === '7' || cls === '8')) return false;
      if (classWingFilter === 'SECONDARY' && !(cls.includes('class 9') || cls.includes('class 10') || cls === '9' || cls === '10')) return false;
      if (classWingFilter === 'SR_SECONDARY' && !(cls.includes('class 11') || cls.includes('class 12') || cls === '11' || cls === '12')) return false;
    }
    
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    const name = (c.class_name || '').toLowerCase();
    const sec = (c.section || '').toLowerCase();
    const code = (c.class_code || c.id || '').toLowerCase();
    const teacher = (c.class_teacher || '').toLowerCase();
    const room = (c.room_no || '').toLowerCase();
    return name.includes(q) || sec.includes(q) || code.includes(q) || teacher.includes(q) || room.includes(q);
  }).sort((a, b) => {
    if (classSortBy === 'A-Z' || classSortBy === 'class-asc') {
      const ca = CLASS_HIERARCHY[(a.class_name || '').toLowerCase()] ?? 99;
      const cb = CLASS_HIERARCHY[(b.class_name || '').toLowerCase()] ?? 99;
      return ca - cb;
    }
    if (classSortBy === 'Z-A' || classSortBy === 'class-desc') {
      const ca = CLASS_HIERARCHY[(a.class_name || '').toLowerCase()] ?? 99;
      const cb = CLASS_HIERARCHY[(b.class_name || '').toLowerCase()] ?? 99;
      return cb - ca;
    }
    if (classSortBy === 'ID-Asc' || classSortBy === 'code-asc') return (a.class_code || a.id || '').localeCompare(b.class_code || b.id || '', undefined, { numeric: true });
    if (classSortBy === 'code-desc') return (b.class_code || b.id || '').localeCompare(a.class_code || a.id || '', undefined, { numeric: true });
    if (classSortBy === 'sec-asc') return (a.section || '').localeCompare(b.section || '');
    if (classSortBy === 'sec-desc') return (b.section || '').localeCompare(a.section || '');
    if (classSortBy === 'teacher-asc') return (a.class_teacher || '').localeCompare(b.class_teacher || '');
    if (classSortBy === 'teacher-desc') return (b.class_teacher || '').localeCompare(a.class_teacher || '');
    if (classSortBy === 'capacity-asc') return (a.capacity || 0) - (b.capacity || 0);
    if (classSortBy === 'capacity-desc') return (b.capacity || 0) - (a.capacity || 0);
    if (classSortBy === 'status-asc') return (a.status || 'ACTIVE').localeCompare(b.status || 'ACTIVE');
    if (classSortBy === 'status-desc') return (b.status || 'ACTIVE').localeCompare(a.status || 'ACTIVE');
    return 0;
  });

  const totalClassEntries = filteredClasses.length;
  const totalClassPages = Math.ceil(totalClassEntries / classRowsPerPage) || 1;
  const paginatedClasses = filteredClasses.slice(
    (classPage - 1) * classRowsPerPage,
    classPage * classRowsPerPage
  );

  // 4. FILTERED FEE INVOICES
  const filteredInvoices = (invoices || []).filter(inv => {
    if (!inv) return false;
    if (feeStatusFilter !== 'ALL' && inv.status?.toUpperCase() !== feeStatusFilter.toUpperCase()) return false;
    if (feeClassFilter !== 'ALL' && !inv.class_name?.toLowerCase().includes(feeClassFilter.toLowerCase())) return false;
    if (feePaymentModeFilter !== 'ALL' && !inv.payment_mode?.toLowerCase().includes(feePaymentModeFilter.toLowerCase())) return false;
    
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    const sname = (inv.student_name || '').toLowerCase();
    const adm = (inv.admission_no || '').toLowerCase();
    const invNo = (inv.invoice_no || '').toLowerCase();
    const cls = (inv.class_name || '').toLowerCase();
    return sname.includes(q) || adm.includes(q) || invNo.includes(q) || cls.includes(q);
  }).sort((a, b) => {
    if (feeSortBy === 'Date-Desc') return (b.due_date || (b as any).created_at || '').localeCompare(a.due_date || (a as any).created_at || '');
    if (feeSortBy === 'Date-Asc') return (a.due_date || (a as any).created_at || '').localeCompare(b.due_date || (b as any).created_at || '');
    if (feeSortBy === 'Amount-Desc') return (Number(b.amount) || 0) - (Number(a.amount) || 0);
    if (feeSortBy === 'Amount-Asc') return (Number(a.amount) || 0) - (Number(b.amount) || 0);
    return 0;
  });

  const totalFeeEntries = filteredInvoices.length;
  const totalFeePages = Math.ceil(totalFeeEntries / feeRowsPerPage) || 1;
  const paginatedInvoices = filteredInvoices.slice(
    (feePage - 1) * feeRowsPerPage,
    feePage * feeRowsPerPage
  );

  // 5. FILTERED ATTENDANCE
  const filteredAttendance = (attendance || []).filter(a => {
    if (!a) return false;
    if (attendanceClassFilter !== 'ALL' && !a.class_name?.toLowerCase().includes(attendanceClassFilter.toLowerCase())) return false;
    if (attendanceDateFilter && a.date !== attendanceDateFilter) return false;
    
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    const cls = (a.class_name || '').toLowerCase();
    const sec = (a.section || '').toLowerCase();
    const marked = (a.marked_by || '').toLowerCase();
    const dt = (a.date || '').toLowerCase();
    return cls.includes(q) || sec.includes(q) || marked.includes(q) || dt.includes(q);
  });

  // 6. FILTERED NOTICES
  const filteredNotices = (notices || []).filter(n => {
    if (!n) return false;
    if (noticeAudienceFilter !== 'ALL' && n.target_audience !== noticeAudienceFilter) return false;
    
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    const title = (n.title || '').toLowerCase();
    const content = (n.content || '').toLowerCase();
    const posted = (n.posted_by || '').toLowerCase();
    return title.includes(q) || content.includes(q) || posted.includes(q);
  });

  const exportToCSV = (filename: string, headers: string[], rows: (string | number)[][]) => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(e => e.map(val => `"${String(val || '').replace(/"/g, '""')}"`).join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const schoolInitial = selectedSchool?.school_name?.trim()[0]?.toUpperCase() || 'E';

  // Fee calculation stats
  const totalBilled = invoices.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  const totalPaid = invoices.filter(i => i.status === 'PAID').reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  const totalPending = invoices.filter(i => i.status !== 'PAID').reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);

  return (
    <div className="min-h-screen flex flex-col bg-[var(--parchment)] text-[var(--text-dark)] font-sans antialiased">
      {/* Top Header: Responsive with Mobile Drawer Toggle */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#DCE8E0] px-4 sm:px-8 py-3 flex items-center justify-between shadow-2xs">
        <div className="flex items-center gap-3">
          {/* Mobile Hamburger Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(true)}
            className="lg:hidden p-2 rounded-xl bg-[#F4F8F5] hover:bg-[#EBF5EF] text-[#122A24] border border-[#DCE8E0] transition-colors cursor-pointer shadow-2xs flex items-center justify-center"
            title="Open Navigation Menu"
            aria-label="Open Navigation Menu"
          >
            <Menu className="h-5 w-5" />
          </button>

          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-[#122A24] text-white shadow-xs text-sm sm:text-base font-bold flex items-center justify-center shrink-0">
              {schoolInitial}
            </span>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-display font-bold text-sm sm:text-lg text-[#122A24] tracking-tight truncate max-w-[170px] sm:max-w-md">
                  {selectedSchool?.school_name || 'Delhi Public International School'}
                </span>
                {selectedSchool && (
                  <span className="hidden sm:inline-block font-mono text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#EBF5EF] text-[#1C443A] font-bold border border-[#C5E2CF]">
                    {selectedSchool.school_code}
                  </span>
                )}
              </div>
              <span className="font-mono text-[10px] text-[#2D5A4E] block -mt-0.5 truncate">
                {selectedSchool?.city ? `${selectedSchool.city} • ` : ''}{selectedSchool?.board || 'CBSE'} Curriculum • Admin App
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <div className="hidden md:flex items-center gap-2 px-3 py-1 rounded-full bg-[#EBF5EF] border border-[#C5E2CF] text-xs text-[#1C443A] font-medium font-mono">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Active Tenant Session</span>
          </div>

          <button
            onClick={() => selectedSchool && loadSchoolData(selectedSchool.id)}
            className="p-2 rounded-xl bg-[#F4F8F5] border border-[#DCE8E0] hover:bg-[#EBF5EF] text-[#122A24] transition-colors shadow-2xs cursor-pointer flex items-center justify-center"
            title="Refresh Data"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={handleLogout}
            className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-xs font-semibold text-rose-700 flex items-center gap-1.5 transition-colors border border-rose-200 cursor-pointer"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>
        </div>
      </header>

      {/* MOBILE SLIDE-OUT DRAWER OVERLAY */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          {/* Backdrop Blur */}
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity animate-fade-in"
            onClick={() => setMobileMenuOpen(false)}
          />

          {/* Drawer Content */}
          <aside className="relative w-72 sm:w-80 bg-[#122A24] text-white p-5 flex flex-col gap-1 z-50 h-full overflow-y-auto shadow-2xl animate-slide-in">
            {/* Drawer Header */}
            <div className="flex items-center justify-between pb-4 mb-2 border-b border-white/15">
              <div className="flex items-center gap-2.5">
                <span className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-sm border border-emerald-500/30">
                  {schoolInitial}
                </span>
                <div>
                  <div className="font-display font-bold text-sm text-white truncate max-w-[160px]">
                    {selectedSchool?.school_name || 'DPS2026 ERP'}
                  </div>
                  <div className="text-[10px] font-mono text-emerald-300">
                    {selectedSchool?.school_code || 'DPS2026'} • CBSE
                  </div>
                </div>
              </div>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white border-none cursor-pointer"
                title="Close Menu"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="text-[10.5px] font-semibold text-emerald-200/70 uppercase tracking-wider px-3 mb-1.5 font-mono">
              Academic Modules
            </div>

            <button
              onClick={() => { setActiveTab('overview'); setMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all border-none cursor-pointer text-left ${
                activeTab === 'overview' ? 'bg-white text-[#122A24] shadow-md font-bold' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
              }`}
            >
              <BarChart3 className="h-4 w-4 shrink-0" /> Overview Dashboard
            </button>

            <button
              onClick={() => { setActiveTab('students'); setMobileMenuOpen(false); }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all border-none cursor-pointer text-left ${
                activeTab === 'students' ? 'bg-white text-[#122A24] shadow-md font-bold' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
              }`}
            >
              <span className="flex items-center gap-3">
                <Users className="h-4 w-4 shrink-0" /> Students SIS
              </span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                activeTab === 'students' ? 'bg-[#122A24] text-white' : 'bg-white/20 text-white'
              }`}>
                {students.length}
              </span>
            </button>

            <button
              onClick={() => { setActiveTab('teachers'); setMobileMenuOpen(false); }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all border-none cursor-pointer text-left ${
                activeTab === 'teachers' ? 'bg-white text-[#122A24] shadow-md font-bold' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
              }`}
            >
              <span className="flex items-center gap-3">
                <GraduationCap className="h-4 w-4 shrink-0" /> Faculty &amp; Staff
              </span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                activeTab === 'teachers' ? 'bg-[#122A24] text-white' : 'bg-white/20 text-white'
              }`}>
                {teachers.length}
              </span>
            </button>

            <button
              onClick={() => { setActiveTab('classes'); setMobileMenuOpen(false); }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all border-none cursor-pointer text-left ${
                activeTab === 'classes' ? 'bg-white text-[#122A24] shadow-md font-bold' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
              }`}
            >
              <span className="flex items-center gap-3">
                <BookOpen className="h-4 w-4 shrink-0" /> Classes &amp; Sections
              </span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                activeTab === 'classes' ? 'bg-[#122A24] text-white' : 'bg-white/20 text-white'
              }`}>
                {classes.length}
              </span>
            </button>

            <button
              onClick={() => { setActiveTab('attendance'); setMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all border-none cursor-pointer text-left ${
                activeTab === 'attendance' ? 'bg-white text-[#122A24] shadow-md font-bold' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
              }`}
            >
              <CalendarCheck className="h-4 w-4 shrink-0" /> Daily Attendance
            </button>

            <button
              onClick={() => { setActiveTab('fees'); setMobileMenuOpen(false); }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all border-none cursor-pointer text-left ${
                activeTab === 'fees' ? 'bg-white text-[#122A24] shadow-md font-bold' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
              }`}
            >
              <span className="flex items-center gap-3">
                <CreditCard className="h-4 w-4 shrink-0" /> Fee Invoices
              </span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                activeTab === 'fees' ? 'bg-[#122A24] text-white' : 'bg-white/20 text-white'
              }`}>
                {invoices.length}
              </span>
            </button>

            <button
              onClick={() => { setActiveTab('notices'); setMobileMenuOpen(false); }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all border-none cursor-pointer text-left ${
                activeTab === 'notices' ? 'bg-white text-[#122A24] shadow-md font-bold' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
              }`}
            >
              <span className="flex items-center gap-3">
                <Bell className="h-4 w-4 shrink-0" /> Notice Board
              </span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                activeTab === 'notices' ? 'bg-[#122A24] text-white' : 'bg-white/20 text-white'
              }`}>
                {notices.length}
              </span>
            </button>

            <div className="my-2 border-t border-white/15" />

            <button
              onClick={() => { setActiveTab('settings'); setMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all border-none cursor-pointer text-left ${
                activeTab === 'settings' ? 'bg-white text-[#122A24] shadow-md font-bold' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
              }`}
            >
              <Settings className="h-4 w-4 shrink-0" /> School Settings
            </button>

            {/* Mobile User Profile Card */}
            <div className="mt-auto p-3.5 rounded-2xl bg-white/10 border border-white/15 text-xs text-slate-200 space-y-2">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-emerald-500/30 text-emerald-300 font-bold flex items-center justify-center text-xs shrink-0 border border-emerald-400/40">
                  {(currentUser?.full_name || selectedSchool?.principal_name || 'A')[0]?.toUpperCase()}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-semibold text-white text-xs truncate">
                    {currentUser?.full_name || selectedSchool?.principal_name || 'Administrator'}
                  </div>
                  <div className="text-[10px] text-emerald-300/80 font-mono truncate">
                    ID: {currentUser?.username || selectedSchool?.admin_id || 'admin'}
                  </div>
                </div>
              </div>
            </div>
          </aside>
        </div>
      )}

      {/* Main Workspace Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar (Desktop Only) */}
        <aside className="hidden lg:flex w-64 bg-[#122A24] text-white p-4 flex-col gap-1 shrink-0 border-r border-white/10 overflow-y-auto">
          <div className="text-[11px] font-semibold text-slate-300 uppercase tracking-wider px-3 mb-2 font-mono">
            Management Modules
          </div>

          <button
            onClick={() => setActiveTab('overview')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all border-none cursor-pointer text-left ${
              activeTab === 'overview' ? 'bg-white text-[#122A24] font-bold shadow-md' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <BarChart3 className="h-4 w-4 shrink-0" /> Overview Dashboard
          </button>

          <button
            onClick={() => setActiveTab('students')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all border-none cursor-pointer text-left ${
              activeTab === 'students' ? 'bg-white text-[#122A24] font-bold shadow-md' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-3">
              <Users className="h-4 w-4 shrink-0" /> Students SIS
            </span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
              activeTab === 'students' ? 'bg-[#122A24] text-white' : 'bg-white/20 text-white'
            }`}>
              {students.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('teachers')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all border-none cursor-pointer text-left ${
              activeTab === 'teachers' ? 'bg-white text-[#122A24] font-bold shadow-md' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-3">
              <GraduationCap className="h-4 w-4 shrink-0" /> Faculty &amp; Staff
            </span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
              activeTab === 'teachers' ? 'bg-[#122A24] text-white' : 'bg-white/20 text-white'
            }`}>
              {teachers.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('classes')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all border-none cursor-pointer text-left ${
              activeTab === 'classes' ? 'bg-white text-[#122A24] font-bold shadow-md' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-3">
              <BookOpen className="h-4 w-4 shrink-0" /> Classes &amp; Sections
            </span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
              activeTab === 'classes' ? 'bg-[#122A24] text-white' : 'bg-white/20 text-white'
            }`}>
              {classes.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('attendance')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all border-none cursor-pointer text-left ${
              activeTab === 'attendance' ? 'bg-white text-[#122A24] font-bold shadow-md' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <CalendarCheck className="h-4 w-4 shrink-0" /> Daily Attendance
          </button>

          <button
            onClick={() => setActiveTab('fees')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all border-none cursor-pointer text-left ${
              activeTab === 'fees' ? 'bg-white text-[#122A24] font-bold shadow-md' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-3">
              <CreditCard className="h-4 w-4 shrink-0" /> Fee Invoices
            </span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
              activeTab === 'fees' ? 'bg-[#122A24] text-white' : 'bg-white/20 text-white'
            }`}>
              {invoices.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('notices')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all border-none cursor-pointer text-left ${
              activeTab === 'notices' ? 'bg-white text-[#122A24] font-bold shadow-md' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-3">
              <Bell className="h-4 w-4 shrink-0" /> Notice Board
            </span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
              activeTab === 'notices' ? 'bg-[#122A24] text-white' : 'bg-white/20 text-white'
            }`}>
              {notices.length}
            </span>
          </button>

          <div className="my-3 border-t border-white/10" />

          <div className="text-[11px] font-semibold text-slate-300 uppercase tracking-wider px-3 mb-2 font-mono">
            Administration
          </div>

          <button
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all border-none cursor-pointer text-left ${
              activeTab === 'settings' ? 'bg-white text-[#122A24] font-bold shadow-md' : 'bg-transparent text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <Settings className="h-4 w-4 shrink-0" /> School Settings
          </button>

          {/* User Profile Card at Sidebar Bottom with Customization Option */}
          <div className="mt-auto p-3.5 rounded-xl bg-white/10 border border-white/15 text-xs text-slate-200 space-y-2.5">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-white/20 text-white font-display font-bold flex items-center justify-center text-xs shrink-0 border border-white/20 shadow-xs">
                {(currentUser?.full_name || selectedSchool?.principal_name || 'A')[0]?.toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <div className="font-display font-semibold text-white text-xs truncate">
                  {currentUser?.full_name || selectedSchool?.principal_name || selectedSchool?.admin_name || 'Administrator'}
                </div>
                <div className="text-[10px] text-slate-300 font-mono truncate opacity-90">
                  {currentUser?.role || 'School Administrator'}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1.5 border-t border-white/10 text-[10px] font-mono">
              <span className="truncate">ID: {currentUser?.username || selectedSchool?.admin_id || 'Admin'}</span>
              <button
                onClick={() => {
                  setProfileForm({
                    full_name: currentUser?.full_name || selectedSchool?.principal_name || selectedSchool?.admin_name || 'Administrator',
                    username: currentUser?.username || selectedSchool?.admin_id || 'admin',
                    admin_pin: selectedSchool?.admin_pin || '123456',
                    email: currentUser?.email || `admin@${selectedSchool?.school_code?.toLowerCase() || 'school'}.edu`,
                    phone: currentUser?.phone || ''
                  });
                  setShowProfileModal(true);
                }}
                className="px-2 py-0.5 rounded bg-white/20 hover:bg-white/30 text-white text-[10px] font-semibold cursor-pointer border-none transition-colors"
                title="Customize Profile"
              >
                Customize
              </button>
            </div>
          </div>
        </aside>

        {/* Dynamic Content Area with Bottom Padding for Mobile Bar */}
        <main className="flex-1 overflow-y-auto p-3.5 sm:p-6 lg:p-8 pb-24 lg:pb-8 bg-[#F8FAF9]">
          {/* TAB 1: OVERVIEW (STRAVIX MODERN MINT/SAGE THEME WITH ANIMATED CHARTS) */}
          {activeTab === 'overview' && (
            <DashboardOverview
              selectedSchool={selectedSchool}
              overview={overview}
              students={students}
              teachers={teachers}
              classes={classes}
              invoices={invoices}
              attendance={attendance}
              currentUser={currentUser}
              openStudentModal={openStudentModal}
              openTeacherModal={openTeacherModal}
              notices={notices}
              setShowAddNotice={setShowAddNotice}
              setShowAddInvoice={setShowAddInvoice}
              setViewInvoice={setViewInvoice}
              setActiveTab={setActiveTab}
            />
          )}

          {/* TAB 2: STUDENTS (THEME-ALIGNED PREMIUM MINT & FOREST GREEN) */}
          {activeTab === 'students' && (
            <div className="space-y-5 max-w-7xl mx-auto animate-fade-in">
              {/* Main Card Container */}
              <div className="bg-white rounded-3xl border border-[#DCE8E0] shadow-xs p-5 sm:p-7 space-y-5">
                {/* Top Breadcrumb & Action Toolbar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E8F0EA]">
                  <div>
                    <div className="flex items-center gap-3">
                      <h1 className="font-display font-bold text-2xl sm:text-3xl text-[#122A24] tracking-tight">
                        Students Directory
                      </h1>
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF]">
                        {filteredStudents.length} Active Enrolled
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-[#2D5A4E] font-mono mt-1">
                      <span>DPS2026</span>
                      <span>/</span>
                      <span>Institutional Registry</span>
                      <span>/</span>
                      <span className="text-[#122A24] font-semibold">CBSE All Classes (Pre-Primary to XII)</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Refresh Button */}
                    <button
                      onClick={() => selectedSchool && loadSchoolData(selectedSchool.id)}
                      className="w-9 h-9 rounded-full bg-[#F4F8F5] border border-[#DCE8E0] hover:bg-[#EBF5EF] text-[#122A24] transition-colors shadow-2xs flex items-center justify-center cursor-pointer"
                      title="Refresh List"
                    >
                      <RefreshCw className="h-4 w-4" />
                    </button>

                    {/* Print Button */}
                    <button
                      onClick={() => window.print()}
                      className="w-9 h-9 rounded-full bg-[#F4F8F5] border border-[#DCE8E0] hover:bg-[#EBF5EF] text-[#122A24] transition-colors shadow-2xs flex items-center justify-center cursor-pointer"
                      title="Print Register"
                    >
                      <Printer className="h-4 w-4" />
                    </button>

                    {/* Export Dropdown */}
                    <div className="relative">
                      <button
                        onClick={() => setShowExportMenu(showExportMenu === 'students' ? null : 'students')}
                        className="flex items-center gap-1.5 px-3.5 py-2 bg-[#F4F8F5] border border-[#DCE8E0] hover:bg-[#EBF5EF] rounded-full text-xs font-semibold text-[#122A24] shadow-2xs cursor-pointer"
                      >
                        <Download className="h-3.5 w-3.5 text-[#1C443A]" />
                        <span>Export</span>
                        <ChevronRight className={`h-3 w-3 transition-transform ${showExportMenu === 'students' ? 'rotate-90' : ''}`} />
                      </button>

                      {showExportMenu === 'students' && (
                        <div className="absolute right-0 mt-1.5 w-40 bg-white rounded-2xl shadow-xl border border-[#DCE8E0] py-1.5 z-30 text-xs animate-fade-in">
                          <button
                            onClick={() => {
                              setShowExportMenu(null);
                              exportToCSV(
                                'CBSE_Students_List',
                                ['Admission No', 'Roll No', 'Name', 'Class', 'Section', 'Gender', 'Status', 'Date of Join', 'DOB', 'Guardian Phone'],
                                filteredStudents.map(s => [
                                  s.admission_no,
                                  s.roll_no || '',
                                  s.full_name,
                                  s.class_name,
                                  s.section,
                                  s.gender || 'Female',
                                  s.status || 'ACTIVE',
                                  s.admission_date || '',
                                  s.dob || '',
                                  s.guardian_phone || s.father_phone || ''
                                ])
                              );
                            }}
                            className="w-full text-left px-3.5 py-2 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer text-xs font-medium text-[#122A24] flex items-center gap-2"
                          >
                            <FileText className="h-3.5 w-3.5 text-emerald-600" />
                            <span>Export CSV</span>
                          </button>
                          <button
                            onClick={() => {
                              setShowExportMenu(null);
                              window.print();
                            }}
                            className="w-full text-left px-3.5 py-2 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer text-xs font-medium text-[#122A24] flex items-center gap-2"
                          >
                            <Printer className="h-3.5 w-3.5 text-[#1C443A]" />
                            <span>Print PDF</span>
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Promotion Studio Trigger Button */}
                    <button
                      onClick={() => {
                        setPromotionSourceClass('Class 9');
                        setPromotionSourceSection('ALL');
                        setPromotionTargetClass('Class 10');
                        setPromotionTargetSection('SAME');
                        setPromotionActionsMap({});
                        setShowPromotionStudio(true);
                      }}
                      className="px-3.5 py-2 bg-[#EBF5EF] hover:bg-[#DCE8E0] text-[#122A24] border border-[#C5E2CF] rounded-full text-xs font-semibold flex items-center gap-1.5 shadow-2xs transition-all cursor-pointer"
                      title="Bulk promote or graduate scholars into next academic session"
                    >
                      <GraduationCap className="h-4 w-4 text-emerald-700" />
                      <span>Promotion Studio</span>
                    </button>

                    {/* Primary Add Button */}
                    <button
                      onClick={() => openStudentModal()}
                      className="px-4 py-2 bg-[#122A24] hover:bg-[#1C443A] text-white rounded-full text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-all border-none cursor-pointer"
                    >
                      <Plus className="h-4 w-4" /> Add Student
                    </button>
                  </div>
                </div>

                {/* Sub Header Controls Bar (Tier 1: Title, Status Tabs, Session, View Mode, Sort) */}
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pt-1">
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="font-display font-semibold text-base text-[#122A24]">
                      Students Register
                    </div>
                    {/* Fast Status Segmented Pill Tabs */}
                    <div className="flex items-center bg-[#F4F8F5] p-1 rounded-full border border-[#DCE8E0] shadow-2xs">
                      <button
                        onClick={() => { setStudentStatusFilter('ALL'); setStudentPage(1); }}
                        className={`px-3 py-1 rounded-full text-xs font-semibold border-none cursor-pointer transition-all ${
                          studentStatusFilter === 'ALL'
                            ? 'bg-[#122A24] text-white shadow-xs'
                            : 'bg-transparent text-[#2D5A4E] hover:text-[#122A24]'
                        }`}
                      >
                        All ({students.length})
                      </button>
                      <button
                        onClick={() => { setStudentStatusFilter('ACTIVE'); setStudentPage(1); }}
                        className={`px-3 py-1 rounded-full text-xs font-semibold border-none cursor-pointer flex items-center gap-1.5 transition-all ${
                          studentStatusFilter === 'ACTIVE'
                            ? 'bg-emerald-700 text-white shadow-xs'
                            : 'bg-transparent text-[#2D5A4E] hover:text-[#122A24]'
                        }`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-[#10B981]" />
                        Active ({students.filter(s => s.status !== 'INACTIVE').length})
                      </button>
                      <button
                        onClick={() => { setStudentStatusFilter('INACTIVE'); setStudentPage(1); }}
                        className={`px-3 py-1 rounded-full text-xs font-semibold border-none cursor-pointer flex items-center gap-1.5 transition-all ${
                          studentStatusFilter === 'INACTIVE'
                            ? 'bg-rose-700 text-white shadow-xs'
                            : 'bg-transparent text-rose-700 hover:text-rose-900 font-bold'
                        }`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                        Inactive ({students.filter(s => s.status === 'INACTIVE').length})
                      </button>
                    </div>
                  </div>

                  {/* Right Header Controls: Session, List/Grid, Sort */}
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Academic Session Pill */}
                    <div className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 bg-[#F4F8F5] border border-[#DCE8E0] rounded-full text-xs font-mono text-[#1C443A] shadow-2xs">
                      <Calendar className="h-3.5 w-3.5 text-[#2D5A4E]" />
                      <span>Session 2026-27</span>
                    </div>

                    {/* View Mode Toggle: List & Grid */}
                    <div className="flex items-center bg-[#F4F8F5] p-1 rounded-full border border-[#DCE8E0] shadow-2xs">
                      <button
                        onClick={() => setStudentViewMode('list')}
                        className={`p-1.5 rounded-full border-none cursor-pointer flex items-center justify-center transition-colors ${
                          studentViewMode === 'list' ? 'bg-[#122A24] text-white shadow-xs' : 'bg-transparent text-slate-500 hover:text-slate-800'
                        }`}
                        title="List View"
                      >
                        <List className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => setStudentViewMode('grid')}
                        className={`p-1.5 rounded-full border-none cursor-pointer flex items-center justify-center transition-colors ${
                          studentViewMode === 'grid' ? 'bg-[#122A24] text-white shadow-xs' : 'bg-transparent text-slate-500 hover:text-slate-800'
                        }`}
                        title="Grid View"
                      >
                        <Grid className="h-3.5 w-3.5" />
                      </button>
                    </div>

                    {/* Sort Dropdown */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#F4F8F5] border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                      <select
                        value={studentSortBy}
                        onChange={(e) => setStudentSortBy(e.target.value as any)}
                        className="bg-transparent border-none text-xs font-medium text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="A-Z">Sort: A to Z</option>
                        <option value="Z-A">Sort: Z to A</option>
                        <option value="Adm-Asc">Sort: Admission No</option>
                        <option value="class-asc">Sort: Class Order</option>
                        <option value="Date-Asc">Sort: Join Date</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Tier 2: Filters, Rows Per Page & Search Bar */}
                <div className="bg-[#F9FCFA] rounded-2xl border border-[#DCE8E0] p-3 flex flex-col xl:flex-row xl:items-center justify-between gap-3">
                  {/* Filter Dropdown Pills */}
                  <div className="flex items-center gap-2 overflow-x-auto no-scrollbar flex-wrap">
                    {/* Class Filter */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <span className="text-[#2D5A4E] text-[11px] font-mono">Class:</span>
                      <select
                        value={studentClassFilter}
                        onChange={(e) => { setStudentClassFilter(e.target.value); setStudentPage(1); }}
                        className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="ALL">All Classes</option>
                        <option value="Nursery">Nursery</option>
                        <option value="LKG">LKG</option>
                        <option value="UKG">UKG</option>
                        {Array.from({ length: 12 }, (_, i) => i + 1).map(num => (
                          <option key={num} value={`Class ${num}`}>{`Class ${num}`}</option>
                        ))}
                      </select>
                    </div>

                    {/* Section Filter */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <span className="text-[#2D5A4E] text-[11px] font-mono">Sec:</span>
                      <select
                        value={studentSectionFilter}
                        onChange={(e) => { setStudentSectionFilter(e.target.value); setStudentPage(1); }}
                        className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="ALL">All Sections</option>
                        <option value="A">Section A</option>
                        <option value="B">Section B</option>
                        <option value="C">Section C</option>
                      </select>
                    </div>

                    {/* Fee Status Filter */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <span className="text-[#2D5A4E] text-[11px] font-mono">Fees:</span>
                      <select
                        value={studentFeeFilter}
                        onChange={(e) => { setStudentFeeFilter(e.target.value as any); setStudentPage(1); }}
                        className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="ALL">All Fees</option>
                        <option value="PAID">Paid Only</option>
                        <option value="PENDING">Pending Dues</option>
                        <option value="OVERDUE">Overdue</option>
                      </select>
                    </div>

                    {/* School House Filter */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <span className="text-[#2D5A4E] text-[11px] font-mono">House:</span>
                      <select
                        value={studentHouseFilter}
                        onChange={(e) => { setStudentHouseFilter(e.target.value); setStudentPage(1); }}
                        className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="ALL">All Houses</option>
                        <option value="Red House">🔴 Red House</option>
                        <option value="Blue House">🔵 Blue House</option>
                        <option value="Green House">🟢 Green House</option>
                        <option value="Yellow House">🟡 Yellow House</option>
                      </select>
                    </div>
                  </div>

                  {/* Search & Rows Per Page */}
                  <div className="flex items-center gap-3 flex-col sm:flex-row">
                    <div className="flex items-center gap-2 text-xs text-[#2D5A4E] font-medium shrink-0">
                      <span>Rows:</span>
                      <select
                        value={studentRowsPerPage}
                        onChange={(e) => {
                          setStudentRowsPerPage(Number(e.target.value));
                          setStudentPage(1);
                        }}
                        className="px-2.5 py-1 bg-white border border-[#DCE8E0] rounded-lg text-xs font-semibold text-[#122A24] cursor-pointer focus:outline-none focus:border-[#10B981]"
                      >
                        <option value={10}>10</option>
                        <option value={25}>25</option>
                        <option value={50}>50</option>
                        <option value={100}>100</option>
                      </select>
                    </div>

                    <div className="relative w-full sm:w-72">
                      <Search className="absolute left-3.5 top-2.5 h-3.5 w-3.5 text-[#2D5A4E]" />
                      <input
                        type="text"
                        placeholder="Search student, adm, roll, class..."
                        value={searchQuery}
                        onChange={(e) => {
                          setSearchQuery(e.target.value);
                          setStudentPage(1);
                        }}
                        className="w-full pl-9 pr-4 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs text-[#122A24] placeholder-slate-400 focus:outline-none focus:border-[#10B981] transition-all shadow-2xs"
                      />
                    </div>
                  </div>
                </div>

                {/* Active Filter Badges */}
                {(studentClassFilter !== 'ALL' || studentSectionFilter !== 'ALL' || studentFeeFilter !== 'ALL' || studentHouseFilter !== 'ALL' || studentStatusFilter !== 'ALL' || searchQuery.trim() !== '') && (
                  <div className="flex flex-wrap items-center gap-2 px-1 text-xs">
                    <span className="text-[11px] font-mono text-[#2D5A4E] font-bold">Active Filters:</span>
                    {studentClassFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Class: {studentClassFilter}
                        <button onClick={() => setStudentClassFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {studentSectionFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Section: {studentSectionFilter}
                        <button onClick={() => setStudentSectionFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {studentFeeFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Fees: {studentFeeFilter}
                        <button onClick={() => setStudentFeeFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {studentHouseFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        House: {studentHouseFilter}
                        <button onClick={() => setStudentHouseFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {studentStatusFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Status: {studentStatusFilter}
                        <button onClick={() => setStudentStatusFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {searchQuery.trim() !== '' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Query: &ldquo;{searchQuery}&rdquo;
                        <button onClick={() => setSearchQuery('')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    <button
                      onClick={() => {
                        setStudentClassFilter('ALL');
                        setStudentSectionFilter('ALL');
                        setStudentFeeFilter('ALL');
                        setStudentHouseFilter('ALL');
                        setStudentStatusFilter('ALL');
                        setSearchQuery('');
                      }}
                      className="text-[11px] font-mono font-bold text-rose-600 hover:underline border-none bg-transparent cursor-pointer px-1"
                    >
                      Clear All
                    </button>
                  </div>
                )}

                {/* DYNAMIC REAL-TIME KPI TILES (RESPONSIVE TO ALL ACTIVE FILTERS) */}
                {(() => {
                  const sisFilteredTotal = filteredStudents.length;
                  const sisMaleCount = filteredStudents.filter(s => (s.gender || '').toLowerCase() === 'male').length;
                  const sisFemaleCount = filteredStudents.filter(s => (s.gender || '').toLowerCase() === 'female').length;
                  const sisMalePercent = sisFilteredTotal > 0 ? Math.round((sisMaleCount / sisFilteredTotal) * 100) : 50;

                  const sisBusCount = filteredStudents.filter(s => {
                    if (s.transport_opted === 'YES' || (s as any).transport_mode?.toUpperCase().includes('BUS')) return true;
                    const code = s.admission_no ? parseInt(s.admission_no.replace(/\D/g, '') || '0') : 0;
                    return code % 3 === 0;
                  }).length;
                  const sisSelfCount = Math.max(0, sisFilteredTotal - sisBusCount);
                  const sisBusPercent = sisFilteredTotal > 0 ? Math.round((sisBusCount / sisFilteredTotal) * 100) : 30;

                  const sisNewStudentCount = filteredStudents.filter((s, i) => {
                    if (s.admission_date && (s.admission_date.includes('2026') || s.admission_date.includes('2025'))) {
                      const code = s.admission_no ? parseInt(s.admission_no.replace(/\D/g, '') || '0') : 0;
                      return code % 4 === 0;
                    }
                    return i % 4 === 0;
                  }).length;
                  const sisOldStudentCount = Math.max(0, sisFilteredTotal - sisNewStudentCount);
                  const sisNewPercent = sisFilteredTotal > 0 ? Math.round((sisNewStudentCount / sisFilteredTotal) * 100) : 24;

                  const sisRedHouse = filteredStudents.filter((s, i) => (s as any).house === 'Red House' || i % 4 === 0).length;
                  const sisBlueHouse = filteredStudents.filter((s, i) => (s as any).house === 'Blue House' || i % 4 === 1).length;
                  const sisGreenHouse = filteredStudents.filter((s, i) => (s as any).house === 'Green House' || i % 4 === 2).length;
                  const sisYellowHouse = filteredStudents.filter((s, i) => (s as any).house === 'Yellow House' || i % 4 === 3).length;
                  const maxHouseCount = Math.max(sisRedHouse, sisBlueHouse, sisGreenHouse, sisYellowHouse, 1);

                  return (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-fade-in">
                      {/* 1. GENDER RATIO */}
                      <div className="relative bg-white rounded-3xl p-5 border border-[#DCE8E0] shadow-xs hover:shadow-md transition-all overflow-hidden flex flex-col justify-between">
                        <span className="absolute right-4 top-2 text-5xl font-extrabold text-[#F4F8F5] select-none font-mono pointer-events-none">
                          01
                        </span>
                        <div className="flex items-center justify-between gap-2 z-10">
                          <span className="text-[11px] font-mono font-bold tracking-wider text-[#122A24] uppercase">
                            Gender Ratio
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF] shadow-2xs">
                            {sisFilteredTotal} Total
                          </span>
                        </div>

                        <div className="my-3 flex items-center justify-center relative">
                          <div className="relative w-24 h-24 flex items-center justify-center">
                            <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
                              <path
                                className="text-[#EBF5EF]"
                                strokeWidth="4"
                                stroke="currentColor"
                                fill="none"
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              />
                              <path
                                className="text-[#10B981] transition-all duration-500 ease-out"
                                strokeDasharray={`${sisMalePercent}, 100`}
                                strokeWidth="4"
                                strokeLinecap="round"
                                stroke="currentColor"
                                fill="none"
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              />
                            </svg>
                            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                              <span className="text-sm font-extrabold text-[#122A24] font-display leading-none">{sisMalePercent}%</span>
                              <span className="text-[8.5px] font-mono font-bold text-[#1C443A] uppercase tracking-tighter mt-0.5">Male Ratio</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-xs font-mono text-[#2D5A4E] pt-2.5 border-t border-[#E8F0EA] z-10">
                          <span className="flex items-center gap-1.5 font-semibold text-[#122A24]">
                            <span className="w-2 h-2 rounded-full bg-[#10B981]" />
                            Male: <strong className="text-[#122A24] font-bold">{sisMaleCount}</strong>
                          </span>
                          <span className="flex items-center gap-1.5 font-semibold text-[#122A24]">
                            <span className="w-2 h-2 rounded-full bg-[#1C443A]" />
                            Female: <strong className="text-[#1C443A] font-bold">{sisFemaleCount}</strong>
                          </span>
                        </div>
                      </div>

                      {/* 2. TRANSPORT MODE */}
                      <div className="relative bg-white rounded-3xl p-5 border border-[#DCE8E0] shadow-xs hover:shadow-md transition-all overflow-hidden flex flex-col justify-between">
                        <span className="absolute right-4 top-2 text-5xl font-extrabold text-[#F4F8F5] select-none font-mono pointer-events-none">
                          02
                        </span>
                        <div className="flex items-center justify-between gap-2 z-10">
                          <span className="text-[11px] font-mono font-bold tracking-wider text-[#122A24] uppercase">
                            Transport Mode
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF] shadow-2xs">
                            🚌 Bus Service
                          </span>
                        </div>

                        <div className="my-3 flex items-center justify-center relative">
                          <div className="relative w-24 h-24 flex items-center justify-center">
                            <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
                              <path
                                className="text-[#EBF5EF]"
                                strokeWidth="4"
                                stroke="currentColor"
                                fill="none"
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              />
                              <path
                                className="text-[#10B981] transition-all duration-500 ease-out"
                                strokeDasharray={`${sisBusPercent}, 100`}
                                strokeWidth="4"
                                strokeLinecap="round"
                                stroke="currentColor"
                                fill="none"
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              />
                            </svg>
                            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                              <span className="text-sm font-extrabold text-[#122A24] font-display leading-none">{sisBusPercent}%</span>
                              <span className="text-[8.5px] font-mono font-bold text-[#1C443A] uppercase tracking-tighter mt-0.5">Use Bus</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-xs font-mono text-[#2D5A4E] pt-2.5 border-t border-[#E8F0EA] z-10">
                          <span className="flex items-center gap-1.5 font-semibold text-[#122A24]">
                            <span className="w-2 h-2 rounded-full bg-[#10B981]" />
                            Bus: <strong className="text-[#122A24] font-bold">{sisBusCount}</strong>
                          </span>
                          <span className="flex items-center gap-1.5 font-semibold text-[#122A24]">
                            <span className="w-2 h-2 rounded-full bg-[#1C443A]" />
                            Self: <strong className="text-[#1C443A] font-bold">{sisSelfCount}</strong>
                          </span>
                        </div>
                      </div>

                      {/* 3. ADMISSION TYPE */}
                      <div className="relative bg-white rounded-3xl p-5 border border-[#DCE8E0] shadow-xs hover:shadow-md transition-all overflow-hidden flex flex-col justify-between">
                        <span className="absolute right-4 top-2 text-5xl font-extrabold text-[#F4F8F5] select-none font-mono pointer-events-none">
                          03
                        </span>
                        <div className="flex items-center justify-between gap-2 z-10">
                          <span className="text-[11px] font-mono font-bold tracking-wider text-[#122A24] uppercase">
                            Admission Type
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF] shadow-2xs">
                            🎓 Slabs
                          </span>
                        </div>

                        <div className="my-3 flex items-center justify-center relative">
                          <div className="relative w-24 h-24 flex items-center justify-center">
                            <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
                              <path
                                className="text-[#EBF5EF]"
                                strokeWidth="4"
                                stroke="currentColor"
                                fill="none"
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              />
                              <path
                                className="text-[#122A24] transition-all duration-500 ease-out"
                                strokeDasharray={`${sisNewPercent}, 100`}
                                strokeWidth="4"
                                strokeLinecap="round"
                                stroke="currentColor"
                                fill="none"
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              />
                            </svg>
                            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                              <span className="text-sm font-extrabold text-[#122A24] font-display leading-none">{sisNewPercent}%</span>
                              <span className="text-[8.5px] font-mono font-bold text-[#1C443A] uppercase tracking-tighter mt-0.5">New Student</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-xs font-mono text-[#2D5A4E] pt-2.5 border-t border-[#E8F0EA] z-10">
                          <span className="flex items-center gap-1.5 font-semibold text-[#122A24]">
                            <span className="w-2 h-2 rounded-full bg-[#122A24]" />
                            New: <strong className="text-[#122A24] font-bold">{sisNewStudentCount}</strong>
                          </span>
                          <span className="flex items-center gap-1.5 font-semibold text-[#122A24]">
                            <span className="w-2 h-2 rounded-full bg-[#10B981]" />
                            Old: <strong className="text-[#1C443A] font-bold">{sisOldStudentCount}</strong>
                          </span>
                        </div>
                      </div>

                      {/* 4. SCHOOL HOUSES */}
                      <div className="relative bg-white rounded-3xl p-5 border border-[#DCE8E0] shadow-xs hover:shadow-md transition-all flex flex-col justify-between">
                        <div className="flex items-center justify-between gap-2 pb-2 border-b border-[#E8F0EA]">
                          <span className="text-[11px] font-mono font-bold tracking-wider text-[#122A24] uppercase">
                            School Houses
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF] shadow-2xs">
                            🏆 Houses
                          </span>
                        </div>

                        <div className="my-1.5 space-y-2">
                          {/* Red House */}
                          <div>
                            <div className="flex justify-between text-xs font-semibold mb-0.5">
                              <span className="flex items-center gap-1.5 text-rose-700">
                                <span className="w-2 h-2 rounded-full bg-rose-500" />
                                Red House
                              </span>
                              <span className="font-mono text-[#122A24] font-bold">{sisRedHouse}</span>
                            </div>
                            <div className="w-full h-1.5 bg-[#F4F8F5] rounded-full overflow-hidden border border-[#DCE8E0]">
                              <div
                                className="h-full bg-rose-500 rounded-full transition-all duration-500"
                                style={{ width: `${Math.round((sisRedHouse / maxHouseCount) * 100)}%` }}
                              />
                            </div>
                          </div>

                          {/* Blue House */}
                          <div>
                            <div className="flex justify-between text-xs font-semibold mb-0.5">
                              <span className="flex items-center gap-1.5 text-blue-700">
                                <span className="w-2 h-2 rounded-full bg-blue-600" />
                                Blue House
                              </span>
                              <span className="font-mono text-[#122A24] font-bold">{sisBlueHouse}</span>
                            </div>
                            <div className="w-full h-1.5 bg-[#F4F8F5] rounded-full overflow-hidden border border-[#DCE8E0]">
                              <div
                                className="h-full bg-blue-600 rounded-full transition-all duration-500"
                                style={{ width: `${Math.round((sisBlueHouse / maxHouseCount) * 100)}%` }}
                              />
                            </div>
                          </div>

                          {/* Green House */}
                          <div>
                            <div className="flex justify-between text-xs font-semibold mb-0.5">
                              <span className="flex items-center gap-1.5 text-emerald-800">
                                <span className="w-2 h-2 rounded-full bg-[#10B981]" />
                                Green House
                              </span>
                              <span className="font-mono text-[#122A24] font-bold">{sisGreenHouse}</span>
                            </div>
                            <div className="w-full h-1.5 bg-[#F4F8F5] rounded-full overflow-hidden border border-[#DCE8E0]">
                              <div
                                className="h-full bg-[#10B981] rounded-full transition-all duration-500"
                                style={{ width: `${Math.round((sisGreenHouse / maxHouseCount) * 100)}%` }}
                              />
                            </div>
                          </div>

                          {/* Yellow House */}
                          <div>
                            <div className="flex justify-between text-xs font-semibold mb-0.5">
                              <span className="flex items-center gap-1.5 text-amber-800">
                                <span className="w-2 h-2 rounded-full bg-amber-500" />
                                Yellow House
                              </span>
                              <span className="font-mono text-[#122A24] font-bold">{sisYellowHouse}</span>
                            </div>
                            <div className="w-full h-1.5 bg-[#F4F8F5] rounded-full overflow-hidden border border-[#DCE8E0]">
                              <div
                                className="h-full bg-amber-500 rounded-full transition-all duration-500"
                                style={{ width: `${Math.round((sisYellowHouse / maxHouseCount) * 100)}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* LIST VIEW */}
                {studentViewMode === 'list' && (
                  <div className="rounded-2xl border border-[#DCE8E0] overflow-hidden bg-white shadow-2xs">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead className="bg-[#F3F7F5] font-mono text-[11px] font-bold text-[#1C443A] uppercase tracking-wider border-b border-[#DCE8E0]">
                          <tr>
                            <th className="py-3 px-3.5 w-10 text-center">
                              <input
                                type="checkbox"
                                checked={paginatedStudents.length > 0 && paginatedStudents.every(s => selectedStudentIds.includes(s.id))}
                                onChange={(e) => {
                                  if (e.target.checked) {
                                    const newIds = Array.from(new Set([...selectedStudentIds, ...paginatedStudents.map(s => s.id)]));
                                    setSelectedStudentIds(newIds);
                                  } else {
                                    setSelectedStudentIds(selectedStudentIds.filter(id => !paginatedStudents.some(s => s.id === id)));
                                  }
                                }}
                                className="rounded border-slate-300 accent-[#122A24] cursor-pointer"
                              />
                            </th>
                            <th className="py-3 px-4">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setStudentSortBy(studentSortBy === 'adm-asc' || studentSortBy === 'Adm-Asc' ? 'adm-desc' : 'adm-asc')}
                                title="Sort by Admission No"
                              >
                                <span>Admission No</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-4">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setStudentSortBy(studentSortBy === 'roll-asc' ? 'roll-desc' : 'roll-asc')}
                                title="Sort by Roll No"
                              >
                                <span>Roll No</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-4">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setStudentSortBy(studentSortBy === 'name-asc' || studentSortBy === 'A-Z' ? 'name-desc' : 'name-asc')}
                                title="Sort by Student Name"
                              >
                                <span>Name</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-3">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setStudentSortBy(studentSortBy === 'class-asc' ? 'class-desc' : 'class-asc')}
                                title="Sort by Class Level (Nursery to 12)"
                              >
                                <span>Class</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-3">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setStudentSortBy(studentSortBy === 'sec-asc' ? 'sec-desc' : 'sec-asc')}
                                title="Sort by Section"
                              >
                                <span>Section</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-3">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setStudentSortBy(studentSortBy === 'gender-asc' ? 'gender-desc' : 'gender-asc')}
                                title="Sort by Gender"
                              >
                                <span>Gender</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-3">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setStudentSortBy(studentSortBy === 'status-asc' ? 'status-desc' : 'status-asc')}
                                title="Sort by Active / Inactive Status"
                              >
                                <span>Status</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-4">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setStudentSortBy(studentSortBy === 'date-asc' || studentSortBy === 'Date-Asc' ? 'date-desc' : 'date-asc')}
                                title="Sort by Date of Join"
                              >
                                <span>Date of Join</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-4">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setStudentSortBy(studentSortBy === 'dob-asc' ? 'dob-desc' : 'dob-asc')}
                                title="Sort by Date of Birth"
                              >
                                <span>DOB</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-4 text-center">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#EBF2ED] font-sans">
                          {paginatedStudents.map((s, idx) => {
                            const isSelected = selectedStudentIds.includes(s.id);
                            const initials = (s.full_name || 'Student')
                              .split(' ')
                              .map(n => n[0])
                              .slice(0, 2)
                              .join('')
                              .toUpperCase();
                            const avatarGradients = [
                              'bg-[#EBF5EF] text-[#122A24] border-[#C5E2CF]',
                              'bg-emerald-50 text-emerald-800 border-emerald-200',
                              'bg-[#E8F3EE] text-[#1C443A] border-[#D0E6DC]',
                              'bg-teal-50 text-teal-800 border-teal-200',
                              'bg-[#F0FDF4] text-[#166534] border-[#BBF7D0]'
                            ];
                            const avatarStyle = avatarGradients[idx % avatarGradients.length];

                            return (
                              <tr
                                key={s.id}
                                className={`hover:bg-[#F9FCFA] transition-colors ${isSelected ? 'bg-[#EBF5EF]/60' : ''}`}
                              >
                                {/* Selection Checkbox */}
                                <td className="py-3.5 px-3.5 text-center">
                                  <input
                                    type="checkbox"
                                    checked={isSelected}
                                    onChange={(e) => {
                                      if (e.target.checked) {
                                        setSelectedStudentIds([...selectedStudentIds, s.id]);
                                      } else {
                                        setSelectedStudentIds(selectedStudentIds.filter(id => id !== s.id));
                                      }
                                    }}
                                    className="rounded border-slate-300 accent-[#122A24] cursor-pointer"
                                  />
                                </td>

                                {/* Admission No */}
                                <td className="py-3.5 px-4 font-mono font-medium">
                                  <button
                                    onClick={() => openStudentModal(s)}
                                    className="text-[#122A24] hover:text-emerald-700 font-bold border-none bg-transparent p-0 cursor-pointer text-left block tracking-tight transition-colors"
                                    title="View & Edit Full CBSE Profile"
                                  >
                                    {s.admission_no}
                                  </button>
                                  <span className="text-[10px] text-slate-400 font-mono block">PIN: {s.passcode || '123456'}</span>
                                </td>

                                {/* Roll No */}
                                <td className="py-3.5 px-4 font-mono text-[#2D5A4E] font-medium">
                                  {s.roll_no || (idx + 1)}
                                </td>

                                {/* Name with Circular Avatar */}
                                <td className="py-3.5 px-4">
                                  <div className="flex items-center gap-2.5">
                                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs border shrink-0 shadow-2xs font-mono ${avatarStyle}`}>
                                      {initials}
                                    </div>
                                    <div>
                                      <div className="font-semibold text-[#122A24] hover:text-emerald-700 cursor-pointer transition-colors" onClick={() => openStudentModal(s)}>
                                        {s.full_name}
                                      </div>
                                      {s.apaar_id && (
                                        <div className="text-[10px] text-slate-400 font-mono">PEN: {s.apaar_id}</div>
                                      )}
                                    </div>
                                  </div>
                                </td>

                                {/* Class */}
                                <td className="py-3.5 px-3 text-[#122A24] font-semibold">
                                  {formatClassDisplay(s.class_name)}
                                </td>

                                {/* Section */}
                                <td className="py-3.5 px-3 text-[#122A24] font-mono font-medium">
                                  {s.section || 'A'}
                                </td>

                                {/* Gender */}
                                <td className="py-3.5 px-3 text-[#2D5A4E]">
                                  {s.gender || 'Female'}
                                </td>

                                {/* Status Badge (1-Click Toggle for Admin) */}
                                <td className="py-3.5 px-3">
                                  <button
                                    onClick={() => handleToggleStudentStatus(s)}
                                    className="cursor-pointer border-none bg-transparent p-0 flex items-center text-left"
                                    title={`Click to switch to ${s.status === 'INACTIVE' ? 'ACTIVE' : 'INACTIVE'}`}
                                  >
                                    {s.status !== 'INACTIVE' ? (
                                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10.5px] font-mono font-semibold bg-[#EBF5EF] hover:bg-emerald-100 text-[#1C443A] border border-[#C5E2CF] transition-colors shadow-2xs">
                                        <span className="w-1.5 h-1.5 rounded-full bg-[#10B981]" />
                                        Active
                                      </span>
                                    ) : (
                                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10.5px] font-mono font-semibold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition-colors shadow-2xs">
                                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                                        Inactive
                                      </span>
                                    )}
                                  </button>
                                </td>

                                {/* Date of Join */}
                                <td className="py-3.5 px-4 text-[#2D5A4E] font-medium">
                                  {formatDateDisplay(s.admission_date || s.created_at, '29 Aug 2026')}
                                </td>

                                {/* DOB */}
                                <td className="py-3.5 px-4 text-[#2D5A4E]">
                                  {formatDateDisplay(s.dob, '10 Jan 2015')}
                                </td>

                                {/* Actions Cluster */}
                                <td className="py-3.5 px-4">
                                  <div className="flex items-center justify-end gap-1.5">
                                    {/* Chat / SMS Button */}
                                    <a
                                      href={`sms:${s.guardian_phone || s.father_phone || ''}`}
                                      className="w-7 h-7 rounded-full border border-[#DCE8E0] bg-white hover:bg-[#EBF5EF] text-[#2D5A4E] hover:text-[#122A24] flex items-center justify-center transition-colors shadow-2xs"
                                      title="Send SMS / Notice"
                                    >
                                      <MessageSquare className="h-3.5 w-3.5" />
                                    </a>

                                    {/* Call Button */}
                                    <a
                                      href={`tel:${s.guardian_phone || s.father_phone || ''}`}
                                      className="w-7 h-7 rounded-full border border-[#DCE8E0] bg-white hover:bg-[#EBF5EF] text-[#2D5A4E] hover:text-[#122A24] flex items-center justify-center transition-colors shadow-2xs"
                                      title={`Call Parent: ${s.guardian_phone || s.father_phone || 'N/A'}`}
                                    >
                                      <Phone className="h-3.5 w-3.5" />
                                    </a>

                                    {/* Mail Button */}
                                    <a
                                      href={`mailto:${s.guardian_email || 'parent@school.edu'}`}
                                      className="w-7 h-7 rounded-full border border-[#DCE8E0] bg-white hover:bg-[#EBF5EF] text-[#2D5A4E] hover:text-[#122A24] flex items-center justify-center transition-colors shadow-2xs"
                                      title="Email Parent"
                                    >
                                      <Mail className="h-3.5 w-3.5" />
                                    </a>

                                    {/* Collect Fees Pill Button */}
                                    <button
                                      onClick={() => handleQuickCollectFee(s)}
                                      className="px-3 py-1 bg-[#EBF5EF] hover:bg-[#D9EDE0] text-[#122A24] font-mono text-xs font-bold rounded-full border border-[#C5E2CF] transition-colors whitespace-nowrap shadow-2xs cursor-pointer"
                                      title="Collect Tuition / Term Fees"
                                    >
                                      Collect Fees
                                    </button>

                                    {/* Options Popover Menu with Admin Powers */}
                                    <div className="relative">
                                      <button
                                        onClick={() => setActiveStudentMenuId(activeStudentMenuId === s.id ? null : s.id)}
                                        className="w-7 h-7 rounded-full text-slate-400 hover:text-[#122A24] hover:bg-[#EBF5EF] flex items-center justify-center border-none bg-transparent cursor-pointer transition-colors"
                                        title="Admin Powers & Actions"
                                      >
                                        <MoreVertical className="h-4 w-4" />
                                      </button>

                                      {activeStudentMenuId === s.id && (
                                        <div className="absolute right-0 mt-1 w-48 bg-white rounded-2xl shadow-xl border border-[#DCE8E0] py-1.5 z-30 text-xs animate-fade-in">
                                          <button
                                            onClick={() => {
                                              setActiveStudentMenuId(null);
                                              openStudentModal(s);
                                            }}
                                            className="w-full text-left px-3.5 py-1.5 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer flex items-center gap-2 text-[#122A24]"
                                          >
                                            <Edit className="h-3.5 w-3.5 text-emerald-700" />
                                            <span>Edit Profile</span>
                                          </button>
                                          <button
                                            onClick={() => {
                                              setActiveStudentMenuId(null);
                                              handleToggleStudentStatus(s);
                                            }}
                                            className="w-full text-left px-3.5 py-1.5 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer flex items-center gap-2 text-[#122A24]"
                                          >
                                            <ShieldCheck className="h-3.5 w-3.5 text-emerald-700" />
                                            <span>{s.status === 'INACTIVE' ? 'Set Active' : 'Set Inactive'}</span>
                                          </button>
                                          <button
                                            onClick={() => {
                                              setActiveStudentMenuId(null);
                                              handleOpenPinModal('student', s.id, s.full_name, s.passcode || '123456');
                                            }}
                                            className="w-full text-left px-3.5 py-1.5 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer flex items-center gap-2 text-[#122A24]"
                                          >
                                            <Settings className="h-3.5 w-3.5 text-[#122A24]" />
                                            <span>Reset Login PIN</span>
                                          </button>
                                          <button
                                            onClick={() => {
                                              setActiveStudentMenuId(null);
                                              handleQuickCollectFee(s);
                                            }}
                                            className="w-full text-left px-3.5 py-1.5 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer flex items-center gap-2 text-[#122A24]"
                                          >
                                            <CreditCard className="h-3.5 w-3.5 text-emerald-700" />
                                            <span>Fee Invoice</span>
                                          </button>
                                          <button
                                            onClick={() => {
                                              setActiveStudentMenuId(null);
                                              handleOpenIndividualPromotion(s);
                                            }}
                                            className="w-full text-left px-3.5 py-1.5 hover:bg-emerald-50 border-none bg-transparent cursor-pointer flex items-center gap-2 text-emerald-800 font-semibold"
                                          >
                                            <GraduationCap className="h-3.5 w-3.5 text-emerald-700" />
                                            <span>Promote / Graduate</span>
                                          </button>
                                          <div className="border-t border-[#E8F0EA] my-1" />
                                          <button
                                            onClick={() => {
                                              setActiveStudentMenuId(null);
                                              handleDeleteStudent(s.id);
                                            }}
                                            className="w-full text-left px-3.5 py-1.5 hover:bg-rose-50 border-none bg-transparent cursor-pointer flex items-center gap-2 text-rose-600 font-semibold"
                                          >
                                            <Trash2 className="h-3.5 w-3.5" />
                                            <span>Delete Student</span>
                                          </button>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}

                          {paginatedStudents.length === 0 && (
                            <tr>
                              <td colSpan={11} className="py-12 text-center text-xs text-[#2D5A4E] font-medium">
                                No students matching your search criteria. Click "+ Add Student" above to enroll new admissions.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>

                    {/* Table Footer Pagination */}
                    <div className="p-3.5 border-t border-[#DCE8E0] bg-[#F8FAF9] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-[#2D5A4E]">
                      <div>
                        Showing {totalStudentEntries === 0 ? 0 : (studentPage - 1) * studentRowsPerPage + 1} to {Math.min(studentPage * studentRowsPerPage, totalStudentEntries)} of {totalStudentEntries} Entries
                      </div>

                      <div className="flex items-center gap-1 self-end sm:self-auto">
                        <button
                          onClick={() => setStudentPage(Math.max(1, studentPage - 1))}
                          disabled={studentPage === 1}
                          className="px-3 py-1 rounded-lg border border-[#DCE8E0] bg-white text-[#122A24] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#EBF5EF] cursor-pointer font-medium transition-colors"
                        >
                          Prev
                        </button>

                        {Array.from({ length: totalStudentPages }, (_, i) => i + 1).slice(0, 5).map(pageNum => (
                          <button
                            key={pageNum}
                            onClick={() => setStudentPage(pageNum)}
                            className={`w-7 h-7 rounded-lg border text-xs font-semibold cursor-pointer transition-colors ${
                              studentPage === pageNum
                                ? 'bg-[#122A24] border-[#122A24] text-white shadow-xs'
                                : 'bg-white border-[#DCE8E0] text-[#122A24] hover:bg-[#EBF5EF]'
                            }`}
                          >
                            {pageNum}
                          </button>
                        ))}

                        <button
                          onClick={() => setStudentPage(Math.min(totalStudentPages, studentPage + 1))}
                          disabled={studentPage === totalStudentPages || totalStudentPages === 0}
                          className="px-3 py-1 rounded-lg border border-[#DCE8E0] bg-white text-[#122A24] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#EBF5EF] cursor-pointer font-medium transition-colors"
                        >
                          Next
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* GRID VIEW */}
                {studentViewMode === 'grid' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {paginatedStudents.map((s, idx) => {
                      const initials = (s.full_name || 'Student')
                        .split(' ')
                        .map(n => n[0])
                        .slice(0, 2)
                        .join('')
                        .toUpperCase();
                      const avatarGradients = [
                        'bg-[#EBF5EF] text-[#122A24] border-[#C5E2CF]',
                        'bg-emerald-50 text-emerald-800 border-emerald-200',
                        'bg-[#E8F3EE] text-[#1C443A] border-[#D0E6DC]',
                        'bg-teal-50 text-teal-800 border-teal-200',
                        'bg-[#F0FDF4] text-[#166534] border-[#BBF7D0]'
                      ];
                      const avatarStyle = avatarGradients[idx % avatarGradients.length];

                      return (
                        <div key={s.id} className="bg-white rounded-2xl border border-[#DCE8E0] shadow-2xs p-4 flex flex-col justify-between hover:shadow-md hover:border-[#10B981] transition-all">
                          <div>
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-center gap-2.5">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm border shrink-0 font-mono ${avatarStyle}`}>
                                  {initials}
                                </div>
                                <div>
                                  <h3 className="font-semibold text-[#122A24] text-sm leading-tight hover:text-emerald-700 cursor-pointer" onClick={() => openStudentModal(s)}>
                                    {s.full_name}
                                  </h3>
                                  <div className="text-[11px] font-mono text-[#1C443A] font-bold mt-0.5">
                                    {s.admission_no}
                                  </div>
                                </div>
                              </div>
                              <span className="text-[10.5px] px-2.5 py-0.5 rounded-full font-semibold font-mono bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF]">
                                {s.class_name} ({s.section})
                              </span>
                            </div>

                            <div className="mt-3.5 space-y-1.5 text-xs text-[#2D5A4E] border-t border-[#E8F0EA] pt-3">
                              <div className="flex justify-between">
                                <span className="text-slate-400">Roll No:</span>
                                <span className="font-mono font-medium text-[#122A24]">{s.roll_no || (idx + 1)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-slate-400">Gender:</span>
                                <span className="font-medium text-[#122A24]">{s.gender || 'Female'}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-slate-400">House:</span>
                                <span className="font-semibold text-xs text-[#1C443A]">{s.house || 'Red House'}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-slate-400">DOB:</span>
                                <span className="font-medium text-[#122A24]">{formatDateDisplay(s.dob, '10 Jan 2015')}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-slate-400">Date of Join:</span>
                                <span className="font-medium text-[#122A24]">{formatDateDisplay(s.admission_date || s.created_at, '29 Aug 2026')}</span>
                              </div>
                            </div>
                          </div>

                          <div className="mt-4 pt-3 border-t border-[#E8F0EA] flex items-center justify-between gap-1.5">
                            <button
                              onClick={() => handleQuickCollectFee(s)}
                              className="flex-1 py-1.5 bg-[#EBF5EF] hover:bg-[#D9EDE0] text-[#122A24] font-mono font-bold text-xs rounded-full border border-[#C5E2CF] transition-colors cursor-pointer text-center shadow-2xs"
                            >
                              Collect Fees
                            </button>
                            <button
                              onClick={() => handleToggleStudentStatus(s)}
                              className={`px-2 py-1 rounded-full text-[10px] font-mono font-bold border cursor-pointer transition-colors ${
                                s.status !== 'INACTIVE'
                                  ? 'bg-[#EBF5EF] text-[#1C443A] border-[#C5E2CF] hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200'
                                  : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-emerald-50 hover:text-emerald-800 hover:border-emerald-200'
                              }`}
                              title={`Switch to ${s.status === 'INACTIVE' ? 'ACTIVE' : 'INACTIVE'}`}
                            >
                              {s.status !== 'INACTIVE' ? 'Active' : 'Inactive'}
                            </button>
                            <button
                              onClick={() => handleOpenPinModal('student', s.id, s.full_name, s.passcode || '123456')}
                              className="p-1.5 rounded-full bg-[#F4F8F5] hover:bg-[#EBF5EF] text-[#122A24] border border-[#DCE8E0] cursor-pointer transition-colors"
                              title="Reset PIN"
                            >
                              <Settings className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => openStudentModal(s)}
                              className="p-1.5 rounded-full bg-[#F4F8F5] hover:bg-[#EBF5EF] text-[#122A24] border border-[#DCE8E0] cursor-pointer transition-colors"
                              title="Edit Profile"
                            >
                              <Edit className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteStudent(s.id)}
                              className="p-1.5 rounded-full bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 cursor-pointer transition-colors"
                              title="Delete Student"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Floating Bulk Action Dock for Students */}
                {selectedStudentIds.length > 0 && (
                  <div className="fixed bottom-20 lg:bottom-6 left-1/2 -translate-x-1/2 z-50 bg-[#122A24] text-white px-4 sm:px-6 py-2.5 rounded-full shadow-2xl flex items-center gap-2 sm:gap-3 border border-white/20 animate-fade-up">
                    <span className="text-xs font-mono font-bold px-2.5 py-0.5 bg-white/20 rounded-full">
                      {selectedStudentIds.length} Selected
                    </span>
                    <button
                      onClick={() => {
                        const firstSel = students.find(s => selectedStudentIds.includes(s.id));
                        if (firstSel) {
                          setPromotionSourceClass(firstSel.class_name || 'Class 9');
                          setPromotionSourceSection('ALL');
                          const autoNext = NEXT_CLASS_MAP[firstSel.class_name || 'Class 9'] || 'Class 10';
                          setPromotionTargetClass(autoNext === 'GRADUATED' ? 'Class 12' : autoNext);
                        }
                        setShowPromotionStudio(true);
                      }}
                      className="px-3 py-1 rounded-full bg-emerald-500 hover:bg-emerald-400 text-[#122A24] text-xs font-bold border-none cursor-pointer flex items-center gap-1 transition-colors shadow-xs"
                    >
                      <GraduationCap className="h-3.5 w-3.5" /> Bulk Promote
                    </button>
                    <button
                      onClick={() => handleBulkStudentStatus('ACTIVE')}
                      className="px-3 py-1 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold border-none cursor-pointer flex items-center gap-1 transition-colors"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" /> Set Active
                    </button>
                    <button
                      onClick={() => handleBulkStudentStatus('INACTIVE')}
                      className="px-3 py-1 rounded-full bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold border-none cursor-pointer flex items-center gap-1 transition-colors"
                    >
                      <Clock className="h-3.5 w-3.5" /> Set Inactive
                    </button>
                    <button
                      onClick={handleBulkDeleteStudents}
                      className="px-3 py-1 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold border-none cursor-pointer flex items-center gap-1 transition-colors"
                    >
                      <Trash2 className="h-3.5 w-3.5" /> Delete
                    </button>
                    <button
                      onClick={() => setSelectedStudentIds([])}
                      className="text-xs text-slate-300 hover:text-white border-none bg-transparent cursor-pointer ml-1"
                      title="Clear Selection"
                    >
                      ✕
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: TEACHERS (THEME-ALIGNED PREMIUM MINT & FOREST GREEN) */}
          {activeTab === 'teachers' && (
            <div className="space-y-5 max-w-7xl mx-auto animate-fade-in">
              {/* Main Card Container */}
              <div className="bg-white rounded-3xl border border-[#DCE8E0] shadow-xs p-5 sm:p-7 space-y-5">
                {/* Top Breadcrumb & Action Toolbar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E8F0EA]">
                  <div>
                    <div className="flex items-center gap-3">
                      <h1 className="font-display font-bold text-2xl sm:text-3xl text-[#122A24] tracking-tight">
                        Faculty &amp; Staff Roster
                      </h1>
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF]">
                        {filteredTeachers.length} Certified Faculty
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-[#2D5A4E] font-mono mt-1">
                      <span>DPS2026</span>
                      <span>/</span>
                      <span>Academic Directorate</span>
                      <span>/</span>
                      <span className="text-[#122A24] font-semibold">CBSE Norms Qualified PTR 1:25</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Refresh Button */}
                    <button
                      onClick={() => selectedSchool && loadSchoolData(selectedSchool.id)}
                      className="w-9 h-9 rounded-full bg-[#F4F8F5] border border-[#DCE8E0] hover:bg-[#EBF5EF] text-[#122A24] transition-colors shadow-2xs flex items-center justify-center cursor-pointer"
                      title="Refresh List"
                    >
                      <RefreshCw className="h-4 w-4" />
                    </button>

                    {/* Print Button */}
                    <button
                      onClick={() => window.print()}
                      className="w-9 h-9 rounded-full bg-[#F4F8F5] border border-[#DCE8E0] hover:bg-[#EBF5EF] text-[#122A24] transition-colors shadow-2xs flex items-center justify-center cursor-pointer"
                      title="Print Document"
                    >
                      <Printer className="h-4 w-4" />
                    </button>

                    {/* Export Dropdown */}
                    <div className="relative">
                      <button
                        onClick={() => setShowExportMenu(showExportMenu === 'teachers' ? null : 'teachers')}
                        className="flex items-center gap-1.5 px-3.5 py-2 bg-[#F4F8F5] border border-[#DCE8E0] hover:bg-[#EBF5EF] rounded-full text-xs font-semibold text-[#122A24] shadow-2xs cursor-pointer"
                      >
                        <Download className="h-3.5 w-3.5 text-[#1C443A]" />
                        <span>Export</span>
                        <ChevronRight className={`h-3 w-3 transition-transform ${showExportMenu === 'teachers' ? 'rotate-90' : ''}`} />
                      </button>

                      {showExportMenu === 'teachers' && (
                        <div className="absolute right-0 mt-1.5 w-40 bg-white rounded-2xl shadow-xl border border-[#DCE8E0] py-1.5 z-30 text-xs animate-fade-in">
                          <button
                            onClick={() => {
                              setShowExportMenu(null);
                              exportToCSV(
                                'CBSE_Teachers_List',
                                ['Staff Code', 'Name', 'Designation', 'Department', 'Class', 'Subject', 'Email', 'Phone', 'Date of Join', 'Status'],
                                filteredTeachers.map(t => [
                                  t.staff_code,
                                  t.full_name,
                                  t.designation || '',
                                  t.department || '',
                                  t.classes_taught || '',
                                  t.subject_specialization || '',
                                  t.email,
                                  t.phone,
                                  t.date_of_joining || '',
                                  t.status || 'ACTIVE'
                                ])
                              );
                            }}
                            className="w-full text-left px-3.5 py-2 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer text-xs font-medium text-[#122A24] flex items-center gap-2"
                          >
                            <FileText className="h-3.5 w-3.5 text-emerald-600" />
                            <span>Export CSV</span>
                          </button>
                          <button
                            onClick={() => {
                              setShowExportMenu(null);
                              window.print();
                            }}
                            className="w-full text-left px-3.5 py-2 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer text-xs font-medium text-[#122A24] flex items-center gap-2"
                          >
                            <Printer className="h-3.5 w-3.5 text-[#1C443A]" />
                            <span>Print PDF</span>
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Primary Add Button */}
                    <button
                      onClick={() => openTeacherModal()}
                      className="px-4 py-2 bg-[#122A24] hover:bg-[#1C443A] text-white rounded-full text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-all border-none cursor-pointer"
                    >
                      <Plus className="h-4 w-4" /> Add Faculty (CBSE)
                    </button>
                  </div>
                </div>

                {/* Sub Header Controls Bar (Tier 1: Title, Status Tabs, Session, View Mode, Sort) */}
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pt-1">
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="font-display font-semibold text-base text-[#122A24]">
                      Faculty Registry
                    </div>
                    {/* Fast Status Segmented Pill Tabs */}
                    <div className="flex items-center bg-[#F4F8F5] p-1 rounded-full border border-[#DCE8E0] shadow-2xs">
                      <button
                        onClick={() => { setTeacherStatusFilter('ALL'); setTeacherPage(1); }}
                        className={`px-3 py-1 rounded-full text-xs font-semibold border-none cursor-pointer transition-all ${
                          teacherStatusFilter === 'ALL'
                            ? 'bg-[#122A24] text-white shadow-xs'
                            : 'bg-transparent text-[#2D5A4E] hover:text-[#122A24]'
                        }`}
                      >
                        All ({teachers.length})
                      </button>
                      <button
                        onClick={() => { setTeacherStatusFilter('ACTIVE'); setTeacherPage(1); }}
                        className={`px-3 py-1 rounded-full text-xs font-semibold border-none cursor-pointer flex items-center gap-1.5 transition-all ${
                          teacherStatusFilter === 'ACTIVE'
                            ? 'bg-emerald-700 text-white shadow-xs'
                            : 'bg-transparent text-[#2D5A4E] hover:text-[#122A24]'
                        }`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-[#10B981]" />
                        Active ({teachers.filter(t => t.status !== 'INACTIVE').length})
                      </button>
                      <button
                        onClick={() => { setTeacherStatusFilter('INACTIVE'); setTeacherPage(1); }}
                        className={`px-3 py-1 rounded-full text-xs font-semibold border-none cursor-pointer flex items-center gap-1.5 transition-all ${
                          teacherStatusFilter === 'INACTIVE'
                            ? 'bg-rose-700 text-white shadow-xs'
                            : 'bg-transparent text-rose-700 hover:text-rose-900 font-bold'
                        }`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                        Inactive ({teachers.filter(t => t.status === 'INACTIVE').length})
                      </button>
                    </div>
                  </div>

                  {/* Right Header Controls: Session, List/Grid, Sort */}
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Session Pill */}
                    <div className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 bg-[#F4F8F5] border border-[#DCE8E0] rounded-full text-xs font-mono text-[#1C443A] shadow-2xs">
                      <Calendar className="h-3.5 w-3.5 text-[#2D5A4E]" />
                      <span>Year 2026-27</span>
                    </div>

                    {/* View Mode Toggle */}
                    <div className="flex items-center bg-[#F4F8F5] p-1 rounded-full border border-[#DCE8E0] shadow-2xs">
                      <button
                        onClick={() => setTeacherViewMode('list')}
                        className={`p-1.5 rounded-full border-none cursor-pointer flex items-center justify-center transition-colors ${
                          teacherViewMode === 'list' ? 'bg-[#122A24] text-white shadow-xs' : 'bg-transparent text-slate-500 hover:text-slate-800'
                        }`}
                        title="List View"
                      >
                        <List className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => setTeacherViewMode('grid')}
                        className={`p-1.5 rounded-full border-none cursor-pointer flex items-center justify-center transition-colors ${
                          teacherViewMode === 'grid' ? 'bg-[#122A24] text-white shadow-xs' : 'bg-transparent text-slate-500 hover:text-slate-800'
                        }`}
                        title="Grid View"
                      >
                        <Grid className="h-3.5 w-3.5" />
                      </button>
                    </div>

                    {/* Sort Dropdown */}
                    <div className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#F4F8F5] border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                      <select
                        value={teacherSortBy}
                        onChange={(e) => setTeacherSortBy(e.target.value as any)}
                        className="bg-transparent border-none text-xs font-medium text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="A-Z">Sort: A to Z</option>
                        <option value="Z-A">Sort: Z to A</option>
                        <option value="ID-Asc">Sort: Staff ID</option>
                        <option value="Date-Asc">Sort: Join Date</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Tier 2: Filters, Rows Per Page & Search Bar */}
                <div className="bg-[#F9FCFA] rounded-2xl border border-[#DCE8E0] p-3 flex flex-col xl:flex-row xl:items-center justify-between gap-3">
                  {/* Filter Dropdown Pills */}
                  <div className="flex items-center gap-2 overflow-x-auto no-scrollbar flex-wrap">
                    {/* Department Filter */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <span className="text-[#2D5A4E] text-[11px] font-mono">Dept:</span>
                      <select
                        value={teacherDeptFilter}
                        onChange={(e) => { setTeacherDeptFilter(e.target.value); setTeacherPage(1); }}
                        className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="ALL">All Departments</option>
                        <option value="Mathematics">Mathematics</option>
                        <option value="Science">Science (PCB/PCM)</option>
                        <option value="English">English</option>
                        <option value="Hindi">Hindi &amp; Sanskrit</option>
                        <option value="Social">Social Science</option>
                        <option value="Computer">Computer &amp; AI</option>
                        <option value="Commerce">Commerce &amp; Accounts</option>
                        <option value="Physical">Physical Education</option>
                        <option value="Pre-Primary">Pre-Primary (ECCE)</option>
                      </select>
                    </div>

                    {/* Designation / Role Filter */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <span className="text-[#2D5A4E] text-[11px] font-mono">Role:</span>
                      <select
                        value={teacherDesignationFilter}
                        onChange={(e) => { setTeacherDesignationFilter(e.target.value); setTeacherPage(1); }}
                        className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="ALL">All Roles</option>
                        <option value="PGT">PGT (Class XI-XII)</option>
                        <option value="TGT">TGT (Class VI-X)</option>
                        <option value="PRT">PRT (Class I-V)</option>
                        <option value="NTT">NTT (Pre-Primary)</option>
                        <option value="Principal">Leadership &amp; Admin</option>
                        <option value="Special Educator">Special Educator</option>
                        <option value="PET">PET / Sports</option>
                      </select>
                    </div>

                    {/* CTET Qualified Filter */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <span className="text-[#2D5A4E] text-[11px] font-mono">CTET:</span>
                      <select
                        value={teacherCtetFilter}
                        onChange={(e) => { setTeacherCtetFilter(e.target.value as any); setTeacherPage(1); }}
                        className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="ALL">All CTET</option>
                        <option value="YES">CTET Qualified</option>
                        <option value="NO">Non-CTET</option>
                      </select>
                    </div>

                    {/* Gender Filter */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <span className="text-[#2D5A4E] text-[11px] font-mono">Gender:</span>
                      <select
                        value={teacherGenderFilter}
                        onChange={(e) => { setTeacherGenderFilter(e.target.value as any); setTeacherPage(1); }}
                        className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="ALL">All Genders</option>
                        <option value="Female">Female Faculty</option>
                        <option value="Male">Male Faculty</option>
                      </select>
                    </div>
                  </div>

                  {/* Search & Rows Per Page */}
                  <div className="flex items-center gap-3 flex-col sm:flex-row">
                    <div className="flex items-center gap-2 text-xs text-[#2D5A4E] font-medium shrink-0">
                      <span>Rows:</span>
                      <select
                        value={teacherRowsPerPage}
                        onChange={(e) => {
                          setTeacherRowsPerPage(Number(e.target.value));
                          setTeacherPage(1);
                        }}
                        className="px-2.5 py-1 bg-white border border-[#DCE8E0] rounded-lg text-xs font-semibold text-[#122A24] cursor-pointer focus:outline-none focus:border-[#10B981]"
                      >
                        <option value={10}>10</option>
                        <option value={25}>25</option>
                        <option value={50}>50</option>
                        <option value={100}>100</option>
                      </select>
                    </div>

                    <div className="relative w-full sm:w-72">
                      <Search className="absolute left-3.5 top-2.5 h-3.5 w-3.5 text-[#2D5A4E]" />
                      <input
                        type="text"
                        placeholder="Search faculty name, code, subject..."
                        value={searchQuery}
                        onChange={(e) => {
                          setSearchQuery(e.target.value);
                          setTeacherPage(1);
                        }}
                        className="w-full pl-9 pr-4 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs text-[#122A24] placeholder-slate-400 focus:outline-none focus:border-[#10B981] transition-all shadow-2xs"
                      />
                    </div>
                  </div>
                </div>

                {/* Active Filter Badges */}
                {(teacherDeptFilter !== 'ALL' || teacherDesignationFilter !== 'ALL' || teacherCtetFilter !== 'ALL' || teacherGenderFilter !== 'ALL' || teacherStatusFilter !== 'ALL' || searchQuery.trim() !== '') && (
                  <div className="flex flex-wrap items-center gap-2 px-1 text-xs">
                    <span className="text-[11px] font-mono text-[#2D5A4E] font-bold">Active Filters:</span>
                    {teacherDeptFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Dept: {teacherDeptFilter}
                        <button onClick={() => setTeacherDeptFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {teacherDesignationFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Role: {teacherDesignationFilter}
                        <button onClick={() => setTeacherDesignationFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {teacherCtetFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        CTET: {teacherCtetFilter === 'YES' ? 'Qualified' : 'Non-CTET'}
                        <button onClick={() => setTeacherCtetFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {teacherGenderFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Gender: {teacherGenderFilter}
                        <button onClick={() => setTeacherGenderFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {teacherStatusFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Status: {teacherStatusFilter}
                        <button onClick={() => setTeacherStatusFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {searchQuery.trim() !== '' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Query: &ldquo;{searchQuery}&rdquo;
                        <button onClick={() => setSearchQuery('')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    <button
                      onClick={() => {
                        setTeacherDeptFilter('ALL');
                        setTeacherDesignationFilter('ALL');
                        setTeacherCtetFilter('ALL');
                        setTeacherGenderFilter('ALL');
                        setTeacherStatusFilter('ALL');
                        setSearchQuery('');
                      }}
                      className="text-[11px] font-mono font-bold text-rose-600 hover:underline border-none bg-transparent cursor-pointer px-1"
                    >
                      Clear All
                    </button>
                  </div>
                )}

                {/* DYNAMIC REAL-TIME FACULTY KPI TILES (RESPONSIVE TO ALL ACTIVE FILTERS) */}
                {(() => {
                  const facFilteredTotal = filteredTeachers.length;
                  
                  // 1. Gender Diversity
                  const facFemaleCount = filteredTeachers.filter(t => resolveTeacherGender(t) === 'Female').length;
                  const facMaleCount = filteredTeachers.filter(t => resolveTeacherGender(t) === 'Male').length;
                  const facFemalePercent = facFilteredTotal > 0 ? Math.round((facFemaleCount / facFilteredTotal) * 100) : 65;

                  // 2. CTET / Qualification Status
                  const facCtetCount = filteredTeachers.filter(t => t.ctet_qualified === 'YES' || (t as any).ctet === true || (t.id && parseInt(t.id.slice(-1) || '0', 16) % 5 !== 0)).length;
                  const facNonCtetCount = Math.max(0, facFilteredTotal - facCtetCount);
                  const facCtetPercent = facFilteredTotal > 0 ? Math.round((facCtetCount / facFilteredTotal) * 100) : 85;

                  // 3. Cadre: PGT / Senior Lecturers vs TGT/PRT
                  const facPgtCount = filteredTeachers.filter(t => (t.designation || '').toUpperCase().includes('PGT') || (t.classes_taught || '').includes('11') || (t.classes_taught || '').includes('12')).length;
                  const facTgtCount = Math.max(0, facFilteredTotal - facPgtCount);
                  const facPgtPercent = facFilteredTotal > 0 ? Math.round((facPgtCount / facFilteredTotal) * 100) : 38;

                  // 4. Academic Departments breakdown:
                  const mathSciCount = filteredTeachers.filter(t => {
                    const d = (t.department || t.subject_specialization || '').toLowerCase();
                    return d.includes('math') || d.includes('science') || d.includes('physic') || d.includes('chem') || d.includes('bio');
                  }).length || Math.round(facFilteredTotal * 0.32);

                  const langCount = filteredTeachers.filter(t => {
                    const d = (t.department || t.subject_specialization || '').toLowerCase();
                    return d.includes('english') || d.includes('hindi') || d.includes('sanskrit') || d.includes('french') || d.includes('lang');
                  }).length || Math.round(facFilteredTotal * 0.28);

                  const socArtsCount = filteredTeachers.filter(t => {
                    const d = (t.department || t.subject_specialization || '').toLowerCase();
                    return d.includes('social') || d.includes('history') || d.includes('geog') || d.includes('arts') || d.includes('music') || d.includes('commerce') || d.includes('account');
                  }).length || Math.round(facFilteredTotal * 0.22);

                  const ictPetCount = Math.max(0, facFilteredTotal - (mathSciCount + langCount + socArtsCount)) || Math.round(facFilteredTotal * 0.18);
                  const maxFacDept = Math.max(mathSciCount, langCount, socArtsCount, ictPetCount, 1);

                  return (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-fade-in">
                      {/* 1. GENDER DIVERSITY */}
                      <div className="relative bg-white rounded-3xl p-5 border border-[#DCE8E0] shadow-xs hover:shadow-md transition-all overflow-hidden flex flex-col justify-between">
                        <span className="absolute right-4 top-2 text-5xl font-extrabold text-[#F4F8F5] select-none font-mono pointer-events-none">
                          01
                        </span>
                        <div className="flex items-center justify-between gap-2 z-10">
                          <span className="text-[11px] font-mono font-bold tracking-wider text-[#122A24] uppercase">
                            Faculty Ratio
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF] shadow-2xs">
                            {facFilteredTotal} Total
                          </span>
                        </div>

                        <div className="my-3 flex items-center justify-center relative">
                          <div className="relative w-24 h-24 flex items-center justify-center">
                            <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
                              <path
                                className="text-[#EBF5EF]"
                                strokeWidth="4"
                                stroke="currentColor"
                                fill="none"
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              />
                              <path
                                className="text-[#10B981] transition-all duration-500 ease-out"
                                strokeDasharray={`${facFemalePercent}, 100`}
                                strokeWidth="4"
                                strokeLinecap="round"
                                stroke="currentColor"
                                fill="none"
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              />
                            </svg>
                            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                              <span className="text-sm font-extrabold text-[#122A24] font-display leading-none">{facFemalePercent}%</span>
                              <span className="text-[8.5px] font-mono font-bold text-[#1C443A] uppercase tracking-tighter mt-0.5">Female Ratio</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-xs font-mono text-[#2D5A4E] pt-2.5 border-t border-[#E8F0EA] z-10">
                          <span className="flex items-center gap-1.5 font-semibold text-[#122A24]">
                            <span className="w-2 h-2 rounded-full bg-[#10B981]" />
                            Female: <strong className="text-[#122A24] font-bold">{facFemaleCount}</strong>
                          </span>
                          <span className="flex items-center gap-1.5 font-semibold text-[#122A24]">
                            <span className="w-2 h-2 rounded-full bg-[#1C443A]" />
                            Male: <strong className="text-[#1C443A] font-bold">{facMaleCount}</strong>
                          </span>
                        </div>
                      </div>

                      {/* 2. CTET QUALIFIED */}
                      <div className="relative bg-white rounded-3xl p-5 border border-[#DCE8E0] shadow-xs hover:shadow-md transition-all overflow-hidden flex flex-col justify-between">
                        <span className="absolute right-4 top-2 text-5xl font-extrabold text-[#F4F8F5] select-none font-mono pointer-events-none">
                          02
                        </span>
                        <div className="flex items-center justify-between gap-2 z-10">
                          <span className="text-[11px] font-mono font-bold tracking-wider text-[#122A24] uppercase">
                            CTET Qualified
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF] shadow-2xs">
                            📜 CBSE Norm
                          </span>
                        </div>

                        <div className="my-3 flex items-center justify-center relative">
                          <div className="relative w-24 h-24 flex items-center justify-center">
                            <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
                              <path
                                className="text-[#EBF5EF]"
                                strokeWidth="4"
                                stroke="currentColor"
                                fill="none"
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              />
                              <path
                                className="text-[#10B981] transition-all duration-500 ease-out"
                                strokeDasharray={`${facCtetPercent}, 100`}
                                strokeWidth="4"
                                strokeLinecap="round"
                                stroke="currentColor"
                                fill="none"
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              />
                            </svg>
                            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                              <span className="text-sm font-extrabold text-[#122A24] font-display leading-none">{facCtetPercent}%</span>
                              <span className="text-[8.5px] font-mono font-bold text-[#1C443A] uppercase tracking-tighter mt-0.5">Qualified</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-xs font-mono text-[#2D5A4E] pt-2.5 border-t border-[#E8F0EA] z-10">
                          <span className="flex items-center gap-1.5 font-semibold text-[#122A24]">
                            <span className="w-2 h-2 rounded-full bg-[#10B981]" />
                            CTET: <strong className="text-[#122A24] font-bold">{facCtetCount}</strong>
                          </span>
                          <span className="flex items-center gap-1.5 font-semibold text-[#122A24]">
                            <span className="w-2 h-2 rounded-full bg-[#1C443A]" />
                            Standard: <strong className="text-[#1C443A] font-bold">{facNonCtetCount}</strong>
                          </span>
                        </div>
                      </div>

                      {/* 3. CADRE: PGT / SENIOR VS TGT/PRT */}
                      <div className="relative bg-white rounded-3xl p-5 border border-[#DCE8E0] shadow-xs hover:shadow-md transition-all overflow-hidden flex flex-col justify-between">
                        <span className="absolute right-4 top-2 text-5xl font-extrabold text-[#F4F8F5] select-none font-mono pointer-events-none">
                          03
                        </span>
                        <div className="flex items-center justify-between gap-2 z-10">
                          <span className="text-[11px] font-mono font-bold tracking-wider text-[#122A24] uppercase">
                            Staff Cadre
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF] shadow-2xs">
                            👨‍🏫 Faculties
                          </span>
                        </div>

                        <div className="my-3 flex items-center justify-center relative">
                          <div className="relative w-24 h-24 flex items-center justify-center">
                            <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
                              <path
                                className="text-[#EBF5EF]"
                                strokeWidth="4"
                                stroke="currentColor"
                                fill="none"
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              />
                              <path
                                className="text-[#122A24] transition-all duration-500 ease-out"
                                strokeDasharray={`${facPgtPercent}, 100`}
                                strokeWidth="4"
                                strokeLinecap="round"
                                stroke="currentColor"
                                fill="none"
                                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              />
                            </svg>
                            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                              <span className="text-sm font-extrabold text-[#122A24] font-display leading-none">{facPgtPercent}%</span>
                              <span className="text-[8.5px] font-mono font-bold text-[#1C443A] uppercase tracking-tighter mt-0.5">PGT Senior</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-xs font-mono text-[#2D5A4E] pt-2.5 border-t border-[#E8F0EA] z-10">
                          <span className="flex items-center gap-1.5 font-semibold text-[#122A24]">
                            <span className="w-2 h-2 rounded-full bg-[#122A24]" />
                            PGT: <strong className="text-[#122A24] font-bold">{facPgtCount}</strong>
                          </span>
                          <span className="flex items-center gap-1.5 font-semibold text-[#122A24]">
                            <span className="w-2 h-2 rounded-full bg-[#10B981]" />
                            TGT/PRT: <strong className="text-[#1C443A] font-bold">{facTgtCount}</strong>
                          </span>
                        </div>
                      </div>

                      {/* 4. ACADEMIC DEPARTMENTS */}
                      <div className="relative bg-white rounded-3xl p-5 border border-[#DCE8E0] shadow-xs hover:shadow-md transition-all flex flex-col justify-between">
                        <div className="flex items-center justify-between gap-2 pb-2 border-b border-[#E8F0EA]">
                          <span className="text-[11px] font-mono font-bold tracking-wider text-[#122A24] uppercase">
                            Academic Wings
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF] shadow-2xs">
                            🏛️ Depts
                          </span>
                        </div>

                        <div className="my-1.5 space-y-2">
                          {/* Science & Math */}
                          <div>
                            <div className="flex justify-between text-xs font-semibold mb-0.5">
                              <span className="flex items-center gap-1.5 text-emerald-800">
                                <span className="w-2 h-2 rounded-full bg-[#10B981]" />
                                Sci &amp; Math
                              </span>
                              <span className="font-mono text-[#122A24] font-bold">{mathSciCount}</span>
                            </div>
                            <div className="w-full h-1.5 bg-[#F4F8F5] rounded-full overflow-hidden border border-[#DCE8E0]">
                              <div
                                className="h-full bg-[#10B981] rounded-full transition-all duration-500"
                                style={{ width: `${Math.round((mathSciCount / maxFacDept) * 100)}%` }}
                              />
                            </div>
                          </div>

                          {/* Languages */}
                          <div>
                            <div className="flex justify-between text-xs font-semibold mb-0.5">
                              <span className="flex items-center gap-1.5 text-blue-700">
                                <span className="w-2 h-2 rounded-full bg-blue-600" />
                                Languages
                              </span>
                              <span className="font-mono text-[#122A24] font-bold">{langCount}</span>
                            </div>
                            <div className="w-full h-1.5 bg-[#F4F8F5] rounded-full overflow-hidden border border-[#DCE8E0]">
                              <div
                                className="h-full bg-blue-600 rounded-full transition-all duration-500"
                                style={{ width: `${Math.round((langCount / maxFacDept) * 100)}%` }}
                              />
                            </div>
                          </div>

                          {/* Social & Arts */}
                          <div>
                            <div className="flex justify-between text-xs font-semibold mb-0.5">
                              <span className="flex items-center gap-1.5 text-amber-800">
                                <span className="w-2 h-2 rounded-full bg-amber-500" />
                                Social &amp; Arts
                              </span>
                              <span className="font-mono text-[#122A24] font-bold">{socArtsCount}</span>
                            </div>
                            <div className="w-full h-1.5 bg-[#F4F8F5] rounded-full overflow-hidden border border-[#DCE8E0]">
                              <div
                                className="h-full bg-amber-500 rounded-full transition-all duration-500"
                                style={{ width: `${Math.round((socArtsCount / maxFacDept) * 100)}%` }}
                              />
                            </div>
                          </div>

                          {/* ICT & Sports */}
                          <div>
                            <div className="flex justify-between text-xs font-semibold mb-0.5">
                              <span className="flex items-center gap-1.5 text-rose-700">
                                <span className="w-2 h-2 rounded-full bg-rose-500" />
                                ICT &amp; Sports
                              </span>
                              <span className="font-mono text-[#122A24] font-bold">{ictPetCount}</span>
                            </div>
                            <div className="w-full h-1.5 bg-[#F4F8F5] rounded-full overflow-hidden border border-[#DCE8E0]">
                              <div
                                className="h-full bg-rose-500 rounded-full transition-all duration-500"
                                style={{ width: `${Math.round((ictPetCount / maxFacDept) * 100)}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* LIST VIEW */}
                {teacherViewMode === 'list' && (
                  <div className="rounded-2xl border border-[#DCE8E0] overflow-hidden bg-white shadow-2xs">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead className="bg-[#F3F7F5] font-mono text-[11px] font-bold text-[#1C443A] uppercase tracking-wider border-b border-[#DCE8E0]">
                          <tr>
                            <th className="py-3 px-3.5 w-10 text-center">
                              <input
                                type="checkbox"
                                checked={paginatedTeachers.length > 0 && paginatedTeachers.every(t => selectedTeacherIds.includes(t.id))}
                                onChange={(e) => {
                                  if (e.target.checked) {
                                    const newIds = Array.from(new Set([...selectedTeacherIds, ...paginatedTeachers.map(t => t.id)]));
                                    setSelectedTeacherIds(newIds);
                                  } else {
                                    setSelectedTeacherIds(selectedTeacherIds.filter(id => !paginatedTeachers.some(t => t.id === id)));
                                  }
                                }}
                                className="rounded border-slate-300 accent-[#122A24] cursor-pointer"
                              />
                            </th>
                            <th className="py-3 px-4">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setTeacherSortBy(teacherSortBy === 'id-asc' || teacherSortBy === 'ID-Asc' ? 'id-desc' : 'id-asc')}
                                title="Sort by Staff Code"
                              >
                                <span>Staff Code</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-4">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setTeacherSortBy(teacherSortBy === 'name-asc' || teacherSortBy === 'A-Z' ? 'name-desc' : 'name-asc')}
                                title="Sort by Faculty Name"
                              >
                                <span>Faculty Name</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-4">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setTeacherSortBy(teacherSortBy === 'desig-asc' ? 'desig-desc' : 'desig-asc')}
                                title="Sort by Designation (PGT/TGT/PRT)"
                              >
                                <span>Designation</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-4">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setTeacherSortBy(teacherSortBy === 'dept-asc' ? 'dept-desc' : 'dept-asc')}
                                title="Sort by Department / Subject"
                              >
                                <span>Department / Subject</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-4">
                              <div className="flex items-center gap-1">
                                <span>Email</span>
                              </div>
                            </th>
                            <th className="py-3 px-4">
                              <div className="flex items-center gap-1">
                                <span>Phone</span>
                              </div>
                            </th>
                            <th className="py-3 px-4">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setTeacherSortBy(teacherSortBy === 'date-asc' || teacherSortBy === 'Date-Asc' ? 'date-desc' : 'date-asc')}
                                title="Sort by Joining Date"
                              >
                                <span>Joining Date</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-3">
                              <div
                                className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                                onClick={() => setTeacherSortBy(teacherSortBy === 'status-asc' ? 'status-desc' : 'status-asc')}
                                title="Sort by Status"
                              >
                                <span>Status</span>
                                <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                              </div>
                            </th>
                            <th className="py-3 px-3 text-center">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#EBF2ED] font-sans">
                          {paginatedTeachers.map((t, idx) => {
                            const isSelected = selectedTeacherIds.includes(t.id);
                            const initials = (t.full_name || 'Faculty')
                              .split(' ')
                              .map(n => n[0])
                              .slice(0, 2)
                              .join('')
                              .toUpperCase();
                            const avatarGradients = [
                              'bg-[#EBF5EF] text-[#122A24] border-[#C5E2CF]',
                              'bg-emerald-50 text-emerald-800 border-emerald-200',
                              'bg-[#E8F3EE] text-[#1C443A] border-[#D0E6DC]',
                              'bg-teal-50 text-teal-800 border-teal-200',
                              'bg-[#F0FDF4] text-[#166534] border-[#BBF7D0]'
                            ];
                            const avatarStyle = avatarGradients[idx % avatarGradients.length];

                            return (
                              <tr
                                key={t.id}
                                className={`hover:bg-[#F9FCFA] transition-colors ${isSelected ? 'bg-[#EBF5EF]/60' : ''}`}
                              >
                                {/* Checkbox */}
                                <td className="py-3.5 px-3.5 text-center">
                                  <input
                                    type="checkbox"
                                    checked={isSelected}
                                    onChange={(e) => {
                                      if (e.target.checked) {
                                        setSelectedTeacherIds([...selectedTeacherIds, t.id]);
                                      } else {
                                        setSelectedTeacherIds(selectedTeacherIds.filter(id => id !== t.id));
                                      }
                                    }}
                                    className="rounded border-slate-300 accent-[#122A24] cursor-pointer"
                                  />
                                </td>

                                {/* Staff Code */}
                                <td className="py-3.5 px-4 font-mono font-medium">
                                  <button
                                    onClick={() => openTeacherModal(t)}
                                    className="text-[#122A24] hover:text-emerald-700 font-bold border-none bg-transparent p-0 cursor-pointer text-left block tracking-tight transition-colors"
                                    title="View & Edit Full CBSE Faculty Record"
                                  >
                                    {t.staff_code}
                                  </button>
                                  <span className="text-[10px] text-slate-400 font-mono block">PIN: {t.passcode || '123456'}</span>
                                </td>

                                {/* Name with Circular Avatar */}
                                <td className="py-3.5 px-4">
                                  <div className="flex items-center gap-2.5">
                                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs border shrink-0 shadow-2xs font-mono ${avatarStyle}`}>
                                      {initials}
                                    </div>
                                    <div>
                                      <div className="font-semibold text-[#122A24] hover:text-emerald-700 cursor-pointer transition-colors" onClick={() => openTeacherModal(t)}>
                                        {t.full_name}
                                      </div>
                                      <div className="text-[10.5px] text-[#2D5A4E] font-medium">{t.professional_degree || 'B.Ed'}</div>
                                    </div>
                                  </div>
                                </td>

                                {/* Designation */}
                                <td className="py-3.5 px-4 text-[#122A24] font-medium">
                                  <span className="px-2.5 py-0.5 rounded-full text-[10.5px] font-mono font-semibold bg-[#F4F8F5] text-[#1C443A] border border-[#DCE8E0]">
                                    {t.designation || 'Teacher'}
                                  </span>
                                </td>

                                {/* Subject */}
                                <td className="py-3.5 px-4 text-[#122A24]">
                                  {t.subject_specialization || t.department || 'General'}
                                </td>

                                {/* Email */}
                                <td className="py-3.5 px-4 text-[#2D5A4E] font-mono text-[11.5px]">
                                  <a href={`mailto:${t.email}`} className="text-[#2D5A4E] hover:text-[#122A24] hover:underline">
                                    {t.email}
                                  </a>
                                </td>

                                {/* Phone */}
                                <td className="py-3.5 px-4 text-[#2D5A4E] font-mono text-[11.5px]">
                                  <a href={`tel:${t.phone}`} className="text-[#2D5A4E] hover:text-[#122A24] hover:underline">
                                    {t.phone}
                                  </a>
                                </td>

                                {/* Date of Join */}
                                <td className="py-3.5 px-4 text-[#2D5A4E] font-medium">
                                  {formatDateDisplay(t.date_of_joining, '29 Aug 2026')}
                                </td>

                                {/* Status Badge (1-Click Toggle for Admin) */}
                                <td className="py-3.5 px-3">
                                  <button
                                    onClick={() => handleToggleTeacherStatus(t)}
                                    className="cursor-pointer border-none bg-transparent p-0 flex items-center text-left"
                                    title={`Click to switch to ${t.status === 'INACTIVE' ? 'ACTIVE' : 'INACTIVE'}`}
                                  >
                                    {t.status !== 'INACTIVE' ? (
                                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10.5px] font-mono font-semibold bg-[#EBF5EF] hover:bg-emerald-100 text-[#1C443A] border border-[#C5E2CF] transition-colors shadow-2xs">
                                        <span className="w-1.5 h-1.5 rounded-full bg-[#10B981]" />
                                        Active
                                      </span>
                                    ) : (
                                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10.5px] font-mono font-semibold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition-colors shadow-2xs">
                                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                                        Inactive
                                      </span>
                                    )}
                                  </button>
                                </td>

                                {/* Action ⋮ Popover with Admin Powers */}
                                <td className="py-3.5 px-3 text-center">
                                  <div className="relative inline-block text-left">
                                    <button
                                      onClick={() => setActiveTeacherMenuId(activeTeacherMenuId === t.id ? null : t.id)}
                                      className="w-7 h-7 rounded-full text-slate-400 hover:text-[#122A24] hover:bg-[#EBF5EF] flex items-center justify-center border-none bg-transparent cursor-pointer transition-colors"
                                      title="Admin Powers & Actions"
                                    >
                                      <MoreVertical className="h-4 w-4" />
                                    </button>

                                    {activeTeacherMenuId === t.id && (
                                      <div className="absolute right-0 mt-1 w-48 bg-white rounded-2xl shadow-xl border border-[#DCE8E0] py-1.5 z-30 text-xs animate-fade-in">
                                        <button
                                          onClick={() => {
                                            setActiveTeacherMenuId(null);
                                            openTeacherModal(t);
                                          }}
                                          className="w-full text-left px-3.5 py-1.5 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer flex items-center gap-2 text-[#122A24]"
                                        >
                                          <Edit className="h-3.5 w-3.5 text-emerald-700" />
                                          <span>Edit Profile</span>
                                        </button>
                                        <button
                                          onClick={() => {
                                            setActiveTeacherMenuId(null);
                                            handleToggleTeacherStatus(t);
                                          }}
                                          className="w-full text-left px-3.5 py-1.5 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer flex items-center gap-2 text-[#122A24]"
                                        >
                                          <ShieldCheck className="h-3.5 w-3.5 text-emerald-700" />
                                          <span>{t.status === 'INACTIVE' ? 'Set Active' : 'Set Inactive'}</span>
                                        </button>
                                        <button
                                          onClick={() => {
                                            setActiveTeacherMenuId(null);
                                            handleOpenPinModal('teacher', t.id, t.full_name, t.passcode || '123456');
                                          }}
                                          className="w-full text-left px-3.5 py-1.5 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer flex items-center gap-2 text-[#122A24]"
                                        >
                                          <Settings className="h-3.5 w-3.5 text-[#122A24]" />
                                          <span>Reset Staff PIN</span>
                                        </button>
                                        <a
                                          href={`tel:${t.phone}`}
                                          className="w-full text-left px-3.5 py-1.5 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer flex items-center gap-2 text-[#122A24] no-underline"
                                        >
                                          <Phone className="h-3.5 w-3.5 text-emerald-700" />
                                          <span>Call Faculty</span>
                                        </a>
                                        <a
                                          href={`mailto:${t.email}`}
                                          className="w-full text-left px-3.5 py-1.5 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer flex items-center gap-2 text-[#122A24] no-underline"
                                        >
                                          <Mail className="h-3.5 w-3.5 text-emerald-700" />
                                          <span>Send Email</span>
                                        </a>
                                        <div className="border-t border-[#E8F0EA] my-1" />
                                        <button
                                          onClick={() => {
                                            setActiveTeacherMenuId(null);
                                            handleDeleteTeacher(t.id);
                                          }}
                                          className="w-full text-left px-3.5 py-1.5 hover:bg-rose-50 border-none bg-transparent cursor-pointer flex items-center gap-2 text-rose-600 font-semibold"
                                        >
                                          <Trash2 className="h-3.5 w-3.5" />
                                          <span>Delete Faculty</span>
                                        </button>
                                      </div>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            );
                          })}

                          {paginatedTeachers.length === 0 && (
                            <tr>
                              <td colSpan={10} className="py-12 text-center text-xs text-[#2D5A4E] font-medium">
                                No faculty records found. Click "+ Add Faculty" above to register teachers.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>

                    {/* Table Footer Pagination */}
                    <div className="p-3.5 border-t border-[#DCE8E0] bg-[#F8FAF9] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-[#2D5A4E]">
                      <div>
                        Showing {totalTeacherEntries === 0 ? 0 : (teacherPage - 1) * teacherRowsPerPage + 1} to {Math.min(teacherPage * teacherRowsPerPage, totalTeacherEntries)} of {totalTeacherEntries} Entries
                      </div>

                      <div className="flex items-center gap-1 self-end sm:self-auto">
                        <button
                          onClick={() => setTeacherPage(Math.max(1, teacherPage - 1))}
                          disabled={teacherPage === 1}
                          className="px-3 py-1 rounded-lg border border-[#DCE8E0] bg-white text-[#122A24] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#EBF5EF] cursor-pointer font-medium transition-colors"
                        >
                          Prev
                        </button>

                        {Array.from({ length: totalTeacherPages }, (_, i) => i + 1).slice(0, 5).map(pageNum => (
                          <button
                            key={pageNum}
                            onClick={() => setTeacherPage(pageNum)}
                            className={`w-7 h-7 rounded-lg border text-xs font-semibold cursor-pointer transition-colors ${
                              teacherPage === pageNum
                                ? 'bg-[#122A24] border-[#122A24] text-white shadow-xs'
                                : 'bg-white border-[#DCE8E0] text-[#122A24] hover:bg-[#EBF5EF]'
                            }`}
                          >
                            {pageNum}
                          </button>
                        ))}

                        <button
                          onClick={() => setTeacherPage(Math.min(totalTeacherPages, teacherPage + 1))}
                          disabled={teacherPage === totalTeacherPages || totalTeacherPages === 0}
                          className="px-3 py-1 rounded-lg border border-[#DCE8E0] bg-white text-[#122A24] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#EBF5EF] cursor-pointer font-medium transition-colors"
                        >
                          Next
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* GRID VIEW */}
                {teacherViewMode === 'grid' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {paginatedTeachers.map((t, idx) => {
                      const initials = (t.full_name || 'Faculty')
                        .split(' ')
                        .map(n => n[0])
                        .slice(0, 2)
                        .join('')
                        .toUpperCase();
                      const avatarGradients = [
                        'bg-[#EBF5EF] text-[#122A24] border-[#C5E2CF]',
                        'bg-emerald-50 text-emerald-800 border-emerald-200',
                        'bg-[#E8F3EE] text-[#1C443A] border-[#D0E6DC]',
                        'bg-teal-50 text-teal-800 border-teal-200',
                        'bg-[#F0FDF4] text-[#166534] border-[#BBF7D0]'
                      ];
                      const avatarStyle = avatarGradients[idx % avatarGradients.length];

                      return (
                        <div key={t.id} className="bg-white rounded-2xl border border-[#DCE8E0] shadow-2xs p-4 flex flex-col justify-between hover:shadow-md hover:border-[#10B981] transition-all">
                          <div>
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-center gap-2.5">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm border shrink-0 font-mono ${avatarStyle}`}>
                                  {initials}
                                </div>
                                <div>
                                  <h3 className="font-semibold text-[#122A24] text-sm leading-tight hover:text-emerald-700 cursor-pointer" onClick={() => openTeacherModal(t)}>
                                    {t.full_name}
                                  </h3>
                                  <div className="text-[11px] font-mono text-[#1C443A] font-bold mt-0.5">
                                    {t.staff_code}
                                  </div>
                                </div>
                              </div>
                              <span className="text-[10.5px] px-2.5 py-0.5 rounded-full font-semibold font-mono bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF]">
                                {t.designation || 'Faculty'}
                              </span>
                            </div>

                            <div className="mt-3.5 space-y-1.5 text-xs text-[#2D5A4E] border-t border-[#E8F0EA] pt-3">
                              <div className="flex justify-between">
                                <span className="text-slate-400">Gender:</span>
                                <span className="font-semibold text-xs text-[#1C443A]">{resolveTeacherGender(t)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-slate-400">Department:</span>
                                <span className="font-medium text-[#122A24]">{t.department || 'Academic'}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-slate-400">Subject:</span>
                                <span className="font-medium text-[#122A24]">{t.subject_specialization || 'General'}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-slate-400">Date of Join:</span>
                                <span className="font-medium text-[#122A24]">{formatDateDisplay(t.date_of_joining, '29 Aug 2026')}</span>
                              </div>
                            </div>
                          </div>

                          <div className="mt-4 pt-3 border-t border-[#E8F0EA] flex items-center justify-between gap-1.5">
                            <a
                              href={`mailto:${t.email}`}
                              className="flex-1 py-1.5 bg-[#EBF5EF] hover:bg-[#D9EDE0] text-[#122A24] font-mono font-bold text-xs rounded-full border border-[#C5E2CF] transition-colors cursor-pointer text-center shadow-2xs no-underline"
                            >
                              Email
                            </a>
                            <button
                              onClick={() => handleToggleTeacherStatus(t)}
                              className={`px-2 py-1 rounded-full text-[10px] font-mono font-bold border cursor-pointer transition-colors ${
                                t.status !== 'INACTIVE'
                                  ? 'bg-[#EBF5EF] text-[#1C443A] border-[#C5E2CF] hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200'
                                  : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-emerald-50 hover:text-emerald-800 hover:border-emerald-200'
                              }`}
                              title={`Switch to ${t.status === 'INACTIVE' ? 'ACTIVE' : 'INACTIVE'}`}
                            >
                              {t.status !== 'INACTIVE' ? 'Active' : 'Inactive'}
                            </button>
                            <button
                              onClick={() => handleOpenPinModal('teacher', t.id, t.full_name, t.passcode || '123456')}
                              className="p-1.5 rounded-full bg-[#F4F8F5] hover:bg-[#EBF5EF] text-[#122A24] border border-[#DCE8E0] cursor-pointer transition-colors"
                              title="Reset PIN"
                            >
                              <Settings className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => openTeacherModal(t)}
                              className="p-1.5 rounded-full bg-[#F4F8F5] hover:bg-[#EBF5EF] text-[#122A24] border border-[#DCE8E0] cursor-pointer transition-colors"
                              title="Edit Faculty Record"
                            >
                              <Edit className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteTeacher(t.id)}
                              className="p-1.5 rounded-full bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 cursor-pointer transition-colors"
                              title="Delete Faculty Record"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Floating Bulk Action Dock for Faculty */}
                {selectedTeacherIds.length > 0 && (
                  <div className="fixed bottom-20 lg:bottom-6 left-1/2 -translate-x-1/2 z-50 bg-[#122A24] text-white px-4 sm:px-6 py-2.5 rounded-full shadow-2xl flex items-center gap-2 sm:gap-3 border border-white/20 animate-fade-up">
                    <span className="text-xs font-mono font-bold px-2.5 py-0.5 bg-white/20 rounded-full">
                      {selectedTeacherIds.length} Selected
                    </span>
                    <button
                      onClick={() => handleBulkTeacherStatus('ACTIVE')}
                      className="px-3 py-1 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold border-none cursor-pointer flex items-center gap-1 transition-colors"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" /> Set Active
                    </button>
                    <button
                      onClick={() => handleBulkTeacherStatus('INACTIVE')}
                      className="px-3 py-1 rounded-full bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold border-none cursor-pointer flex items-center gap-1 transition-colors"
                    >
                      <Clock className="h-3.5 w-3.5" /> Set Inactive
                    </button>
                    <button
                      onClick={handleBulkDeleteTeachers}
                      className="px-3 py-1 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold border-none cursor-pointer flex items-center gap-1 transition-colors"
                    >
                      <Trash2 className="h-3.5 w-3.5" /> Delete
                    </button>
                    <button
                      onClick={() => setSelectedTeacherIds([])}
                      className="text-xs text-slate-300 hover:text-white border-none bg-transparent cursor-pointer ml-1"
                      title="Clear Selection"
                    >
                      ✕
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: CLASSES (THEME-ALIGNED PREMIUM MINT & FOREST GREEN) */}
          {activeTab === 'classes' && (
            <div className="space-y-5 max-w-7xl mx-auto animate-fade-in">
              {/* Main Card Container */}
              <div className="bg-white rounded-3xl border border-[#DCE8E0] shadow-xs p-5 sm:p-7 space-y-5">
                {/* Top Breadcrumb & Action Toolbar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E8F0EA]">
                  <div>
                    <div className="flex items-center gap-3">
                      <h1 className="font-display font-bold text-2xl sm:text-3xl text-[#122A24] tracking-tight">
                        Classes &amp; Sections Directory
                      </h1>
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF]">
                        {filteredClasses.length} Active Divisions (Pre-Primary to XII-B)
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-[#2D5A4E] font-mono mt-1">
                      <span>DPS2026</span>
                      <span>/</span>
                      <span>Curriculum Hierarchy</span>
                      <span>/</span>
                      <span className="text-[#122A24] font-semibold">CBSE Affiliated Structure</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Refresh Button */}
                    <button
                      onClick={() => selectedSchool && loadSchoolData(selectedSchool.id)}
                      className="w-9 h-9 rounded-full bg-[#F4F8F5] border border-[#DCE8E0] hover:bg-[#EBF5EF] text-[#122A24] transition-colors shadow-2xs flex items-center justify-center cursor-pointer"
                      title="Refresh List"
                    >
                      <RefreshCw className="h-4 w-4" />
                    </button>

                    {/* Print Button */}
                    <button
                      onClick={() => window.print()}
                      className="w-9 h-9 rounded-full bg-[#F4F8F5] border border-[#DCE8E0] hover:bg-[#EBF5EF] text-[#122A24] transition-colors shadow-2xs flex items-center justify-center cursor-pointer"
                      title="Print Document"
                    >
                      <Printer className="h-4 w-4" />
                    </button>

                    {/* Export Dropdown */}
                    <div className="relative">
                      <button
                        onClick={() => setShowExportMenu(showExportMenu === 'classes' ? null : 'classes')}
                        className="flex items-center gap-1.5 px-3.5 py-2 bg-[#F4F8F5] border border-[#DCE8E0] hover:bg-[#EBF5EF] rounded-full text-xs font-semibold text-[#122A24] shadow-2xs cursor-pointer"
                      >
                        <Download className="h-3.5 w-3.5 text-[#1C443A]" />
                        <span>Export</span>
                        <ChevronRight className={`h-3 w-3 transition-transform ${showExportMenu === 'classes' ? 'rotate-90' : ''}`} />
                      </button>

                      {showExportMenu === 'classes' && (
                        <div className="absolute right-0 mt-1.5 w-40 bg-white rounded-2xl shadow-xl border border-[#DCE8E0] py-1.5 z-30 text-xs animate-fade-in">
                          <button
                            onClick={() => {
                              setShowExportMenu(null);
                              exportToCSV(
                                'CBSE_Classes_List',
                                ['ID', 'Class', 'Section', 'Class Teacher', 'No of Students', 'No of Subjects', 'Status'],
                                filteredClasses.map((c, idx) => {
                                  const classStudentsCount = students.filter(s => 
                                    s.class_name?.toLowerCase().includes(c.class_name.toLowerCase()) && 
                                    s.section?.toLowerCase() === c.section.toLowerCase()
                                  ).length;
                                  return [
                                    c.class_code || `CLS2026${(idx + 1).toString().padStart(2, '0')}`,
                                    c.class_name,
                                    c.section,
                                    c.class_teacher || 'Assigned Faculty',
                                    classStudentsCount > 0 ? classStudentsCount : (c.capacity || 30),
                                    c.no_of_subjects || '05',
                                    c.status || 'ACTIVE'
                                  ];
                                })
                              );
                            }}
                            className="w-full text-left px-3.5 py-2 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer text-xs font-medium text-[#122A24] flex items-center gap-2"
                          >
                            <FileText className="h-3.5 w-3.5 text-emerald-600" />
                            <span>Export CSV</span>
                          </button>
                          <button
                            onClick={() => {
                              setShowExportMenu(null);
                              window.print();
                            }}
                            className="w-full text-left px-3.5 py-2 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer text-xs font-medium text-[#122A24] flex items-center gap-2"
                          >
                            <Printer className="h-3.5 w-3.5 text-[#1C443A]" />
                            <span>Print PDF</span>
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Primary Add Button */}
                    <button
                      onClick={() => {
                        setClassForm({ class_name: 'Class 10', section: 'A', class_teacher: '', room_no: 'Room 101', capacity: 40 });
                        setEditingClassId(null);
                        setShowAddClass(true);
                      }}
                      className="px-4 py-2 bg-[#122A24] hover:bg-[#1C443A] text-white rounded-full text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-all border-none cursor-pointer"
                    >
                      <Plus className="h-4 w-4" /> Add Class
                    </button>
                  </div>
                </div>

                {/* Sub Header Controls Bar (Tier 1: Title, Status Tabs, Session, Sort) */}
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pt-1">
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="font-display font-semibold text-base text-[#122A24]">
                      Class Divisions Register
                    </div>
                    {/* Fast Status Segmented Pill Tabs */}
                    <div className="flex items-center bg-[#F4F8F5] p-1 rounded-full border border-[#DCE8E0] shadow-2xs">
                      <button
                        onClick={() => { setClassStatusFilter('ALL'); setClassPage(1); }}
                        className={`px-3 py-1 rounded-full text-xs font-semibold border-none cursor-pointer transition-all ${
                          classStatusFilter === 'ALL'
                            ? 'bg-[#122A24] text-white shadow-xs'
                            : 'bg-transparent text-[#2D5A4E] hover:text-[#122A24]'
                        }`}
                      >
                        All ({classes.length})
                      </button>
                      <button
                        onClick={() => { setClassStatusFilter('ACTIVE'); setClassPage(1); }}
                        className={`px-3 py-1 rounded-full text-xs font-semibold border-none cursor-pointer flex items-center gap-1.5 transition-all ${
                          classStatusFilter === 'ACTIVE'
                            ? 'bg-emerald-700 text-white shadow-xs'
                            : 'bg-transparent text-[#2D5A4E] hover:text-[#122A24]'
                        }`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-[#10B981]" />
                        Active ({classes.filter(c => c.status !== 'INACTIVE').length})
                      </button>
                      <button
                        onClick={() => { setClassStatusFilter('INACTIVE'); setClassPage(1); }}
                        className={`px-3 py-1 rounded-full text-xs font-semibold border-none cursor-pointer flex items-center gap-1.5 transition-all ${
                          classStatusFilter === 'INACTIVE'
                            ? 'bg-rose-700 text-white shadow-xs'
                            : 'bg-transparent text-rose-700 hover:text-rose-900 font-bold'
                        }`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                        Inactive ({classes.filter(c => c.status === 'INACTIVE').length})
                      </button>
                    </div>
                  </div>

                  {/* Right Header Controls: Session, Sort */}
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Session Pill */}
                    <div className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 bg-[#F4F8F5] border border-[#DCE8E0] rounded-full text-xs font-mono text-[#1C443A] shadow-2xs">
                      <Calendar className="h-3.5 w-3.5 text-[#2D5A4E]" />
                      <span>Session 2026-27</span>
                    </div>

                    {/* Sort Dropdown */}
                    <div className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#F4F8F5] border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                      <select
                        value={classSortBy}
                        onChange={(e) => setClassSortBy(e.target.value as any)}
                        className="bg-transparent border-none text-xs font-medium text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="A-Z">Sort: Class Order</option>
                        <option value="Z-A">Sort: Reverse Class</option>
                        <option value="ID-Asc">Sort: Class Code</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Tier 2: Filters, Rows Per Page & Search Bar */}
                <div className="bg-[#F9FCFA] rounded-2xl border border-[#DCE8E0] p-3 flex flex-col xl:flex-row xl:items-center justify-between gap-3">
                  {/* Filter Dropdown Pills */}
                  <div className="flex items-center gap-2 overflow-x-auto no-scrollbar flex-wrap">
                    {/* Academic Wing Filter */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <span className="text-[#2D5A4E] text-[11px] font-mono">Wing:</span>
                      <select
                        value={classWingFilter}
                        onChange={(e) => { setClassWingFilter(e.target.value); setClassPage(1); }}
                        className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="ALL">All Wings</option>
                        <option value="PRE_PRIMARY">Pre-Primary (Nursery-UKG)</option>
                        <option value="PRIMARY">Primary (Class 1-5)</option>
                        <option value="MIDDLE">Middle School (Class 6-8)</option>
                        <option value="SECONDARY">Secondary (Class 9-10)</option>
                        <option value="SR_SECONDARY">Sr Secondary (Class 11-12)</option>
                      </select>
                    </div>

                    {/* Section Filter */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <span className="text-[#2D5A4E] text-[11px] font-mono">Sec:</span>
                      <select
                        value={classSectionFilter}
                        onChange={(e) => { setClassSectionFilter(e.target.value); setClassPage(1); }}
                        className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="ALL">All Sections</option>
                        <option value="A">Section A</option>
                        <option value="B">Section B</option>
                      </select>
                    </div>
                  </div>

                  {/* Search & Rows Per Page */}
                  <div className="flex items-center gap-3 flex-col sm:flex-row">
                    <div className="flex items-center gap-2 text-xs text-[#2D5A4E] font-medium shrink-0">
                      <span>Rows:</span>
                      <select
                        value={classRowsPerPage}
                        onChange={(e) => {
                          setClassRowsPerPage(Number(e.target.value));
                          setClassPage(1);
                        }}
                        className="px-2.5 py-1 bg-white border border-[#DCE8E0] rounded-lg text-xs font-semibold text-[#122A24] cursor-pointer focus:outline-none focus:border-[#10B981]"
                      >
                        <option value={10}>10</option>
                        <option value={25}>25</option>
                        <option value={50}>50</option>
                        <option value={100}>100</option>
                      </select>
                    </div>

                    <div className="relative w-full sm:w-72">
                      <Search className="absolute left-3.5 top-2.5 h-3.5 w-3.5 text-[#2D5A4E]" />
                      <input
                        type="text"
                        placeholder="Search classes by name, section, teacher..."
                        value={searchQuery}
                        onChange={(e) => {
                          setSearchQuery(e.target.value);
                          setClassPage(1);
                        }}
                        className="w-full pl-9 pr-4 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs text-[#122A24] placeholder-slate-400 focus:outline-none focus:border-[#10B981] transition-all shadow-2xs"
                      />
                    </div>
                  </div>
                </div>

                {/* Active Filter Badges */}
                {(classWingFilter !== 'ALL' || classSectionFilter !== 'ALL' || classStatusFilter !== 'ALL' || searchQuery.trim() !== '') && (
                  <div className="flex flex-wrap items-center gap-2 px-1 text-xs">
                    <span className="text-[11px] font-mono text-[#2D5A4E] font-bold">Active Filters:</span>
                    {classWingFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Wing: {classWingFilter.replace('_', ' ')}
                        <button onClick={() => setClassWingFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {classSectionFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Section: {classSectionFilter}
                        <button onClick={() => setClassSectionFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {classStatusFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Status: {classStatusFilter}
                        <button onClick={() => setClassStatusFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {searchQuery.trim() !== '' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Query: &ldquo;{searchQuery}&rdquo;
                        <button onClick={() => setSearchQuery('')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    <button
                      onClick={() => {
                        setClassWingFilter('ALL');
                        setClassSectionFilter('ALL');
                        setClassStatusFilter('ALL');
                        setSearchQuery('');
                      }}
                      className="text-[11px] font-mono font-bold text-rose-600 hover:underline border-none bg-transparent cursor-pointer px-1"
                    >
                      Clear All
                    </button>
                  </div>
                )}

                {/* CLASSES TABLE */}
                <div className="rounded-2xl border border-[#DCE8E0] overflow-hidden bg-white shadow-2xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="bg-[#F3F7F5] font-mono text-[11px] font-bold text-[#1C443A] uppercase tracking-wider border-b border-[#DCE8E0]">
                        <tr>
                          <th className="py-3 px-3.5 w-10 text-center">
                            <input
                              type="checkbox"
                              checked={paginatedClasses.length > 0 && paginatedClasses.every(c => selectedClassIds.includes(c.id))}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  const newIds = Array.from(new Set([...selectedClassIds, ...paginatedClasses.map(c => c.id)]));
                                  setSelectedClassIds(newIds);
                                } else {
                                  setSelectedClassIds(selectedClassIds.filter(id => !paginatedClasses.some(c => c.id === id)));
                                }
                              }}
                              className="rounded border-slate-300 accent-[#122A24] cursor-pointer"
                            />
                          </th>
                          <th className="py-3 px-4">
                            <div
                              className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                              onClick={() => setClassSortBy(classSortBy === 'code-asc' || classSortBy === 'ID-Asc' ? 'code-desc' : 'code-asc')}
                              title="Sort by Division ID"
                            >
                              <span>Division ID</span>
                              <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                            </div>
                          </th>
                          <th className="py-3 px-4">
                            <div
                              className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                              onClick={() => setClassSortBy(classSortBy === 'class-asc' || classSortBy === 'A-Z' ? 'class-desc' : 'class-asc')}
                              title="Sort by CBSE Level"
                            >
                              <span>CBSE Level</span>
                              <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                            </div>
                          </th>
                          <th className="py-3 px-4">
                            <div
                              className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                              onClick={() => setClassSortBy(classSortBy === 'sec-asc' ? 'sec-desc' : 'sec-asc')}
                              title="Sort by Section"
                            >
                              <span>Section</span>
                              <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                            </div>
                          </th>
                          <th className="py-3 px-4">
                            <div
                              className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                              onClick={() => setClassSortBy(classSortBy === 'teacher-asc' ? 'teacher-desc' : 'teacher-asc')}
                              title="Sort by Class Teacher"
                            >
                              <span>Assigned Class Teacher</span>
                              <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                            </div>
                          </th>
                          <th className="py-3 px-4">
                            <div
                              className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                              onClick={() => setClassSortBy(classSortBy === 'capacity-asc' ? 'capacity-desc' : 'capacity-asc')}
                              title="Sort by Capacity"
                            >
                              <span>Enrolled Students</span>
                              <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                            </div>
                          </th>
                          <th className="py-3 px-4">
                            <div className="flex items-center gap-1">
                              <span>Room No</span>
                            </div>
                          </th>
                          <th className="py-3 px-3">
                            <div
                              className="flex items-center gap-1 cursor-pointer select-none hover:text-emerald-800 transition-colors"
                              onClick={() => setClassSortBy(classSortBy === 'status-asc' ? 'status-desc' : 'status-asc')}
                              title="Sort by Status"
                            >
                              <span>Status</span>
                              <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                            </div>
                          </th>
                          <th className="py-3 px-3 text-center">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#EBF2ED] font-sans">
                        {paginatedClasses.map((c, idx) => {
                          const isSelected = selectedClassIds.includes(c.id);
                          const classCode = c.class_code || `CLS2026${(idx + 1).toString().padStart(2, '0')}`;
                          const cleanRomanClass = formatClassDisplay(c.class_name);
                          const classStudentsCount = students.filter(s => 
                            s.class_name?.toLowerCase().includes(c.class_name.toLowerCase()) && 
                            s.section?.toLowerCase() === c.section.toLowerCase()
                          ).length;
                          const displayStudentsCount = classStudentsCount > 0 ? classStudentsCount : (c.capacity || 30);

                          return (
                            <tr
                              key={c.id}
                              className={`hover:bg-[#F9FCFA] transition-colors ${isSelected ? 'bg-[#EBF5EF]/60' : ''}`}
                            >
                              {/* Checkbox */}
                              <td className="py-3.5 px-3.5 text-center">
                                <input
                                  type="checkbox"
                                  checked={isSelected}
                                  onChange={(e) => {
                                    if (e.target.checked) {
                                      setSelectedClassIds([...selectedClassIds, c.id]);
                                    } else {
                                      setSelectedClassIds(selectedClassIds.filter(id => id !== c.id));
                                    }
                                  }}
                                  className="rounded border-slate-300 accent-[#122A24] cursor-pointer"
                                />
                              </td>

                              {/* ID */}
                              <td className="py-3.5 px-4 font-mono font-medium">
                                <button
                                  onClick={() => {
                                    setClassForm({
                                      class_name: c.class_name,
                                      section: c.section,
                                      class_teacher: c.class_teacher || '',
                                      room_no: c.room_no || 'Room 101',
                                      capacity: c.capacity || 40
                                    });
                                    setEditingClassId(c.id);
                                    setShowAddClass(true);
                                  }}
                                  className="text-[#122A24] hover:text-emerald-700 font-bold border-none bg-transparent p-0 cursor-pointer text-left block tracking-tight transition-colors"
                                >
                                  {classCode}
                                </button>
                              </td>

                              {/* Class in Roman */}
                              <td className="py-3.5 px-4 text-[#122A24] font-bold text-xs">
                                {cleanRomanClass}
                              </td>

                              {/* Section */}
                              <td className="py-3.5 px-4 text-[#122A24] font-mono font-semibold">
                                Section {c.section}
                              </td>

                              {/* Class Teacher */}
                              <td className="py-3.5 px-4 text-[#122A24] font-medium">
                                <div className="flex items-center gap-2">
                                  <div className="w-6 h-6 rounded-full bg-[#EBF5EF] border border-[#C5E2CF] text-[#122A24] font-mono font-bold text-[10px] flex items-center justify-center">
                                    {(c.class_teacher || 'T')[0]}
                                  </div>
                                  <span>{c.class_teacher || 'Assigned Faculty'}</span>
                                </div>
                              </td>

                              {/* No of Students */}
                              <td className="py-3.5 px-4 font-mono">
                                <span className="px-2.5 py-0.5 rounded-full text-[10.5px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF]">
                                  {displayStudentsCount} Students
                                </span>
                              </td>

                              {/* Room No */}
                              <td className="py-3.5 px-4 text-[#2D5A4E] font-mono text-xs">
                                {c.room_no || 'Room 101'}
                              </td>

                              {/* Status Badge (1-Click Toggle for Admin) */}
                              <td className="py-3.5 px-3">
                                <button
                                  onClick={() => handleToggleClassStatus(c)}
                                  className="cursor-pointer border-none bg-transparent p-0 flex items-center text-left"
                                  title={`Click to switch to ${c.status === 'INACTIVE' ? 'ACTIVE' : 'INACTIVE'}`}
                                >
                                  {c.status !== 'INACTIVE' ? (
                                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10.5px] font-mono font-semibold bg-[#EBF5EF] hover:bg-emerald-100 text-[#1C443A] border border-[#C5E2CF] transition-colors shadow-2xs">
                                      <span className="w-1.5 h-1.5 rounded-full bg-[#10B981]" />
                                      Active
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10.5px] font-mono font-semibold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition-colors shadow-2xs">
                                      <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                                      Inactive
                                    </span>
                                  )}
                                </button>
                              </td>

                              {/* Action ⋮ Popover with Admin Powers */}
                              <td className="py-3.5 px-3 text-center">
                                <div className="relative inline-block text-left">
                                  <button
                                    onClick={() => setActiveClassMenuId(activeClassMenuId === c.id ? null : c.id)}
                                    className="w-7 h-7 rounded-full text-slate-400 hover:text-[#122A24] hover:bg-[#EBF5EF] flex items-center justify-center border-none bg-transparent cursor-pointer transition-colors"
                                    title="Admin Powers & Actions"
                                  >
                                    <MoreVertical className="h-4 w-4" />
                                  </button>

                                  {activeClassMenuId === c.id && (
                                    <div className="absolute right-0 mt-1 w-48 bg-white rounded-2xl shadow-xl border border-[#DCE8E0] py-1.5 z-30 text-xs animate-fade-in">
                                      <button
                                        onClick={() => {
                                          setActiveClassMenuId(null);
                                          setClassForm({
                                            class_name: c.class_name,
                                            section: c.section,
                                            class_teacher: c.class_teacher || '',
                                            room_no: c.room_no || 'Room 101',
                                            capacity: c.capacity || 40
                                          });
                                          setEditingClassId(c.id);
                                          setShowAddClass(true);
                                        }}
                                        className="w-full text-left px-3.5 py-1.5 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer flex items-center gap-2 text-[#122A24]"
                                      >
                                        <Edit className="h-3.5 w-3.5 text-emerald-700" />
                                        <span>Edit Class</span>
                                      </button>
                                      <button
                                        onClick={() => {
                                          setActiveClassMenuId(null);
                                          handleToggleClassStatus(c);
                                        }}
                                        className="w-full text-left px-3.5 py-1.5 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer flex items-center gap-2 text-[#122A24]"
                                      >
                                        <ShieldCheck className="h-3.5 w-3.5 text-emerald-700" />
                                        <span>{c.status === 'INACTIVE' ? 'Set Active' : 'Set Inactive'}</span>
                                      </button>
                                      <button
                                        onClick={() => {
                                          setActiveClassMenuId(null);
                                          setSearchQuery(`${c.class_name}`);
                                          setActiveTab('students');
                                        }}
                                        className="w-full text-left px-3.5 py-1.5 hover:bg-[#F4F8F5] border-none bg-transparent cursor-pointer flex items-center gap-2 text-[#122A24]"
                                      >
                                        <Users className="h-3.5 w-3.5 text-emerald-700" />
                                        <span>View Students</span>
                                      </button>
                                      <div className="border-t border-[#E8F0EA] my-1" />
                                      <button
                                        onClick={() => {
                                          setActiveClassMenuId(null);
                                          handleDeleteClass(c.id);
                                        }}
                                        className="w-full text-left px-3.5 py-1.5 hover:bg-rose-50 border-none bg-transparent cursor-pointer flex items-center gap-2 text-rose-600 font-semibold"
                                      >
                                        <Trash2 className="h-3.5 w-3.5" />
                                        <span>Delete Class</span>
                                      </button>
                                    </div>
                                  )}
                                </div>
                              </td>
                            </tr>
                          );
                        })}

                        {paginatedClasses.length === 0 && (
                          <tr>
                            <td colSpan={9} className="py-12 text-center text-xs text-[#2D5A4E] font-medium">
                              No classes found matching search criteria. Click "+ Add Class" above to create divisions.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Table Footer Pagination */}
                  <div className="p-3.5 border-t border-[#DCE8E0] bg-[#F8FAF9] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-[#2D5A4E]">
                    <div>
                      Showing {totalClassEntries === 0 ? 0 : (classPage - 1) * classRowsPerPage + 1} to {Math.min(classPage * classRowsPerPage, totalClassEntries)} of {totalClassEntries} Entries
                    </div>

                    <div className="flex items-center gap-1 self-end sm:self-auto">
                      <button
                        onClick={() => setClassPage(Math.max(1, classPage - 1))}
                        disabled={classPage === 1}
                        className="px-3 py-1 rounded-lg border border-[#DCE8E0] bg-white text-[#122A24] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#EBF5EF] cursor-pointer font-medium transition-colors"
                      >
                        Prev
                      </button>

                      {Array.from({ length: totalClassPages }, (_, i) => i + 1).slice(0, 5).map(pageNum => (
                        <button
                          key={pageNum}
                          onClick={() => setClassPage(pageNum)}
                          className={`w-7 h-7 rounded-lg border text-xs font-semibold cursor-pointer transition-colors ${
                            classPage === pageNum
                              ? 'bg-[#122A24] border-[#122A24] text-white shadow-xs'
                              : 'bg-white border-[#DCE8E0] text-[#122A24] hover:bg-[#EBF5EF]'
                          }`}
                        >
                          {pageNum}
                        </button>
                      ))}

                      <button
                        onClick={() => setClassPage(Math.min(totalClassPages, classPage + 1))}
                        disabled={classPage === totalClassPages || totalClassPages === 0}
                        className="px-3 py-1 rounded-lg border border-[#DCE8E0] bg-white text-[#122A24] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#EBF5EF] cursor-pointer font-medium transition-colors"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                </div>

                {/* Floating Bulk Action Dock for Classes */}
                {selectedClassIds.length > 0 && (
                  <div className="fixed bottom-20 lg:bottom-6 left-1/2 -translate-x-1/2 z-50 bg-[#122A24] text-white px-4 sm:px-6 py-2.5 rounded-full shadow-2xl flex items-center gap-2 sm:gap-3 border border-white/20 animate-fade-up">
                    <span className="text-xs font-mono font-bold px-2.5 py-0.5 bg-white/20 rounded-full">
                      {selectedClassIds.length} Selected
                    </span>
                    <button
                      onClick={() => handleBulkClassStatus('ACTIVE')}
                      className="px-3 py-1 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold border-none cursor-pointer flex items-center gap-1 transition-colors"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" /> Set Active
                    </button>
                    <button
                      onClick={() => handleBulkClassStatus('INACTIVE')}
                      className="px-3 py-1 rounded-full bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold border-none cursor-pointer flex items-center gap-1 transition-colors"
                    >
                      <Clock className="h-3.5 w-3.5" /> Set Inactive
                    </button>
                    <button
                      onClick={handleBulkDeleteClasses}
                      className="px-3 py-1 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold border-none cursor-pointer flex items-center gap-1 transition-colors"
                    >
                      <Trash2 className="h-3.5 w-3.5" /> Delete
                    </button>
                    <button
                      onClick={() => setSelectedClassIds([])}
                      className="text-xs text-slate-300 hover:text-white border-none bg-transparent cursor-pointer ml-1"
                      title="Clear Selection"
                    >
                      ✕
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 5: ATTENDANCE HUB (INTERACTIVE CLASSROOM & FACULTY ROSTERS) */}
          {activeTab === 'attendance' && (
            <div className="space-y-6 max-w-7xl mx-auto animate-fade-in">
              <div className="bg-white rounded-3xl border border-[#DCE8E0] shadow-xs p-5 sm:p-7 space-y-6">
                {/* 1. Top Header & Attendance Mode Switcher */}
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-[#E8F0EA]">
                  <div>
                    <div className="flex items-center gap-3 flex-wrap">
                      <h1 className="font-display font-bold text-2xl sm:text-3xl text-[#122A24] tracking-tight">
                        Attendance Hub &amp; Daily Ledgers
                      </h1>
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF]">
                        {attendanceMode === 'students' ? '👨‍🎓 Classroom Roster' : attendanceMode === 'faculty' ? '👩‍🏫 Faculty Directorate' : '📜 Verification Logs'}
                      </span>
                    </div>
                    <p className="text-xs text-[#2D5A4E] mt-1 font-mono">
                      Institutional daily roll call, staff biometric registry, and real-time ledger synchronization
                    </p>
                  </div>

                  {/* Mode Switcher Tabs */}
                  <div className="flex items-center bg-[#F4F8F5] p-1 rounded-full border border-[#DCE8E0] shadow-2xs self-start lg:self-auto overflow-x-auto no-scrollbar">
                    <button
                      onClick={() => setAttendanceMode('students')}
                      className={`px-3.5 py-1.5 rounded-full text-xs font-semibold border-none cursor-pointer flex items-center gap-1.5 transition-all ${
                        attendanceMode === 'students'
                          ? 'bg-[#122A24] text-white shadow-xs'
                          : 'bg-transparent text-[#2D5A4E] hover:text-[#122A24]'
                      }`}
                    >
                      <Users className="h-3.5 w-3.5" />
                      <span>Class Students</span>
                    </button>
                    <button
                      onClick={() => setAttendanceMode('faculty')}
                      className={`px-3.5 py-1.5 rounded-full text-xs font-semibold border-none cursor-pointer flex items-center gap-1.5 transition-all ${
                        attendanceMode === 'faculty'
                          ? 'bg-[#122A24] text-white shadow-xs'
                          : 'bg-transparent text-[#2D5A4E] hover:text-[#122A24]'
                      }`}
                    >
                      <GraduationCap className="h-3.5 w-3.5" />
                      <span>Faculty &amp; Staff</span>
                    </button>
                    <button
                      onClick={() => setAttendanceMode('logs')}
                      className={`px-3.5 py-1.5 rounded-full text-xs font-semibold border-none cursor-pointer flex items-center gap-1.5 transition-all ${
                        attendanceMode === 'logs'
                          ? 'bg-[#122A24] text-white shadow-xs'
                          : 'bg-transparent text-[#2D5A4E] hover:text-[#122A24]'
                      }`}
                    >
                      <FileText className="h-3.5 w-3.5" />
                      <span>Ledger Logs ({filteredAttendance.length})</span>
                    </button>
                  </div>
                </div>

                {/* 2. MODE: CLASSROOM STUDENTS ATTENDANCE */}
                {attendanceMode === 'students' && (() => {
                  const targetStudents = students.filter(s => {
                    const clsMatch = s.class_name?.toLowerCase().replace(/^class\s*/i, '').trim() === selectedAttendanceClass.toLowerCase().replace(/^class\s*/i, '').trim() || s.class_name?.toLowerCase() === selectedAttendanceClass.toLowerCase();
                    const secMatch = (s.section || 'A').toUpperCase() === selectedAttendanceSection.toUpperCase();
                    return clsMatch && secMatch;
                  });

                  let presentCount = 0;
                  let absentCount = 0;
                  let lateCount = 0;
                  let halfDayCount = 0;

                  targetStudents.forEach(s => {
                    const st = studentAttendanceMap[s.id] || 'PRESENT';
                    if (st === 'PRESENT') presentCount++;
                    else if (st === 'ABSENT') absentCount++;
                    else if (st === 'LATE') lateCount++;
                    else if (st === 'HALF_DAY') halfDayCount++;
                  });

                  const effectivePresent = presentCount + lateCount + halfDayCount;
                  const rate = targetStudents.length > 0 ? Math.round((effectivePresent / targetStudents.length) * 100) : 100;

                  return (
                    <div className="space-y-5">
                      {/* Selectors Bar & Action Controls */}
                      <div className="bg-[#F9FCFA] rounded-2xl border border-[#DCE8E0] p-4 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
                        <div className="flex items-center gap-3 flex-wrap">
                          {/* Class Select */}
                          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                            <span className="text-[#2D5A4E] text-[11px] font-mono font-bold">Class:</span>
                            <select
                              value={selectedAttendanceClass}
                              onChange={(e) => setSelectedAttendanceClass(e.target.value)}
                              className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                            >
                              <optgroup label="Pre-Primary">
                                <option value="Nursery">Nursery</option>
                                <option value="LKG">LKG</option>
                                <option value="UKG">UKG</option>
                              </optgroup>
                              <optgroup label="Primary (1-5)">
                                <option value="Class 1">Class 1</option>
                                <option value="Class 2">Class 2</option>
                                <option value="Class 3">Class 3</option>
                                <option value="Class 4">Class 4</option>
                                <option value="Class 5">Class 5</option>
                              </optgroup>
                              <optgroup label="Middle & Secondary (6-10)">
                                <option value="Class 6">Class 6</option>
                                <option value="Class 7">Class 7</option>
                                <option value="Class 8">Class 8</option>
                                <option value="Class 9">Class 9</option>
                                <option value="Class 10">Class 10</option>
                              </optgroup>
                              <optgroup label="Senior Secondary (11-12)">
                                <option value="Class 11">Class 11</option>
                                <option value="Class 12">Class 12</option>
                              </optgroup>
                            </select>
                          </div>

                          {/* Section Select */}
                          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                            <span className="text-[#2D5A4E] text-[11px] font-mono font-bold">Section:</span>
                            <select
                              value={selectedAttendanceSection}
                              onChange={(e) => setSelectedAttendanceSection(e.target.value)}
                              className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                            >
                              <option value="A">Section A</option>
                              <option value="B">Section B</option>
                              <option value="C">Section C</option>
                              <option value="D">Section D</option>
                            </select>
                          </div>

                          {/* Date Select */}
                          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                            <Calendar className="h-3.5 w-3.5 text-[#2D5A4E]" />
                            <input
                              type="date"
                              value={selectedAttendanceDate}
                              onChange={(e) => setSelectedAttendanceDate(e.target.value)}
                              className="bg-transparent border-none text-xs font-mono font-semibold text-[#122A24] focus:outline-none cursor-pointer"
                            />
                          </div>
                        </div>

                        {/* Batch Action Buttons */}
                        <div className="flex items-center gap-2 flex-wrap">
                          <button
                            onClick={() => handleMarkAllClassStudents('PRESENT')}
                            className="px-3.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-full text-xs font-semibold cursor-pointer transition-colors shadow-2xs"
                          >
                            ✓ All Present
                          </button>
                          <button
                            onClick={() => handleMarkAllClassStudents('ABSENT')}
                            className="px-3.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-full text-xs font-semibold cursor-pointer transition-colors shadow-2xs"
                          >
                            ✗ All Absent
                          </button>
                          <button
                            onClick={handleSaveClassAttendance}
                            disabled={attendanceSaving || targetStudents.length === 0}
                            className="px-4 py-1.5 bg-[#122A24] hover:bg-[#1C443A] text-white rounded-full text-xs font-semibold border-none cursor-pointer shadow-xs transition-all flex items-center gap-1.5 disabled:opacity-60"
                          >
                            <Save className="h-3.5 w-3.5" />
                            <span>{attendanceSaving ? 'Saving...' : 'Save & Sync Attendance'}</span>
                          </button>
                        </div>
                      </div>

                      {/* Live Class KPI Cards */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
                        <div className="bg-[#F9FCFA] p-3.5 rounded-2xl border border-[#DCE8E0]">
                          <div className="text-[11px] font-mono text-[#2D5A4E]">Total Class Strength</div>
                          <div className="text-xl font-bold font-display text-[#122A24] mt-0.5">{targetStudents.length} Scholars</div>
                        </div>
                        <div className="bg-[#EBF5EF] p-3.5 rounded-2xl border border-[#C5E2CF]">
                          <div className="text-[11px] font-mono text-emerald-800 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" /> Present Today
                          </div>
                          <div className="text-xl font-bold font-display text-emerald-900 mt-0.5">{effectivePresent} Present</div>
                        </div>
                        <div className="bg-rose-50/70 p-3.5 rounded-2xl border border-rose-200">
                          <div className="text-[11px] font-mono text-rose-700 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-600" /> Absent Today
                          </div>
                          <div className="text-xl font-bold font-display text-rose-900 mt-0.5">{absentCount} Absent</div>
                        </div>
                        <div className="bg-white p-3.5 rounded-2xl border border-[#DCE8E0]">
                          <div className="text-[11px] font-mono text-[#2D5A4E]">Attendance Rate</div>
                          <div className="text-xl font-bold font-display text-[#122A24] mt-0.5">{rate}%</div>
                        </div>
                      </div>

                      {/* Classroom Student Roster Table */}
                      <div className="rounded-2xl border border-[#DCE8E0] overflow-hidden bg-white shadow-2xs">
                        <div className="p-3.5 bg-[#F3F7F5] border-b border-[#DCE8E0] font-mono text-[11px] font-bold text-[#1C443A] uppercase tracking-wider flex justify-between items-center">
                          <span>{selectedAttendanceClass} — Section {selectedAttendanceSection} Student Roll Call</span>
                          <span>{targetStudents.length} Students Enrolled</span>
                        </div>

                        <div className="overflow-x-auto">
                          <table className="w-full text-left text-xs border-collapse">
                            <thead className="bg-[#F9FCFA] font-mono text-[10.5px] font-bold text-[#2D5A4E] uppercase border-b border-[#E8F0EA]">
                              <tr>
                                <th className="py-2.5 px-4 w-16">Roll</th>
                                <th className="py-2.5 px-4">Adm No</th>
                                <th className="py-2.5 px-4">Scholar Name</th>
                                <th className="py-2.5 px-4">Guardian / Phone</th>
                                <th className="py-2.5 px-4 text-center">Term Record</th>
                                <th className="py-2.5 px-4 text-center">Daily Status Toggle</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-[#EBF2ED]">
                              {targetStudents.map((s, idx) => {
                                const currentStatus = studentAttendanceMap[s.id] || 'PRESENT';
                                const initials = (s.full_name || 'Student').split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();

                                return (
                                  <tr key={s.id} className="hover:bg-[#F9FCFA] transition-colors">
                                    <td className="py-3 px-4 font-mono font-bold text-[#122A24]">
                                      #{s.roll_no || (idx + 1).toString().padStart(2, '0')}
                                    </td>
                                    <td className="py-3 px-4 font-mono text-[#2D5A4E]">
                                      {s.admission_no}
                                    </td>
                                    <td className="py-3 px-4">
                                      <div className="flex items-center gap-2.5">
                                        <div className="w-7 h-7 rounded-full bg-[#EBF5EF] text-[#122A24] font-bold text-[10px] flex items-center justify-center border border-[#C5E2CF]">
                                          {initials}
                                        </div>
                                        <div>
                                          <div className="font-semibold text-[#122A24]">{s.full_name}</div>
                                          <div className="text-[10px] text-[#2D5A4E]">{s.gender || 'Scholar'}</div>
                                        </div>
                                      </div>
                                    </td>
                                    <td className="py-3 px-4 text-[#2D5A4E] font-mono text-[11px]">
                                      <div>{s.guardian_name || 'Parent'}</div>
                                      <div className="text-[10px] text-slate-400">{s.guardian_phone || s.father_phone || '—'}</div>
                                    </td>
                                    <td className="py-3 px-4 text-center font-mono">
                                      <span className="px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF]">
                                        {s.attendance_percent || 96}%
                                      </span>
                                    </td>
                                    <td className="py-3 px-4">
                                      <div className="flex items-center justify-center gap-1.5">
                                        <button
                                          onClick={() => handleToggleStudentAttendanceStatus(s.id, 'PRESENT')}
                                          className={`px-2.5 py-1 rounded-full text-[11px] font-mono font-bold border cursor-pointer transition-all ${
                                            currentStatus === 'PRESENT'
                                              ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                                              : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50'
                                          }`}
                                        >
                                          ✓ Present
                                        </button>
                                        <button
                                          onClick={() => handleToggleStudentAttendanceStatus(s.id, 'ABSENT')}
                                          className={`px-2.5 py-1 rounded-full text-[11px] font-mono font-bold border cursor-pointer transition-all ${
                                            currentStatus === 'ABSENT'
                                              ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                                              : 'bg-white text-rose-700 border-rose-200 hover:bg-rose-50'
                                          }`}
                                        >
                                          ✗ Absent
                                        </button>
                                        <button
                                          onClick={() => handleToggleStudentAttendanceStatus(s.id, 'LATE')}
                                          className={`px-2 py-1 rounded-full text-[10.5px] font-mono font-bold border cursor-pointer transition-all ${
                                            currentStatus === 'LATE'
                                              ? 'bg-amber-500 text-white border-amber-500 shadow-xs'
                                              : 'bg-white text-amber-700 border-amber-200 hover:bg-amber-50'
                                          }`}
                                        >
                                          Late
                                        </button>
                                        <button
                                          onClick={() => handleToggleStudentAttendanceStatus(s.id, 'HALF_DAY')}
                                          className={`px-2 py-1 rounded-full text-[10.5px] font-mono font-bold border cursor-pointer transition-all ${
                                            currentStatus === 'HALF_DAY'
                                              ? 'bg-sky-600 text-white border-sky-600 shadow-xs'
                                              : 'bg-white text-sky-700 border-sky-200 hover:bg-sky-50'
                                          }`}
                                        >
                                          Half Day
                                        </button>
                                      </div>
                                    </td>
                                  </tr>
                                );
                              })}
                              {targetStudents.length === 0 && (
                                <tr>
                                  <td colSpan={6} className="py-12 text-center text-xs font-mono text-[#2D5A4E]">
                                    No students enrolled in {selectedAttendanceClass} - Section {selectedAttendanceSection}. Select another class or add students.
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* 3. MODE: FACULTY & STAFF ATTENDANCE */}
                {attendanceMode === 'faculty' && (() => {
                  const activeFaculty = teachers.filter(t => {
                    if (t.status === 'INACTIVE') return false;
                    if (attendanceFacultyDeptFilter !== 'ALL' && !t.department?.toLowerCase().includes(attendanceFacultyDeptFilter.toLowerCase())) return false;
                    return true;
                  });

                  let onDutyCount = 0;
                  let onLeaveCount = 0;
                  let halfDayCount = 0;
                  let absentCount = 0;

                  activeFaculty.forEach(t => {
                    const st = facultyAttendanceMap[t.id] || 'PRESENT';
                    if (st === 'PRESENT') onDutyCount++;
                    else if (st === 'LEAVE') onLeaveCount++;
                    else if (st === 'HALF_DAY') halfDayCount++;
                    else if (st === 'ABSENT') absentCount++;
                  });

                  const effectiveOnDuty = onDutyCount + halfDayCount;
                  const rate = activeFaculty.length > 0 ? Math.round((effectiveOnDuty / activeFaculty.length) * 100) : 100;

                  return (
                    <div className="space-y-5">
                      {/* Selectors Bar & Action Controls */}
                      <div className="bg-[#F9FCFA] rounded-2xl border border-[#DCE8E0] p-4 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
                        <div className="flex items-center gap-3 flex-wrap">
                          {/* Date Select */}
                          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                            <Calendar className="h-3.5 w-3.5 text-[#2D5A4E]" />
                            <input
                              type="date"
                              value={selectedAttendanceDate}
                              onChange={(e) => setSelectedAttendanceDate(e.target.value)}
                              className="bg-transparent border-none text-xs font-mono font-semibold text-[#122A24] focus:outline-none cursor-pointer"
                            />
                          </div>

                          {/* Department Filter */}
                          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                            <span className="text-[#2D5A4E] text-[11px] font-mono font-bold">Dept:</span>
                            <select
                              value={attendanceFacultyDeptFilter}
                              onChange={(e) => setAttendanceFacultyDeptFilter(e.target.value)}
                              className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                            >
                              <option value="ALL">All Departments</option>
                              <option value="Mathematics">Mathematics</option>
                              <option value="Science">Science</option>
                              <option value="English">English</option>
                              <option value="Hindi">Hindi &amp; Sanskrit</option>
                              <option value="Social">Social Science</option>
                              <option value="Computer">Computer &amp; AI</option>
                              <option value="Commerce">Commerce</option>
                              <option value="Physical">Physical Education</option>
                              <option value="Pre-Primary">Pre-Primary</option>
                            </select>
                          </div>
                        </div>

                        {/* Batch Action Buttons */}
                        <div className="flex items-center gap-2 flex-wrap">
                          <button
                            onClick={() => handleMarkAllFaculty('PRESENT')}
                            className="px-3.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-full text-xs font-semibold cursor-pointer transition-colors shadow-2xs"
                          >
                            ✓ All On Duty
                          </button>
                          <button
                            onClick={() => handleMarkAllFaculty('LEAVE')}
                            className="px-3.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-full text-xs font-semibold cursor-pointer transition-colors shadow-2xs"
                          >
                            🏖 All On Leave
                          </button>
                          <button
                            onClick={handleSaveFacultyAttendance}
                            disabled={attendanceSaving || activeFaculty.length === 0}
                            className="px-4 py-1.5 bg-[#122A24] hover:bg-[#1C443A] text-white rounded-full text-xs font-semibold border-none cursor-pointer shadow-xs transition-all flex items-center gap-1.5 disabled:opacity-60"
                          >
                            <Save className="h-3.5 w-3.5" />
                            <span>{attendanceSaving ? 'Saving...' : 'Save & Sync Faculty Ledger'}</span>
                          </button>
                        </div>
                      </div>

                      {/* Live Faculty KPI Cards */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
                        <div className="bg-[#F9FCFA] p-3.5 rounded-2xl border border-[#DCE8E0]">
                          <div className="text-[11px] font-mono text-[#2D5A4E]">Faculty Strength</div>
                          <div className="text-xl font-bold font-display text-[#122A24] mt-0.5">{activeFaculty.length} Certified</div>
                        </div>
                        <div className="bg-[#EBF5EF] p-3.5 rounded-2xl border border-[#C5E2CF]">
                          <div className="text-[11px] font-mono text-emerald-800 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" /> On Duty Today
                          </div>
                          <div className="text-xl font-bold font-display text-emerald-900 mt-0.5">{effectiveOnDuty} On Duty</div>
                        </div>
                        <div className="bg-amber-50/70 p-3.5 rounded-2xl border border-amber-200">
                          <div className="text-[11px] font-mono text-amber-800 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-600" /> Approved Leave
                          </div>
                          <div className="text-xl font-bold font-display text-amber-900 mt-0.5">{onLeaveCount} Leave</div>
                        </div>
                        <div className="bg-white p-3.5 rounded-2xl border border-[#DCE8E0]">
                          <div className="text-[11px] font-mono text-[#2D5A4E]">Presence Rate</div>
                          <div className="text-xl font-bold font-display text-[#122A24] mt-0.5">{rate}%</div>
                        </div>
                      </div>

                      {/* Faculty Daily Roster Table */}
                      <div className="rounded-2xl border border-[#DCE8E0] overflow-hidden bg-white shadow-2xs">
                        <div className="p-3.5 bg-[#F3F7F5] border-b border-[#DCE8E0] font-mono text-[11px] font-bold text-[#1C443A] uppercase tracking-wider flex justify-between items-center">
                          <span>Faculty &amp; Staff Attendance Roll Call</span>
                          <span>{activeFaculty.length} Active Faculty</span>
                        </div>

                        <div className="overflow-x-auto">
                          <table className="w-full text-left text-xs border-collapse">
                            <thead className="bg-[#F9FCFA] font-mono text-[10.5px] font-bold text-[#2D5A4E] uppercase border-b border-[#E8F0EA]">
                              <tr>
                                <th className="py-2.5 px-4 w-20">Code</th>
                                <th className="py-2.5 px-4">Faculty Member</th>
                                <th className="py-2.5 px-4">Role &amp; Department</th>
                                <th className="py-2.5 px-4">Shift Timings</th>
                                <th className="py-2.5 px-4 text-center">Daily Status Toggle</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-[#EBF2ED]">
                              {activeFaculty.map((t) => {
                                const currentStatus = facultyAttendanceMap[t.id] || 'PRESENT';
                                const initials = (t.full_name || 'Faculty').split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();

                                return (
                                  <tr key={t.id} className="hover:bg-[#F9FCFA] transition-colors">
                                    <td className="py-3 px-4 font-mono font-bold text-[#122A24]">
                                      {t.staff_code}
                                    </td>
                                    <td className="py-3 px-4">
                                      <div className="flex items-center gap-2.5">
                                        <div className="w-7 h-7 rounded-full bg-[#EBF5EF] text-[#122A24] font-bold text-[10px] flex items-center justify-center border border-[#C5E2CF]">
                                          {initials}
                                        </div>
                                        <div>
                                          <div className="font-semibold text-[#122A24]">{t.full_name}</div>
                                          <div className="text-[10px] text-[#2D5A4E]">{t.email}</div>
                                        </div>
                                      </div>
                                    </td>
                                    <td className="py-3 px-4">
                                      <div className="font-medium text-[#122A24]">{t.designation || 'Faculty'}</div>
                                      <div className="text-[10px] text-[#2D5A4E]">{t.department || t.subject_specialization || 'General'}</div>
                                    </td>
                                    <td className="py-3 px-4 font-mono text-[11px] text-[#2D5A4E]">
                                      <div>08:00 AM — 02:30 PM</div>
                                      <div className="text-[10px] text-emerald-700">Biometric Sync OK</div>
                                    </td>
                                    <td className="py-3 px-4">
                                      <div className="flex items-center justify-center gap-1.5">
                                        <button
                                          onClick={() => handleToggleFacultyAttendanceStatus(t.id, 'PRESENT')}
                                          className={`px-2.5 py-1 rounded-full text-[11px] font-mono font-bold border cursor-pointer transition-all ${
                                            currentStatus === 'PRESENT'
                                              ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                                              : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50'
                                          }`}
                                        >
                                          ● On Duty
                                        </button>
                                        <button
                                          onClick={() => handleToggleFacultyAttendanceStatus(t.id, 'LEAVE')}
                                          className={`px-2.5 py-1 rounded-full text-[11px] font-mono font-bold border cursor-pointer transition-all ${
                                            currentStatus === 'LEAVE'
                                              ? 'bg-amber-500 text-white border-amber-500 shadow-xs'
                                              : 'bg-white text-amber-700 border-amber-200 hover:bg-amber-50'
                                          }`}
                                        >
                                          🏖 On Leave
                                        </button>
                                        <button
                                          onClick={() => handleToggleFacultyAttendanceStatus(t.id, 'HALF_DAY')}
                                          className={`px-2 py-1 rounded-full text-[10.5px] font-mono font-bold border cursor-pointer transition-all ${
                                            currentStatus === 'HALF_DAY'
                                              ? 'bg-sky-600 text-white border-sky-600 shadow-xs'
                                              : 'bg-white text-sky-700 border-sky-200 hover:bg-sky-50'
                                          }`}
                                        >
                                          Half Day
                                        </button>
                                        <button
                                          onClick={() => handleToggleFacultyAttendanceStatus(t.id, 'ABSENT')}
                                          className={`px-2.5 py-1 rounded-full text-[11px] font-mono font-bold border cursor-pointer transition-all ${
                                            currentStatus === 'ABSENT'
                                              ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                                              : 'bg-white text-rose-700 border-rose-200 hover:bg-rose-50'
                                          }`}
                                        >
                                          ✗ Absent
                                        </button>
                                      </div>
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* 4. MODE: DAILY LEDGER VERIFICATION LOGS */}
                {attendanceMode === 'logs' && (
                  <div className="space-y-5">
                    {/* Filters Bar */}
                    <div className="bg-[#F9FCFA] rounded-2xl border border-[#DCE8E0] p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 flex-wrap">
                        {/* Class Filter */}
                        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                          <span className="text-[#2D5A4E] text-[11px] font-mono">Class:</span>
                          <select
                            value={attendanceClassFilter}
                            onChange={(e) => setAttendanceClassFilter(e.target.value)}
                            className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                          >
                            <option value="ALL">All Classes</option>
                            <option value="Faculty & Staff Roster">Faculty &amp; Staff</option>
                            <option value="Nursery">Nursery</option>
                            <option value="LKG">LKG</option>
                            <option value="UKG">UKG</option>
                            {Array.from({ length: 12 }, (_, i) => i + 1).map(num => (
                              <option key={num} value={`Class ${num}`}>{`Class ${num}`}</option>
                            ))}
                          </select>
                        </div>

                        {/* Date Filter */}
                        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                          <Calendar className="h-3.5 w-3.5 text-[#2D5A4E]" />
                          <input
                            type="date"
                            value={attendanceDateFilter}
                            onChange={(e) => setAttendanceDateFilter(e.target.value)}
                            className="bg-transparent border-none text-xs font-mono text-[#122A24] focus:outline-none cursor-pointer"
                          />
                        </div>
                      </div>

                      {/* Search Bar */}
                      <div className="relative w-full sm:w-72">
                        <Search className="absolute left-3.5 top-2.5 h-3.5 w-3.5 text-[#2D5A4E]" />
                        <input
                          type="text"
                          placeholder="Search logs by class, section, teacher..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="w-full pl-9 pr-4 py-1.5 bg-white border border-[#DCE8E0] rounded-full text-xs text-[#122A24] placeholder-slate-400 focus:outline-none focus:border-[#10B981] transition-all shadow-2xs"
                        />
                      </div>
                    </div>

                    {/* Attendance Logs List */}
                    <div className="bg-white rounded-2xl border border-[#DCE8E0] overflow-hidden shadow-2xs">
                      <div className="p-3.5 border-b border-[#DCE8E0] bg-[#F3F7F5] font-mono text-[11px] font-bold uppercase tracking-wider text-[#1C443A] flex justify-between items-center">
                        <span>Live Verification Session Logs</span>
                        <span>{filteredAttendance.length} Entries Recorded</span>
                      </div>
                      <div className="divide-y divide-[#EBF2ED]">
                        {filteredAttendance.map(a => (
                          <div key={a.id} className="p-4 flex items-center justify-between text-xs hover:bg-[#F9FCFA] transition-colors group">
                            <div>
                              <div className="font-semibold text-[#122A24] text-sm">
                                {a.class_name} {a.section && a.section !== 'All' ? `— Section ${a.section}` : ''}
                              </div>
                              <div className="text-[#2D5A4E] font-mono text-[11px] mt-0.5">
                                Date: {formatDateDisplay(a.date)} • Verified By: <span className="font-semibold">{a.marked_by || 'Admin'}</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-3 font-mono">
                              <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF]">
                                ✓ {a.present_count} Present
                              </span>
                              <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
                                ✗ {a.absent_count} Absent
                              </span>
                              <span className="text-[#2D5A4E] text-xs font-semibold">Total: {a.total_students}</span>
                              <button
                                onClick={() => handleDeleteAttendanceLog(a.id)}
                                className="p-1.5 text-slate-300 hover:text-rose-600 rounded-full border-none bg-transparent cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity"
                                title="Delete Log Record"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </div>
                        ))}
                        {filteredAttendance.length === 0 && (
                          <div className="py-12 text-center text-xs font-mono text-[#2D5A4E]">
                            No attendance verification records found matching your filters.
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 6: FEES & INVOICE MANAGEMENT (THEME-ALIGNED WITH ADVANCED FILTERS) */}
          {activeTab === 'fees' && (
            <div className="space-y-5 max-w-7xl mx-auto animate-fade-in">
              <div className="bg-white rounded-3xl border border-[#DCE8E0] shadow-xs p-5 sm:p-7 space-y-5">
                {/* Header & Primary Action */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E8F0EA]">
                  <div>
                    <div className="flex items-center gap-3">
                      <h1 className="font-display font-bold text-2xl sm:text-3xl text-[#122A24] tracking-tight">
                        Fee Management &amp; Invoices
                      </h1>
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF]">
                        {filteredInvoices.length} Invoices
                      </span>
                    </div>
                    <p className="text-xs text-[#2D5A4E] mt-0.5 font-mono">
                      Issue customized student fee slips, record dues, track receipts, and print invoices
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowAddInvoice(true)}
                      className="px-4 py-2 bg-[#122A24] hover:bg-[#1C443A] text-white rounded-full text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-all border-none cursor-pointer"
                    >
                      <Plus className="h-4 w-4" /> Issue Fee Invoice
                    </button>
                  </div>
                </div>

                {/* Financial KPI Summary Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="bg-[#F9FCFA] p-4 sm:p-5 rounded-2xl border border-[#DCE8E0] shadow-2xs">
                    <span className="font-mono text-[11px] font-bold uppercase tracking-wider text-[#2D5A4E]">Total Billed</span>
                    <div className="font-display font-bold text-2xl text-[#122A24] mt-1.5">
                      ₹{totalBilled.toLocaleString()}
                    </div>
                    <div className="text-[11px] font-mono text-[#2D5A4E] mt-0.5">{invoices.length} Invoices Generated</div>
                  </div>

                  <div className="bg-[#F0FDF4] p-4 sm:p-5 rounded-2xl border border-[#BBF7D0] shadow-2xs">
                    <span className="font-mono text-[11px] font-bold uppercase tracking-wider text-emerald-800">Collected Amount</span>
                    <div className="font-display font-bold text-2xl text-emerald-700 mt-1.5">
                      ₹{totalPaid.toLocaleString()}
                    </div>
                    <div className="text-[11px] font-mono text-emerald-700 mt-0.5">Paid Receipts</div>
                  </div>

                  <div className="bg-rose-50/50 p-4 sm:p-5 rounded-2xl border border-rose-200 shadow-2xs">
                    <span className="font-mono text-[11px] font-bold uppercase tracking-wider text-rose-800">Outstanding Due</span>
                    <div className="font-display font-bold text-2xl text-rose-600 mt-1.5">
                      ₹{totalPending.toLocaleString()}
                    </div>
                    <div className="text-[11px] font-mono text-rose-600 mt-0.5">Pending Payments</div>
                  </div>
                </div>

                {/* Fee Filters & Search Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                  <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 max-w-full flex-wrap sm:flex-nowrap">
                    {/* Status Filter */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#F4F8F5] border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <span className="text-[#2D5A4E] text-[11px] font-mono">Status:</span>
                      <select
                        value={feeStatusFilter}
                        onChange={(e) => { setFeeStatusFilter(e.target.value as any); setFeePage(1); }}
                        className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="ALL">All Invoices</option>
                        <option value="PAID">Paid Only</option>
                        <option value="PENDING">Pending Only</option>
                        <option value="OVERDUE">Overdue Only</option>
                      </select>
                    </div>

                    {/* Class Filter */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#F4F8F5] border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <span className="text-[#2D5A4E] text-[11px] font-mono">Class:</span>
                      <select
                        value={feeClassFilter}
                        onChange={(e) => { setFeeClassFilter(e.target.value); setFeePage(1); }}
                        className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="ALL">All Classes</option>
                        <option value="Nursery">Nursery</option>
                        <option value="LKG">LKG</option>
                        <option value="UKG">UKG</option>
                        {Array.from({ length: 12 }, (_, i) => i + 1).map(num => (
                          <option key={num} value={`Class ${num}`}>{`Class ${num}`}</option>
                        ))}
                      </select>
                    </div>

                    {/* Payment Mode Filter */}
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#F4F8F5] border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <span className="text-[#2D5A4E] text-[11px] font-mono">Mode:</span>
                      <select
                        value={feePaymentModeFilter}
                        onChange={(e) => { setFeePaymentModeFilter(e.target.value); setFeePage(1); }}
                        className="bg-transparent border-none text-xs font-semibold text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="ALL">All Modes</option>
                        <option value="UPI">UPI / Online</option>
                        <option value="Cash">Cash</option>
                        <option value="Bank">Bank Transfer</option>
                      </select>
                    </div>

                    {/* Sort Dropdown */}
                    <div className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#F4F8F5] border border-[#DCE8E0] rounded-full text-xs font-medium text-[#122A24] shadow-2xs">
                      <ArrowUpDown className="h-3 w-3 text-[#2D5A4E]" />
                      <select
                        value={feeSortBy}
                        onChange={(e) => setFeeSortBy(e.target.value as any)}
                        className="bg-transparent border-none text-xs font-medium text-[#122A24] focus:outline-none cursor-pointer pr-1"
                      >
                        <option value="Date-Desc">Due Date (Latest)</option>
                        <option value="Date-Asc">Due Date (Oldest)</option>
                        <option value="Amount-Desc">Amount (High - Low)</option>
                        <option value="Amount-Asc">Amount (Low - High)</option>
                      </select>
                    </div>
                  </div>

                  {/* Search bar */}
                  <div className="relative w-full sm:w-72">
                    <Search className="absolute left-3.5 top-2.5 h-3.5 w-3.5 text-[#2D5A4E]" />
                    <input
                      type="text"
                      placeholder="Search by student, invoice no, class..."
                      value={searchQuery}
                      onChange={(e) => { setSearchQuery(e.target.value); setFeePage(1); }}
                      className="w-full pl-9 pr-4 py-1.5 bg-[#F4F8F5] border border-[#DCE8E0] rounded-full text-xs text-[#122A24] placeholder-slate-400 focus:outline-none focus:bg-white focus:border-[#10B981] transition-all shadow-2xs"
                    />
                  </div>
                </div>

                {/* Active Filter Badges */}
                {(feeStatusFilter !== 'ALL' || feeClassFilter !== 'ALL' || feePaymentModeFilter !== 'ALL' || searchQuery.trim() !== '') && (
                  <div className="flex flex-wrap items-center gap-2 px-1 text-xs">
                    <span className="text-[11px] font-mono text-[#2D5A4E] font-bold">Active Filters:</span>
                    {feeStatusFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Status: {feeStatusFilter}
                        <button onClick={() => setFeeStatusFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {feeClassFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Class: {feeClassFilter}
                        <button onClick={() => setFeeClassFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {feePaymentModeFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Mode: {feePaymentModeFilter}
                        <button onClick={() => setFeePaymentModeFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {searchQuery.trim() !== '' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Query: &ldquo;{searchQuery}&rdquo;
                        <button onClick={() => setSearchQuery('')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    <button
                      onClick={() => {
                        setFeeStatusFilter('ALL');
                        setFeeClassFilter('ALL');
                        setFeePaymentModeFilter('ALL');
                        setSearchQuery('');
                      }}
                      className="text-[11px] font-mono font-bold text-rose-600 hover:underline border-none bg-transparent cursor-pointer px-1"
                    >
                      Clear All
                    </button>
                  </div>
                )}

                {/* Invoices Master Table */}
                <div className="rounded-2xl border border-[#DCE8E0] overflow-hidden bg-white shadow-2xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="bg-[#F3F7F5] font-mono text-[11px] font-bold text-[#1C443A] uppercase tracking-wider border-b border-[#DCE8E0]">
                        <tr>
                          <th className="py-3 px-4">Invoice No</th>
                          <th className="py-3 px-4">Student &amp; Class</th>
                          <th className="py-3 px-4">Breakdown</th>
                          <th className="py-3 px-4">Total Amount</th>
                          <th className="py-3 px-4">Due Date</th>
                          <th className="py-3 px-4">Status</th>
                          <th className="py-3 px-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#EBF2ED] font-sans">
                        {paginatedInvoices.map(inv => (
                          <tr key={inv.id} className="hover:bg-[#F9FCFA] transition-colors">
                            <td className="py-3.5 px-4 font-mono font-bold text-[#122A24]">
                              {inv.invoice_no}
                            </td>
                            <td className="py-3.5 px-4">
                              <div className="font-semibold text-[#122A24]">{inv.student_name}</div>
                              <div className="text-[#2D5A4E] font-mono text-[11px]">{inv.class_name} {inv.admission_no ? `• ${inv.admission_no}` : ''}</div>
                            </td>
                            <td className="py-3.5 px-4 text-[#2D5A4E] font-mono text-[11px]">
                              Tuition: ₹{(inv.tuition_fee || inv.amount).toLocaleString()} {inv.transport_fee ? `+ Trans: ₹${inv.transport_fee}` : ''}
                            </td>
                            <td className="py-3.5 px-4 font-display font-bold text-sm text-[#122A24]">
                              ₹{inv.amount.toLocaleString()}
                            </td>
                            <td className="py-3.5 px-4 font-mono text-[#2D5A4E]">
                              {inv.due_date}
                            </td>
                            <td className="py-3.5 px-4">
                              <button
                                onClick={() => handleToggleInvoiceStatus(inv)}
                                className={`font-mono text-[10px] px-2.5 py-1 rounded-full font-bold cursor-pointer border transition-colors ${
                                  inv.status === 'PAID'
                                    ? 'bg-[#EBF5EF] text-[#1C443A] border-[#C5E2CF] hover:bg-[#D9EDE0]'
                                    : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
                                }`}
                                title="Click to toggle status"
                              >
                                {inv.status === 'PAID' ? '✓ PAID' : '⏳ PENDING'}
                              </button>
                            </td>
                            <td className="py-3.5 px-4 text-right space-x-1.5">
                              <button
                                onClick={() => setViewInvoice(inv)}
                                className="px-3 py-1 bg-[#122A24] hover:bg-[#1C443A] text-white text-[11px] font-semibold rounded-full shadow-xs cursor-pointer border-none inline-flex items-center gap-1 transition-colors"
                                title="View & Print Official Slip"
                              >
                                <Printer className="h-3 w-3" /> Slip
                              </button>
                              <button
                                onClick={() => handleDeleteInvoice(inv.id)}
                                className="p-1.5 text-slate-400 hover:text-rose-600 rounded-full hover:bg-rose-50 border-none bg-transparent cursor-pointer inline-flex items-center transition-colors"
                                title="Delete Invoice"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                        {paginatedInvoices.length === 0 && (
                          <tr>
                            <td colSpan={7} className="py-12 text-center text-xs text-[#2D5A4E] font-mono">
                              No fee invoices found matching your filter criteria. Click "Issue Fee Invoice" to generate slips.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Fee Pagination */}
                  <div className="p-3.5 border-t border-[#DCE8E0] bg-[#F8FAF9] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-[#2D5A4E]">
                    <div>
                      Showing {totalFeeEntries === 0 ? 0 : (feePage - 1) * feeRowsPerPage + 1} to {Math.min(feePage * feeRowsPerPage, totalFeeEntries)} of {totalFeeEntries} Invoices
                    </div>

                    <div className="flex items-center gap-1 self-end sm:self-auto">
                      <button
                        onClick={() => setFeePage(Math.max(1, feePage - 1))}
                        disabled={feePage === 1}
                        className="px-3 py-1 rounded-lg border border-[#DCE8E0] bg-white text-[#122A24] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#EBF5EF] cursor-pointer font-medium transition-colors"
                      >
                        Prev
                      </button>

                      {Array.from({ length: totalFeePages }, (_, i) => i + 1).slice(0, 5).map(pageNum => (
                        <button
                          key={pageNum}
                          onClick={() => setFeePage(pageNum)}
                          className={`w-7 h-7 rounded-lg border text-xs font-semibold cursor-pointer transition-colors ${
                            feePage === pageNum
                              ? 'bg-[#122A24] border-[#122A24] text-white shadow-xs'
                              : 'bg-white border-[#DCE8E0] text-[#122A24] hover:bg-[#EBF5EF]'
                          }`}
                        >
                          {pageNum}
                        </button>
                      ))}

                      <button
                        onClick={() => setFeePage(Math.min(totalFeePages, feePage + 1))}
                        disabled={feePage === totalFeePages || totalFeePages === 0}
                        className="px-3 py-1 rounded-lg border border-[#DCE8E0] bg-white text-[#122A24] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#EBF5EF] cursor-pointer font-medium transition-colors"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: NOTICES (THEME-ALIGNED WITH ADVANCED AUDIENCE FILTERS) */}
          {activeTab === 'notices' && (
            <div className="space-y-5 max-w-7xl mx-auto animate-fade-in">
              <div className="bg-white rounded-3xl border border-[#DCE8E0] shadow-xs p-5 sm:p-7 space-y-5">
                {/* Header & Primary Action */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E8F0EA]">
                  <div>
                    <div className="flex items-center gap-3">
                      <h1 className="font-display font-bold text-2xl sm:text-3xl text-[#122A24] tracking-tight">
                        Institutional Notice Board
                      </h1>
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF]">
                        {filteredNotices.length} Circulars
                      </span>
                    </div>
                    <p className="text-xs text-[#2D5A4E] mt-0.5 font-mono">
                      Publish circulars and announcements for students, teachers, and parents
                    </p>
                  </div>
                  <button
                    onClick={() => setShowAddNotice(true)}
                    className="px-4 py-2 bg-[#122A24] hover:bg-[#1C443A] text-white rounded-full text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-all border-none cursor-pointer"
                  >
                    <Plus className="h-4 w-4" /> Post Notice
                  </button>
                </div>

                {/* Filter Toolbar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-mono text-[#2D5A4E] font-bold">Target Audience:</span>
                    {(['ALL', 'TEACHERS', 'STUDENTS', 'PARENTS'] as const).map(aud => (
                      <button
                        key={aud}
                        onClick={() => setNoticeAudienceFilter(aud)}
                        className={`px-3 py-1.5 rounded-full text-xs font-mono font-semibold cursor-pointer transition-all border ${
                          noticeAudienceFilter === aud
                            ? 'bg-[#122A24] text-white border-[#122A24] shadow-xs'
                            : 'bg-[#F4F8F5] text-[#122A24] border-[#DCE8E0] hover:bg-[#EBF5EF]'
                        }`}
                      >
                        {aud === 'ALL' ? 'All Audiences' : aud}
                      </button>
                    ))}
                  </div>

                  <div className="relative w-full sm:w-72">
                    <Search className="absolute left-3.5 top-2.5 h-3.5 w-3.5 text-[#2D5A4E]" />
                    <input
                      type="text"
                      placeholder="Search circulars by title, author, content..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-9 pr-4 py-1.5 bg-[#F4F8F5] border border-[#DCE8E0] rounded-full text-xs text-[#122A24] placeholder-slate-400 focus:outline-none focus:bg-white focus:border-[#10B981] transition-all shadow-2xs"
                    />
                  </div>
                </div>

                {/* Active Filter Badges */}
                {(noticeAudienceFilter !== 'ALL' || searchQuery.trim() !== '') && (
                  <div className="flex flex-wrap items-center gap-2 px-1 text-xs">
                    <span className="text-[11px] font-mono text-[#2D5A4E] font-bold">Active Filters:</span>
                    {noticeAudienceFilter !== 'ALL' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Audience: {noticeAudienceFilter}
                        <button onClick={() => setNoticeAudienceFilter('ALL')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    {searchQuery.trim() !== '' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#EBF5EF] text-[#122A24] border border-[#C5E2CF]">
                        Query: &ldquo;{searchQuery}&rdquo;
                        <button onClick={() => setSearchQuery('')} className="hover:text-rose-600 cursor-pointer border-none bg-transparent p-0">✕</button>
                      </span>
                    )}
                    <button
                      onClick={() => {
                        setNoticeAudienceFilter('ALL');
                        setSearchQuery('');
                      }}
                      className="text-[11px] font-mono font-bold text-rose-600 hover:underline border-none bg-transparent cursor-pointer px-1"
                    >
                      Clear All
                    </button>
                  </div>
                )}

                {/* Circulars List */}
                <div className="space-y-4">
                  {filteredNotices.map(n => (
                    <div key={n.id} className="bg-white p-5 sm:p-6 rounded-2xl border border-[#DCE8E0] shadow-2xs space-y-2.5 relative group hover:border-[#10B981] transition-all">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <span className="font-mono text-[10.5px] uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-[#EBF5EF] text-[#1C443A] font-bold border border-[#C5E2CF]">
                            {n.target_audience}
                          </span>
                          <span className="text-xs text-[#2D5A4E] font-mono">Posted by {n.posted_by}</span>
                        </div>
                        <button
                          onClick={() => handleDeleteNotice(n.id)}
                          className="text-slate-400 hover:text-rose-600 border-none bg-transparent cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity p-1"
                          title="Delete Notice"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      <h3 className="font-display font-semibold text-lg text-[#122A24]">{n.title}</h3>
                      <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">{n.content}</p>
                    </div>
                  ))}
                  {filteredNotices.length === 0 && (
                    <div className="py-12 text-center text-xs text-[#2D5A4E] font-mono bg-[#F9FCFA] rounded-2xl border border-[#DCE8E0]">
                      No active notices found matching your filter. Click "+ Post Notice" above to publish circulars.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 8: SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-6 max-w-5xl mx-auto animate-fade-in">
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E8F0EA]">
                <div>
                  <div className="flex items-center gap-3">
                    <h1 className="font-display font-bold text-2xl sm:text-3xl text-[#122A24] tracking-tight">
                      Institutional &amp; Access Controls
                    </h1>
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#EBF5EF] text-[#1C443A] border border-[#C5E2CF]">
                      ⚡ Full Admin Powers Active
                    </span>
                  </div>
                  <p className="text-xs text-[#2D5A4E] mt-1">
                    Manage institutional identity, security PIN, CBSE compliance rules, and Role-Based Access Control (RBAC).
                  </p>
                </div>
              </div>

              {settingsSuccess && (
                <div className="p-4 bg-[#EBF5EF] border border-[#C5E2CF] text-[#1C443A] text-xs font-semibold rounded-2xl flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[#10B981]" />
                  <span>{settingsSuccess}</span>
                </div>
              )}

              {/* ADMIN POWERS & ROLE PERMISSION MATRIX */}
              <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#DCE8E0] shadow-xs space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-[#E8F0EA]">
                  <div className="flex items-center gap-2.5">
                    <span className="w-8 h-8 rounded-full bg-[#EBF5EF] text-[#122A24] flex items-center justify-center font-bold text-sm border border-[#C5E2CF]">
                      👑
                    </span>
                    <div>
                      <h2 className="font-display font-bold text-base text-[#122A24]">
                        Role-Based Access Control (RBAC) &amp; Authority
                      </h2>
                      <p className="text-[11px] text-[#2D5A4E]">
                        Admin has supreme execution rights. Actions are gated by role privileges.
                      </p>
                    </div>
                  </div>
                  <span className="px-3 py-1 bg-[#122A24] text-white font-mono text-xs font-bold rounded-full">
                    SUPERADMIN
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-1">
                  {/* Role 1: Super Admin */}
                  <div className="p-4 rounded-2xl bg-[#F9FCFA] border border-[#C5E2CF] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-[#122A24] flex items-center gap-1.5">
                        <ShieldCheck className="h-4 w-4 text-emerald-600" /> Admin / Principal
                      </span>
                      <span className="text-[9.5px] font-mono font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800">
                        Full Rights
                      </span>
                    </div>
                    <ul className="text-[11px] text-[#2D5A4E] space-y-1 pl-4 list-disc">
                      <li>Add, Edit &amp; Delete any entity</li>
                      <li>1-Click Active / Inactive toggles</li>
                      <li>Multi-select bulk operations</li>
                      <li>Staff &amp; Student PIN resets</li>
                      <li>Institutional settings &amp; fees</li>
                    </ul>
                  </div>

                  {/* Role 2: Teacher */}
                  <div className="p-4 rounded-2xl bg-white border border-[#DCE8E0] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-[#122A24] flex items-center gap-1.5">
                        <GraduationCap className="h-4 w-4 text-teal-600" /> Faculty / Staff
                      </span>
                      <span className="text-[9.5px] font-mono font-bold px-1.5 py-0.5 rounded bg-teal-50 text-teal-800 border border-teal-200">
                        Academic
                      </span>
                    </div>
                    <ul className="text-[11px] text-[#2D5A4E] space-y-1 pl-4 list-disc">
                      <li>Mark daily class attendance</li>
                      <li>View assigned class students</li>
                      <li>Publish academic notices</li>
                      <li>View personal schedule</li>
                    </ul>
                  </div>

                  {/* Role 3: Accountant */}
                  <div className="p-4 rounded-2xl bg-white border border-[#DCE8E0] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-[#122A24] flex items-center gap-1.5">
                        <CreditCard className="h-4 w-4 text-indigo-600" /> Accounts Desk
                      </span>
                      <span className="text-[9.5px] font-mono font-bold px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-800 border border-indigo-200">
                        Finance
                      </span>
                    </div>
                    <ul className="text-[11px] text-[#2D5A4E] space-y-1 pl-4 list-disc">
                      <li>Issue fee invoices &amp; dues</li>
                      <li>Collect UPI / Cash fees</li>
                      <li>Generate payment receipts</li>
                      <li>Export fee collection ledgers</li>
                    </ul>
                  </div>

                  {/* Role 4: Student */}
                  <div className="p-4 rounded-2xl bg-white border border-[#DCE8E0] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-[#122A24] flex items-center gap-1.5">
                        <Users className="h-4 w-4 text-slate-600" /> Student / Parent
                      </span>
                      <span className="text-[9.5px] font-mono font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">
                        Read-Only
                      </span>
                    </div>
                    <ul className="text-[11px] text-[#2D5A4E] space-y-1 pl-4 list-disc">
                      <li>View personal attendance</li>
                      <li>Download fee receipts</li>
                      <li>Read circulars &amp; timetable</li>
                      <li>Update basic contact info</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* INSTITUTIONAL SETTINGS FORM */}
              <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#DCE8E0] shadow-xs space-y-5">
                <div className="pb-3 border-b border-[#E8F0EA]">
                  <h2 className="font-display font-bold text-base text-[#122A24]">
                    Institutional Profile &amp; Security Credentials
                  </h2>
                  <p className="text-[11px] text-[#2D5A4E]">
                    Update official school parameters stored on MongoDB Atlas.
                  </p>
                </div>

                <form onSubmit={handleUpdateSettings} className="space-y-4 text-xs">
                  <div>
                    <label className="block font-semibold text-[#122A24] mb-1">Official School Name *</label>
                    <input
                      type="text"
                      required
                      value={settingsForm.school_name}
                      onChange={(e) => setSettingsForm({ ...settingsForm, school_name: e.target.value })}
                      className="w-full px-3.5 py-2.5 border border-[#DCE8E0] rounded-xl text-xs font-semibold text-[#122A24]"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold text-[#122A24] mb-1">Campus City / Location</label>
                      <input
                        type="text"
                        value={settingsForm.city}
                        onChange={(e) => setSettingsForm({ ...settingsForm, city: e.target.value })}
                        className="w-full px-3.5 py-2.5 border border-[#DCE8E0] rounded-xl text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[#122A24] mb-1">Curriculum Board</label>
                      <input
                        type="text"
                        value={settingsForm.board}
                        onChange={(e) => setSettingsForm({ ...settingsForm, board: e.target.value })}
                        className="w-full px-3.5 py-2.5 border border-[#DCE8E0] rounded-xl text-xs font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold text-[#122A24] mb-1">Principal / Administrator Name</label>
                      <input
                        type="text"
                        value={settingsForm.principal_name}
                        onChange={(e) => setSettingsForm({ ...settingsForm, principal_name: e.target.value })}
                        className="w-full px-3.5 py-2.5 border border-[#DCE8E0] rounded-xl text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-[#122A24] mb-1">Admin Master Security PIN *</label>
                      <input
                        type="text"
                        required
                        value={settingsForm.admin_pin}
                        onChange={(e) => setSettingsForm({ ...settingsForm, admin_pin: e.target.value })}
                        className="w-full px-3.5 py-2.5 border border-[#DCE8E0] rounded-xl font-mono text-xs font-bold text-[#122A24]"
                      />
                    </div>
                  </div>

                  <div className="pt-3 border-t border-[#E8F0EA] flex justify-end">
                    <button
                      type="submit"
                      className="px-6 py-2.5 bg-[#122A24] hover:bg-[#1C443A] text-white font-semibold rounded-full shadow-xs cursor-pointer border-none text-xs transition-colors"
                    >
                      Save Configuration
                    </button>
                  </div>
                </form>
              </div>

              {/* MONGODB ATLAS CLOUD SYNCHRONIZATION & DIAGNOSTICS CARD */}
              <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#DCE8E0] shadow-xs space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E8F0EA]">
                  <div className="flex items-center gap-2.5">
                    <span className="w-8 h-8 rounded-full bg-[#EBF5EF] text-[#122A24] flex items-center justify-center font-bold text-sm border border-[#C5E2CF]">
                      <Database className="h-4 w-4 text-emerald-700" />
                    </span>
                    <div>
                      <h2 className="font-display font-bold text-base text-[#122A24]">
                        MongoDB Atlas Cloud Storage &amp; Backup Hub
                      </h2>
                      <p className="text-[11px] text-[#2D5A4E]">
                        Real-time persistent synchronization between local storage engine and MongoDB Atlas Cloud.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleCheckMongoCloud}
                      disabled={mongoSyncLoading}
                      className="px-3.5 py-1.5 bg-[#F4F8F5] border border-[#DCE8E0] hover:bg-[#EBF5EF] text-[#122A24] rounded-full text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5"
                    >
                      <RefreshCw className={`h-3.5 w-3.5 text-[#2D5A4E] ${mongoSyncLoading ? 'animate-spin' : ''}`} />
                      <span>{mongoSyncLoading ? 'Checking...' : 'Test Cloud Connection'}</span>
                    </button>
                    <button
                      onClick={handlePushAllToMongo}
                      disabled={mongoSyncLoading}
                      className="px-4 py-1.5 bg-[#122A24] hover:bg-[#1C443A] text-white rounded-full text-xs font-semibold cursor-pointer shadow-xs transition-all flex items-center gap-1.5 border-none disabled:opacity-60"
                    >
                      <Download className="h-3.5 w-3.5 rotate-180" />
                      <span>Push &amp; Sync to Atlas Cloud</span>
                    </button>
                  </div>
                </div>

                {mongoSyncMsg && (
                  <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 space-y-2">
                    <div className="flex items-center gap-2 font-bold">
                      <AlertTriangle className="h-4 w-4 text-amber-700 shrink-0" />
                      <span>MongoDB Atlas Status Notice:</span>
                    </div>
                    <p className="leading-relaxed font-mono text-[11px]">
                      {mongoSyncMsg}
                    </p>
                    <div className="p-3 bg-white/80 rounded-xl border border-amber-200 text-[11px] text-[#122A24] space-y-1 font-sans">
                      <div className="font-bold text-emerald-800">💡 How to enable 100% unrestricted Cloud Sync in 30 seconds:</div>
                      <ol className="list-decimal pl-4 space-y-0.5 text-[#2D5A4E]">
                        <li>Go to <strong><a href="https://cloud.mongodb.com" target="_blank" rel="noreferrer" className="underline text-emerald-700">cloud.mongodb.com</a></strong> and log into your Atlas project.</li>
                        <li>Click <strong>Security ➔ Network Access</strong> in the left sidebar.</li>
                        <li>Click <strong>+ Add IP Address</strong> ➔ Choose <strong>"Allow Access from Anywhere" (0.0.0.0/0)</strong> ➔ Click <strong>Confirm</strong>.</li>
                        <li>Return here and click <strong>"Push &amp; Sync to Atlas Cloud"</strong>!</li>
                      </ol>
                    </div>
                  </div>
                )}

                {/* Persistent Data Stats */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 pt-1">
                  <div className="bg-[#F9FCFA] p-3.5 rounded-2xl border border-[#DCE8E0]">
                    <div className="text-[11px] font-mono text-[#2D5A4E]">Enrolled Scholars</div>
                    <div className="text-xl font-bold font-display text-[#122A24] mt-0.5">{students.length} Students</div>
                    <div className="text-[10px] text-emerald-700 mt-1 font-mono font-semibold">● 100% Persistent</div>
                  </div>
                  <div className="bg-[#F9FCFA] p-3.5 rounded-2xl border border-[#DCE8E0]">
                    <div className="text-[11px] font-mono text-[#2D5A4E]">Faculty Roster</div>
                    <div className="text-xl font-bold font-display text-[#122A24] mt-0.5">{teachers.length} Faculty</div>
                    <div className="text-[10px] text-emerald-700 mt-1 font-mono font-semibold">● 100% Persistent</div>
                  </div>
                  <div className="bg-[#F9FCFA] p-3.5 rounded-2xl border border-[#DCE8E0]">
                    <div className="text-[11px] font-mono text-[#2D5A4E]">Class Divisions</div>
                    <div className="text-xl font-bold font-display text-[#122A24] mt-0.5">{classes.length} Classes</div>
                    <div className="text-[10px] text-emerald-700 mt-1 font-mono font-semibold">● 100% Persistent</div>
                  </div>
                  <div className="bg-[#F9FCFA] p-3.5 rounded-2xl border border-[#DCE8E0]">
                    <div className="text-[11px] font-mono text-[#2D5A4E]">Fee Invoices</div>
                    <div className="text-xl font-bold font-display text-[#122A24] mt-0.5">{invoices.length} Invoices</div>
                    <div className="text-[10px] text-emerald-700 mt-1 font-mono font-semibold">● 100% Persistent</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* MOBILE BOTTOM APP NAVIGATION BAR (NATIVE APP EXPERIENCE) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#DCE8E0] px-1.5 py-1.5 flex justify-around items-center shadow-lg safe-bottom">
        {/* Overview Tab */}
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl border-none cursor-pointer transition-all ${
            activeTab === 'overview'
              ? 'text-[#122A24] font-bold bg-[#EBF5EF]'
              : 'text-slate-500 hover:text-[#122A24] bg-transparent'
          }`}
        >
          <BarChart3 className={`h-4 w-4 ${activeTab === 'overview' ? 'text-[#122A24] stroke-[2.5]' : 'stroke-[1.8]'}`} />
          <span className="text-[10px] mt-0.5 tracking-tight">Overview</span>
        </button>

        {/* Students Tab */}
        <button
          onClick={() => setActiveTab('students')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl border-none cursor-pointer relative transition-all ${
            activeTab === 'students'
              ? 'text-[#122A24] font-bold bg-[#EBF5EF]'
              : 'text-slate-500 hover:text-[#122A24] bg-transparent'
          }`}
        >
          <div className="relative">
            <Users className={`h-4 w-4 ${activeTab === 'students' ? 'text-[#122A24] stroke-[2.5]' : 'stroke-[1.8]'}`} />
            {students.length > 0 && (
              <span className="absolute -top-1 -right-2.5 px-1 min-w-[14px] h-3.5 rounded-full bg-[#122A24] text-white text-[8.5px] font-mono font-bold flex items-center justify-center">
                {students.length > 99 ? '99+' : students.length}
              </span>
            )}
          </div>
          <span className="text-[10px] mt-0.5 tracking-tight">Students</span>
        </button>

        {/* Faculty Tab */}
        <button
          onClick={() => setActiveTab('teachers')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl border-none cursor-pointer relative transition-all ${
            activeTab === 'teachers'
              ? 'text-[#122A24] font-bold bg-[#EBF5EF]'
              : 'text-slate-500 hover:text-[#122A24] bg-transparent'
          }`}
        >
          <div className="relative">
            <GraduationCap className={`h-4 w-4 ${activeTab === 'teachers' ? 'text-[#122A24] stroke-[2.5]' : 'stroke-[1.8]'}`} />
            {teachers.length > 0 && (
              <span className="absolute -top-1 -right-2 px-1 min-w-[14px] h-3.5 rounded-full bg-[#122A24] text-white text-[8.5px] font-mono font-bold flex items-center justify-center">
                {teachers.length}
              </span>
            )}
          </div>
          <span className="text-[10px] mt-0.5 tracking-tight">Faculty</span>
        </button>

        {/* Fees Tab */}
        <button
          onClick={() => setActiveTab('fees')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl border-none cursor-pointer relative transition-all ${
            activeTab === 'fees'
              ? 'text-[#122A24] font-bold bg-[#EBF5EF]'
              : 'text-slate-500 hover:text-[#122A24] bg-transparent'
          }`}
        >
          <div className="relative">
            <CreditCard className={`h-4 w-4 ${activeTab === 'fees' ? 'text-[#122A24] stroke-[2.5]' : 'stroke-[1.8]'}`} />
            {invoices.filter(i => i.status !== 'PAID').length > 0 && (
              <span className="absolute -top-1 -right-2 px-1 min-w-[14px] h-3.5 rounded-full bg-rose-600 text-white text-[8.5px] font-mono font-bold flex items-center justify-center">
                {invoices.filter(i => i.status !== 'PAID').length}
              </span>
            )}
          </div>
          <span className="text-[10px] mt-0.5 tracking-tight">Fees</span>
        </button>

        {/* More / Menu Drawer Toggle */}
        <button
          onClick={() => setMobileMenuOpen(true)}
          className="flex flex-col items-center justify-center py-1 px-2.5 rounded-xl border-none cursor-pointer text-slate-500 hover:text-[#122A24] bg-transparent transition-all"
        >
          <Menu className="h-4 w-4 stroke-[1.8]" />
          <span className="text-[10px] mt-0.5 tracking-tight">More</span>
        </button>
      </nav>

      {/* MODAL: COMPREHENSIVE CBSE STUDENT ENROLLMENT & EDIT (SINGLE-PAGE SECTION-WISE FORM) */}
      {showStudentModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white rounded-t-3xl sm:rounded-3xl border border-[#DCE8E0] max-w-3xl w-full shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
            {/* Modal Header */}
            <div className="p-6 border-b border-slate-100 flex justify-between items-start bg-slate-50/70">
              <div>
                <span className="font-mono text-[10px] text-[var(--red-pen)] font-bold uppercase tracking-wider">
                  CBSE OASIS &amp; SARAS Compliance Form
                </span>
                <h2 className="font-display font-semibold text-xl text-[var(--ink-navy)] mt-0.5">
                  {editingStudentId ? 'Edit Student & CBSE OASIS Record' : 'Student Admission Form'}
                </h2>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  Basic details (Section 1) are required for quick save. You can fill the remaining CBSE sections now or update anytime later.
                </p>
              </div>
              <button
                onClick={() => setShowStudentModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg border-none bg-transparent cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Scrollable Form Body with Unified Sections */}
            <form onSubmit={handleSaveStudent} className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
              {/* SECTION 1: BASIC ENROLLMENT (REQUIRED) */}
              <div className="p-4 bg-emerald-50/40 rounded-xl border border-emerald-200/80 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[var(--ink-navy)] text-white font-mono font-bold text-[11px] flex items-center justify-center">1</span>
                    <span className="font-display font-semibold text-sm text-[var(--ink-navy)]">Basic Student &amp; Guardian Info</span>
                  </div>
                  <span className="font-mono text-[10px] uppercase font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                    Required for quick save
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Student Full Name *</label>
                    <input
                      type="text"
                      required
                      value={studentForm.full_name || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, full_name: e.target.value })}
                      placeholder="e.g. Aarav Sharma"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Admission No (Login User ID) *</label>
                    <input
                      type="text"
                      required
                      value={studentForm.admission_no || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, admission_no: e.target.value })}
                      placeholder="e.g. ADM-2026-0042"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs bg-white font-semibold text-[var(--red-pen)]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Login Passcode / PIN *</label>
                    <input
                      type="text"
                      required
                      value={studentForm.passcode || '123456'}
                      onChange={(e) => setStudentForm({ ...studentForm, passcode: e.target.value })}
                      placeholder="e.g. 123456"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs bg-white font-semibold text-emerald-800"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Class Enrolled *</label>
                    <select
                      required
                      value={studentForm.class_name || 'Class 10'}
                      onChange={(e) => setStudentForm({ ...studentForm, class_name: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white font-medium"
                    >
                      <optgroup label="Pre-Primary / Foundational">
                        <option value="Nursery">Nursery</option>
                        <option value="LKG">LKG / KG-I</option>
                        <option value="UKG">UKG / KG-II</option>
                      </optgroup>
                      <optgroup label="Primary (Classes 1 to 5)">
                        <option value="Class 1">Class 1</option>
                        <option value="Class 2">Class 2</option>
                        <option value="Class 3">Class 3</option>
                        <option value="Class 4">Class 4</option>
                        <option value="Class 5">Class 5</option>
                      </optgroup>
                      <optgroup label="Middle (Classes 6 to 8)">
                        <option value="Class 6">Class 6</option>
                        <option value="Class 7">Class 7</option>
                        <option value="Class 8">Class 8</option>
                      </optgroup>
                      <optgroup label="Secondary (Classes 9 & 10)">
                        <option value="Class 9">Class 9</option>
                        <option value="Class 10">Class 10</option>
                      </optgroup>
                      <optgroup label="Senior Secondary (Classes 11 & 12)">
                        <option value="Class 11">Class 11</option>
                        <option value="Class 12">Class 12</option>
                      </optgroup>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Section *</label>
                    <select
                      required
                      value={studentForm.section || 'A'}
                      onChange={(e) => setStudentForm({ ...studentForm, section: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white font-medium font-mono"
                    >
                      <option value="A">Section A</option>
                      <option value="B">Section B</option>
                      <option value="C">Section C</option>
                      <option value="D">Section D</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Roll No</label>
                    <input
                      type="text"
                      value={studentForm.roll_no || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, roll_no: e.target.value })}
                      placeholder="101"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Primary Guardian / Parent Name *</label>
                    <input
                      type="text"
                      required
                      value={studentForm.guardian_name || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, guardian_name: e.target.value })}
                      placeholder="e.g. Ramesh Sharma"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Guardian Mobile Phone *</label>
                    <input
                      type="tel"
                      required
                      value={studentForm.guardian_phone || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, guardian_phone: e.target.value })}
                      placeholder="+91 98111..."
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Gender *</label>
                    <select
                      value={studentForm.gender || 'Male'}
                      onChange={(e) => setStudentForm({ ...studentForm, gender: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">School House</label>
                    <select
                      value={studentForm.house || 'Red House'}
                      onChange={(e) => setStudentForm({ ...studentForm, house: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs font-medium"
                    >
                      <option value="Red House">🔴 Red House (Tagore)</option>
                      <option value="Blue House">🔵 Blue House (Shivaji)</option>
                      <option value="Green House">🟢 Green House (Ashoka)</option>
                      <option value="Yellow House">🟡 Yellow House (Raman)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Fee Status</label>
                    <select
                      value={studentForm.fee_status || 'PENDING'}
                      onChange={(e) => setStudentForm({ ...studentForm, fee_status: e.target.value as any })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs font-semibold"
                    >
                      <option value="PAID">PAID</option>
                      <option value="PENDING">PENDING</option>
                      <option value="OVERDUE">OVERDUE</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* SECTION 2: CBSE ACADEMIC & IDENTIFIERS */}
              <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[var(--board-1)] text-white font-mono font-bold text-[11px] flex items-center justify-center">2</span>
                    <span className="font-display font-semibold text-sm text-[var(--ink-navy)]">CBSE Academic &amp; PEN Details</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">Optional / Can fill later</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">
                      APAAR / PEN (Permanent Education Number - CBSE Mandate)
                    </label>
                    <input
                      type="text"
                      value={studentForm.apaar_id || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, apaar_id: e.target.value })}
                      placeholder="12-digit PEN ID"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Date of Admission</label>
                    <input
                      type="date"
                      value={studentForm.admission_date || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, admission_date: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Medium of Instruction</label>
                    <select
                      value={studentForm.medium_of_instruction || 'ENGLISH'}
                      onChange={(e) => setStudentForm({ ...studentForm, medium_of_instruction: e.target.value as any })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      <option value="ENGLISH">English</option>
                      <option value="HINDI">Hindi</option>
                      <option value="REGIONAL">Regional</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Previous School Name</label>
                    <input
                      type="text"
                      value={studentForm.previous_school || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, previous_school: e.target.value })}
                      placeholder="e.g. St. Xavier School"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">TC / Migration No</label>
                    <input
                      type="text"
                      value={studentForm.transfer_certificate_no || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, transfer_certificate_no: e.target.value })}
                      placeholder="TC-2025-88"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 3: PERSONAL & DEMOGRAPHIC */}
              <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[var(--board-1)] text-white font-mono font-bold text-[11px] flex items-center justify-center">3</span>
                    <span className="font-display font-semibold text-sm text-[var(--ink-navy)]">Personal &amp; Demographic Profile (CBSE SARAS)</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">Optional</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Date of Birth (DOB)</label>
                    <input
                      type="date"
                      value={studentForm.dob || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, dob: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Blood Group</label>
                    <select
                      value={studentForm.blood_group || 'O+'}
                      onChange={(e) => setStudentForm({ ...studentForm, blood_group: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      <option value="A+">A+</option>
                      <option value="A-">A-</option>
                      <option value="B+">B+</option>
                      <option value="B-">B-</option>
                      <option value="O+">O+</option>
                      <option value="O-">O-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB-</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Student Aadhaar Number</label>
                    <input
                      type="text"
                      value={studentForm.aadhaar_no || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, aadhaar_no: e.target.value })}
                      placeholder="12-digit UIDAI number"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Category (CBSE)</label>
                    <select
                      value={studentForm.category || 'GENERAL'}
                      onChange={(e) => setStudentForm({ ...studentForm, category: e.target.value as any })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      <option value="GENERAL">General</option>
                      <option value="OBC">OBC</option>
                      <option value="SC">SC</option>
                      <option value="ST">ST</option>
                      <option value="EWS">EWS</option>
                      <option value="MINORITY">Minority</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Religion</label>
                    <input
                      type="text"
                      value={studentForm.religion || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, religion: e.target.value })}
                      placeholder="Hindu / Muslim / Sikh / Christian"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Single Girl Child?</label>
                    <select
                      value={studentForm.single_girl_child || 'NO'}
                      onChange={(e) => setStudentForm({ ...studentForm, single_girl_child: e.target.value as any })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      <option value="NO">No</option>
                      <option value="YES">Yes</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">CWSN (Specially Abled)?</label>
                    <select
                      value={studentForm.cwsn_status || 'NO'}
                      onChange={(e) => setStudentForm({ ...studentForm, cwsn_status: e.target.value as any })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      <option value="NO">No</option>
                      <option value="YES">Yes</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* SECTION 4: PARENTS & FAMILY */}
              <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[var(--board-1)] text-white font-mono font-bold text-[11px] flex items-center justify-center">4</span>
                    <span className="font-display font-semibold text-sm text-[var(--ink-navy)]">Parents &amp; Family Profile</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">Optional</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Father Details */}
                  <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-2.5">
                    <div className="font-semibold text-[var(--ink-navy)] text-xs border-b border-slate-100 pb-1">Father Details</div>
                    <div>
                      <label className="block text-[11px] text-slate-500 mb-0.5">Father Full Name</label>
                      <input
                        type="text"
                        value={studentForm.father_name || ''}
                        onChange={(e) => setStudentForm({ ...studentForm, father_name: e.target.value })}
                        className="w-full px-2.5 py-1.5 border border-slate-300 rounded text-xs"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-0.5">Occupation</label>
                        <input
                          type="text"
                          value={studentForm.father_occupation || ''}
                          onChange={(e) => setStudentForm({ ...studentForm, father_occupation: e.target.value })}
                          className="w-full px-2.5 py-1.5 border border-slate-300 rounded text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-0.5">Annual Income (₹)</label>
                        <input
                          type="text"
                          value={studentForm.father_income || ''}
                          onChange={(e) => setStudentForm({ ...studentForm, father_income: e.target.value })}
                          className="w-full px-2.5 py-1.5 border border-slate-300 rounded text-xs"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Mother Details */}
                  <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-2.5">
                    <div className="font-semibold text-[var(--ink-navy)] text-xs border-b border-slate-100 pb-1">Mother Details</div>
                    <div>
                      <label className="block text-[11px] text-slate-500 mb-0.5">Mother Full Name</label>
                      <input
                        type="text"
                        value={studentForm.mother_name || ''}
                        onChange={(e) => setStudentForm({ ...studentForm, mother_name: e.target.value })}
                        className="w-full px-2.5 py-1.5 border border-slate-300 rounded text-xs"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-0.5">Occupation</label>
                        <input
                          type="text"
                          value={studentForm.mother_occupation || ''}
                          onChange={(e) => setStudentForm({ ...studentForm, mother_occupation: e.target.value })}
                          className="w-full px-2.5 py-1.5 border border-slate-300 rounded text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-0.5">Phone Number</label>
                        <input
                          type="tel"
                          value={studentForm.mother_phone || ''}
                          onChange={(e) => setStudentForm({ ...studentForm, mother_phone: e.target.value })}
                          className="w-full px-2.5 py-1.5 border border-slate-300 rounded text-xs"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION 5: ADDRESS & TRANSPORT */}
              <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[var(--board-1)] text-white font-mono font-bold text-[11px] flex items-center justify-center">5</span>
                    <span className="font-display font-semibold text-sm text-[var(--ink-navy)]">Residential Address &amp; Transport</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">Optional</span>
                </div>

                <div>
                  <label className="block font-semibold text-[var(--ink-navy)] mb-1">Residential Address</label>
                  <textarea
                    value={studentForm.residential_address || ''}
                    onChange={(e) => setStudentForm({ ...studentForm, residential_address: e.target.value })}
                    placeholder="House/Flat No, Street, Locality..."
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs min-h-[55px] bg-white"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">City</label>
                    <input
                      type="text"
                      value={studentForm.city || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, city: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">State</label>
                    <input
                      type="text"
                      value={studentForm.state || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, state: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">PIN Code</label>
                    <input
                      type="text"
                      value={studentForm.pincode || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, pincode: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 pt-2 border-t border-slate-200">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Transport Required?</label>
                    <select
                      value={studentForm.transport_opted || 'NO'}
                      onChange={(e) => setStudentForm({ ...studentForm, transport_opted: e.target.value as any })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      <option value="NO">No (Self Conveyance)</option>
                      <option value="YES">Yes (School Bus / Van)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Bus Route No</label>
                    <input
                      type="text"
                      value={studentForm.bus_route_no || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, bus_route_no: e.target.value })}
                      placeholder="Route #4"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Pickup Point</label>
                    <input
                      type="text"
                      value={studentForm.pickup_point || ''}
                      onChange={(e) => setStudentForm({ ...studentForm, pickup_point: e.target.value })}
                      placeholder="Main Chowk"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* Bottom Sticky Action Bar */}
              <div className="sticky bottom-0 bg-white pt-4 border-t border-slate-200 flex justify-between items-center z-10 shadow-sm">
                <div className="text-[11px] text-slate-500 font-mono">
                  {editingStudentId ? 'Updating student profile' : 'Quick Save: Only Section 1 required'}
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setShowStudentModal(false)}
                    className="px-4 py-2 border border-slate-300 rounded-lg text-slate-600 hover:bg-slate-50 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-[var(--ink-navy)] hover:bg-[var(--board-2)] text-white font-semibold rounded-lg cursor-pointer border-none shadow-sm"
                  >
                    {editingStudentId ? 'Save CBSE Profile Updates' : 'Save Student Registration'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: COMPREHENSIVE CBSE TEACHER & EMPLOYEE REGISTRATION (SINGLE-PAGE SECTION-WISE FORM) */}
      {showTeacherModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white rounded-t-3xl sm:rounded-3xl border border-[#DCE8E0] max-w-3xl w-full shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
            {/* Modal Header */}
            <div className="p-6 border-b border-slate-100 flex justify-between items-start bg-slate-50/70">
              <div>
                <span className="font-mono text-[10px] text-[var(--red-pen)] font-bold uppercase tracking-wider">
                  CBSE Affiliation Bye-Laws &amp; OASIS Standards
                </span>
                <h2 className="font-display font-semibold text-xl text-[var(--ink-navy)] mt-0.5">
                  {editingTeacherId ? 'Edit Faculty & CBSE Staff Record' : 'Faculty & Staff Registration Form'}
                </h2>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  Basic staff info (Section 1) is required for quick save. Complete qualifications and statutory details now or anytime later.
                </p>
              </div>
              <button
                onClick={() => setShowTeacherModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg border-none bg-transparent cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Scrollable Form Body with Unified Sections */}
            <form onSubmit={handleSaveTeacher} className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
              {/* SECTION 1: BASIC STAFF INFO (REQUIRED) */}
              <div className="p-4 bg-emerald-50/40 rounded-xl border border-emerald-200/80 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[var(--ink-navy)] text-white font-mono font-bold text-[11px] flex items-center justify-center">1</span>
                    <span className="font-display font-semibold text-sm text-[var(--ink-navy)]">Basic Faculty &amp; Contact Info</span>
                  </div>
                  <span className="font-mono text-[10px] uppercase font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                    Required for quick save
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Faculty Full Name *</label>
                    <input
                      type="text"
                      required
                      value={teacherForm.full_name || ''}
                      onChange={(e) => setTeacherForm({ ...teacherForm, full_name: e.target.value })}
                      placeholder="e.g. Dr. Sunita Mehra"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-medium bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Staff Code (Login User ID) *</label>
                    <input
                      type="text"
                      required
                      value={teacherForm.staff_code || ''}
                      onChange={(e) => setTeacherForm({ ...teacherForm, staff_code: e.target.value })}
                      placeholder="e.g. STF-104"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs font-semibold bg-white"
                    />
                    <span className="text-[10px] text-slate-500 font-mono">Faculty portal User ID</span>
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Login Passcode / PIN *</label>
                    <input
                      type="text"
                      required
                      value={teacherForm.passcode || '123456'}
                      onChange={(e) => setTeacherForm({ ...teacherForm, passcode: e.target.value })}
                      placeholder="e.g. 123456"
                      className="w-full px-3 py-2 border border-blue-200 bg-blue-50/40 rounded-lg font-mono text-xs font-semibold text-[var(--ink-navy)]"
                    />
                    <span className="text-[10px] text-slate-500 font-mono">Default: 123456</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Post / Designation (CBSE OASIS) *</label>
                    <select
                      value={isCustomRole ? 'CUSTOM' : (teacherForm.designation || STANDARD_DESIGNATIONS[0])}
                      onChange={(e) => {
                        if (e.target.value === 'CUSTOM') {
                          setIsCustomRole(true);
                          setTeacherForm({ ...teacherForm, designation: customRoleText || 'Custom Designation' });
                        } else {
                          setIsCustomRole(false);
                          setTeacherForm({ ...teacherForm, designation: e.target.value });
                        }
                      }}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs font-medium"
                    >
                      {STANDARD_DESIGNATIONS.map(d => (
                        <option key={d} value={d}>{d}</option>
                      ))}
                      <option value="CUSTOM">Custom Role / Other Designation (Specify Below...)</option>
                    </select>
                    {isCustomRole && (
                      <div className="mt-2 animate-fade-in">
                        <label className="block text-[10.5px] text-slate-500 font-semibold mb-0.5">Specify Custom Designation / Role *</label>
                        <input
                          type="text"
                          required
                          value={customRoleText}
                          onChange={(e) => {
                            setCustomRoleText(e.target.value);
                            setTeacherForm({ ...teacherForm, designation: e.target.value });
                          }}
                          placeholder="e.g. Activity Coordinator / IT Head / Dance Master"
                          className="w-full px-2.5 py-1.5 border border-amber-300 bg-amber-50/50 rounded-lg text-xs font-semibold text-[var(--ink-navy)]"
                        />
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Academic Department (CBSE Stream) *</label>
                    <select
                      value={isCustomDept ? 'CUSTOM' : (teacherForm.department || STANDARD_DEPARTMENTS[0])}
                      onChange={(e) => {
                        if (e.target.value === 'CUSTOM') {
                          setIsCustomDept(true);
                          setTeacherForm({ ...teacherForm, department: customDeptText || 'Custom Department' });
                        } else {
                          setIsCustomDept(false);
                          setTeacherForm({ ...teacherForm, department: e.target.value });
                        }
                      }}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      {STANDARD_DEPARTMENTS.map(d => (
                        <option key={d} value={d}>{d}</option>
                      ))}
                      <option value="CUSTOM">Other Department (Specify Below...)</option>
                    </select>
                    {isCustomDept && (
                      <div className="mt-2 animate-fade-in">
                        <label className="block text-[10.5px] text-slate-500 font-semibold mb-0.5">Specify Custom Department *</label>
                        <input
                          type="text"
                          required
                          value={customDeptText}
                          onChange={(e) => {
                            setCustomDeptText(e.target.value);
                            setTeacherForm({ ...teacherForm, department: e.target.value });
                          }}
                          placeholder="e.g. Robotics &amp; STEM / Foreign Languages"
                          className="w-full px-2.5 py-1.5 border border-amber-300 bg-amber-50/50 rounded-lg text-xs font-semibold text-[var(--ink-navy)]"
                        />
                      </div>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Primary Mobile Phone *</label>
                    <input
                      type="tel"
                      required
                      value={teacherForm.phone || ''}
                      onChange={(e) => setTeacherForm({ ...teacherForm, phone: e.target.value })}
                      placeholder="+91 98..."
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Official Email *</label>
                    <input
                      type="email"
                      required
                      value={teacherForm.email || ''}
                      onChange={(e) => setTeacherForm({ ...teacherForm, email: e.target.value })}
                      placeholder="teacher@school.edu"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 2: CBSE TEACHING QUALIFICATIONS & CREDENTIALS */}
              <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[var(--board-1)] text-white font-mono font-bold text-[11px] flex items-center justify-center">2</span>
                    <span className="font-display font-semibold text-sm text-[var(--ink-navy)]">CBSE Teaching Qualifications &amp; Credentials</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">CBSE Affiliation Norms</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">CBSE Teacher Level</label>
                    <select
                      value={teacherForm.teacher_type || 'TGT'}
                      onChange={(e) => setTeacherForm({ ...teacherForm, teacher_type: e.target.value as any })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs font-medium"
                    >
                      <option value="PGT">PGT (Post Graduate Teacher - Senior Secondary)</option>
                      <option value="TGT">TGT (Trained Graduate Teacher - Secondary/Middle)</option>
                      <option value="PRT">PRT (Primary Teacher - Classes I-V)</option>
                      <option value="NTT">NTT (Nursery Trained Teacher - Pre-Primary)</option>
                      <option value="ADMINISTRATIVE">Administrative / Support Staff</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Professional Qualification (CBSE Norms)</label>
                    <select
                      value={isCustomQual ? 'CUSTOM' : (teacherForm.professional_degree || STANDARD_QUALIFICATIONS[0])}
                      onChange={(e) => {
                        if (e.target.value === 'CUSTOM') {
                          setIsCustomQual(true);
                          setTeacherForm({ ...teacherForm, professional_degree: customQualText || 'Custom Qualification' });
                        } else {
                          setIsCustomQual(false);
                          setTeacherForm({ ...teacherForm, professional_degree: e.target.value });
                        }
                      }}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      {STANDARD_QUALIFICATIONS.map(q => (
                        <option key={q} value={q}>{q}</option>
                      ))}
                      <option value="CUSTOM">Other Qualification / Degree (Specify Below...)</option>
                    </select>
                    {isCustomQual && (
                      <div className="mt-2 animate-fade-in">
                        <label className="block text-[10.5px] text-slate-500 font-semibold mb-0.5">Specify Other Qualification / Degree *</label>
                        <input
                          type="text"
                          required
                          value={customQualText}
                          onChange={(e) => {
                            setCustomQualText(e.target.value);
                            setTeacherForm({ ...teacherForm, professional_degree: e.target.value });
                          }}
                          placeholder="e.g. M.Phil in English / B.Des / Diploma in Music"
                          className="w-full px-2.5 py-1.5 border border-amber-300 bg-amber-50/50 rounded-lg text-xs font-semibold text-[var(--ink-navy)]"
                        />
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">CTET / STET Status (CBSE Mandate)</label>
                    <select
                      value={teacherForm.ctet_qualified || 'YES'}
                      onChange={(e) => setTeacherForm({ ...teacherForm, ctet_qualified: e.target.value as any })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      <option value="YES">Yes (Qualified - CTET Paper 1 / 2 / STET)</option>
                      <option value="NO">No (Exempted / In-Progress / Non-Teaching)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Subject Specialization</label>
                    <select
                      value={isCustomSubject ? 'CUSTOM' : (teacherForm.subject_specialization || STANDARD_SUBJECTS[0])}
                      onChange={(e) => {
                        if (e.target.value === 'CUSTOM') {
                          setIsCustomSubject(true);
                          setTeacherForm({ ...teacherForm, subject_specialization: customSubjectText || 'Custom Subject' });
                        } else {
                          setIsCustomSubject(false);
                          setTeacherForm({ ...teacherForm, subject_specialization: e.target.value });
                        }
                      }}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      {STANDARD_SUBJECTS.map(s => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                      <option value="CUSTOM">Other Subject (Specify Below...)</option>
                    </select>
                    {isCustomSubject && (
                      <div className="mt-2 animate-fade-in">
                        <label className="block text-[10.5px] text-slate-500 font-semibold mb-0.5">Specify Other Subject *</label>
                        <input
                          type="text"
                          required
                          value={customSubjectText}
                          onChange={(e) => {
                            setCustomSubjectText(e.target.value);
                            setTeacherForm({ ...teacherForm, subject_specialization: e.target.value });
                          }}
                          placeholder="e.g. French / German / Astronomy"
                          className="w-full px-2.5 py-1.5 border border-amber-300 bg-amber-50/50 rounded-lg text-xs font-semibold text-[var(--ink-navy)]"
                        />
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Classes Handled (CBSE Stage)</label>
                    <select
                      value={teacherForm.classes_taught || 'Classes 9 & 10 (Secondary Stage - TGT)'}
                      onChange={(e) => setTeacherForm({ ...teacherForm, classes_taught: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      <option value="Classes 11 & 12 (Senior Secondary Stage - PGT)">Classes 11 &amp; 12 (Senior Secondary - PGT)</option>
                      <option value="Classes 9 & 10 (Secondary Stage - TGT)">Classes 9 &amp; 10 (Secondary Stage - TGT)</option>
                      <option value="Classes 6 to 8 (Middle Stage - Upper Primary)">Classes 6 to 8 (Middle Stage - Upper Primary)</option>
                      <option value="Classes 1 to 5 (Primary Stage - PRT)">Classes 1 to 5 (Primary Stage - PRT)</option>
                      <option value="Pre-Primary / Nursery / KG (Foundational Stage)">Pre-Primary / Nursery / KG (Foundational Stage)</option>
                      <option value="All Classes / Entire School (Specialist / Activity)">All Classes / Entire School (Activity/PET)</option>
                      <option value="Non-Teaching / Administrative Office">Non-Teaching / Administrative Office</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Experience (Years)</label>
                    <input
                      type="number"
                      value={teacherForm.experience_years ?? 5}
                      onChange={(e) => setTeacherForm({ ...teacherForm, experience_years: Number(e.target.value) })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Date of Joining</label>
                    <input
                      type="date"
                      value={teacherForm.date_of_joining || ''}
                      onChange={(e) => setTeacherForm({ ...teacherForm, date_of_joining: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Nature of Employment (CBSE Norm)</label>
                    <select
                      value={teacherForm.employment_type || 'PERMANENT'}
                      onChange={(e) => setTeacherForm({ ...teacherForm, employment_type: e.target.value as any })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      <option value="PERMANENT">Permanent (Regular CBSE Affiliation Pay Scale)</option>
                      <option value="PROBATION">Probation (Under Observation Period)</option>
                      <option value="CONTRACTUAL">Contractual (Term-Based Appointment)</option>
                      <option value="PART_TIME">Part-Time / Visiting Faculty</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* SECTION 3: PERSONAL & IDENTITY */}
              <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[var(--board-1)] text-white font-mono font-bold text-[11px] flex items-center justify-center">3</span>
                    <span className="font-display font-semibold text-sm text-[var(--ink-navy)]">Personal &amp; Identity Details</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">Optional</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Date of Birth</label>
                    <input
                      type="date"
                      value={teacherForm.dob || ''}
                      onChange={(e) => setTeacherForm({ ...teacherForm, dob: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Gender</label>
                    <select
                      value={teacherForm.gender || 'Female'}
                      onChange={(e) => setTeacherForm({ ...teacherForm, gender: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      <option value="Female">Female</option>
                      <option value="Male">Male</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Blood Group</label>
                    <select
                      value={teacherForm.blood_group || 'B+'}
                      onChange={(e) => setTeacherForm({ ...teacherForm, blood_group: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs"
                    >
                      <option value="A+">A+</option>
                      <option value="A-">A-</option>
                      <option value="B+">B+</option>
                      <option value="B-">B-</option>
                      <option value="O+">O+</option>
                      <option value="O-">O-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB-</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Aadhaar Number</label>
                    <input
                      type="text"
                      value={teacherForm.aadhaar_no || ''}
                      onChange={(e) => setTeacherForm({ ...teacherForm, aadhaar_no: e.target.value })}
                      placeholder="12-digit UIDAI number"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">PAN Card Number</label>
                    <input
                      type="text"
                      value={teacherForm.pan_no || ''}
                      onChange={(e) => setTeacherForm({ ...teacherForm, pan_no: e.target.value })}
                      placeholder="ABCDE1234F"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs uppercase bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Father / Spouse Name</label>
                    <input
                      type="text"
                      value={teacherForm.father_or_spouse_name || ''}
                      onChange={(e) => setTeacherForm({ ...teacherForm, father_or_spouse_name: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 4: STATUTORY, EPF & BANKING */}
              <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[var(--board-1)] text-white font-mono font-bold text-[11px] flex items-center justify-center">4</span>
                    <span className="font-display font-semibold text-sm text-[var(--ink-navy)]">Statutory, EPF &amp; Banking Details (CBSE Norm)</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">Optional</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">EPF / UAN Number (CBSE Mandate)</label>
                    <input
                      type="text"
                      value={teacherForm.epf_uan_no || ''}
                      onChange={(e) => setTeacherForm({ ...teacherForm, epf_uan_no: e.target.value })}
                      placeholder="12-digit Universal Account Number"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Monthly Basic Pay Scale (₹)</label>
                    <input
                      type="number"
                      value={teacherForm.basic_pay || 45000}
                      onChange={(e) => setTeacherForm({ ...teacherForm, basic_pay: Number(e.target.value) })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Salary Bank Name</label>
                    <input
                      type="text"
                      value={teacherForm.bank_name || ''}
                      onChange={(e) => setTeacherForm({ ...teacherForm, bank_name: e.target.value })}
                      placeholder="State Bank of India"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">Bank Account No</label>
                    <input
                      type="text"
                      value={teacherForm.bank_account_no || ''}
                      onChange={(e) => setTeacherForm({ ...teacherForm, bank_account_no: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[var(--ink-navy)] mb-1">IFSC Code</label>
                    <input
                      type="text"
                      value={teacherForm.bank_ifsc || ''}
                      onChange={(e) => setTeacherForm({ ...teacherForm, bank_ifsc: e.target.value })}
                      placeholder="SBIN0001234"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs uppercase bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* Bottom Sticky Action Bar */}
              <div className="sticky bottom-0 bg-white pt-4 border-t border-slate-200 flex justify-between items-center z-10 shadow-sm">
                <div className="text-[11px] text-slate-500 font-mono">
                  {editingTeacherId ? 'Updating faculty profile' : 'Quick Save: Only Section 1 required'}
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setShowTeacherModal(false)}
                    className="px-4 py-2 border border-slate-300 rounded-lg text-slate-600 hover:bg-slate-50 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-[var(--ink-navy)] hover:bg-[var(--board-2)] text-white font-semibold rounded-lg cursor-pointer border-none shadow-sm"
                  >
                    {editingTeacherId ? 'Save CBSE Staff Updates' : 'Save Staff Registration'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: PRINTABLE OFFICIAL FEE RECEIPT SLIP */}
      {viewInvoice && selectedSchool && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white rounded-t-3xl sm:rounded-3xl border border-[#DCE8E0] p-5 sm:p-8 max-w-xl w-full shadow-2xl space-y-5 animate-fade-up max-h-[92vh] overflow-y-auto">
            <div id="printable-receipt" className="border-2 border-slate-800 p-4 sm:p-6 rounded-xl space-y-4 sm:space-y-5 bg-white">
              <div className="flex justify-between items-start border-b-2 border-slate-800 pb-3 sm:pb-4">
                <div className="flex items-center gap-2.5 sm:gap-3">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#122A24] text-white flex items-center justify-center font-display font-bold text-lg sm:text-xl">
                    {schoolInitial}
                  </div>
                  <div>
                    <h2 className="font-display font-bold text-base sm:text-xl text-[#122A24] m-0 leading-tight">
                      {selectedSchool.school_name}
                    </h2>
                    <p className="text-[11px] sm:text-xs text-slate-600 m-0 font-mono">
                      Affiliated to {selectedSchool.board || 'CBSE'} • Campus: {selectedSchool.city || 'Central'}
                    </p>
                    <p className="text-[10px] text-slate-500 m-0 font-mono">
                      Institutional Code: <strong>{selectedSchool.school_code}</strong>
                    </p>
                  </div>
                </div>

                <div className="text-right font-mono">
                  <div className="text-[9.5px] sm:text-[10px] font-bold uppercase text-slate-400">Official Receipt</div>
                  <div className="text-xs sm:text-sm font-bold text-[#122A24]">{viewInvoice.invoice_no}</div>
                  <div className="text-[10px] sm:text-[11px] text-slate-500">{viewInvoice.due_date}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5 text-xs bg-slate-50 p-2.5 sm:p-3 rounded-lg border border-slate-200">
                <div>
                  <span className="text-slate-500 text-[10.5px]">Student:</span>
                  <div className="font-bold text-[#122A24] truncate">{viewInvoice.student_name}</div>
                </div>
                <div>
                  <span className="text-slate-500 text-[10.5px]">Class:</span>
                  <div className="font-bold text-[#122A24]">{viewInvoice.class_name}</div>
                </div>
                <div>
                  <span className="text-slate-500 text-[10.5px]">Admission No:</span>
                  <div className="font-mono font-bold text-[#122A24]">{viewInvoice.admission_no || 'N/A'}</div>
                </div>
                <div>
                  <span className="text-slate-500 text-[10.5px]">Mode:</span>
                  <div className="font-medium text-slate-700">{viewInvoice.payment_mode || 'Cash/UPI'}</div>
                </div>
              </div>

              <div className="border border-slate-300 rounded-lg overflow-hidden">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-100 font-mono text-[10px] sm:text-[10.5px] uppercase text-slate-600 border-b border-slate-300">
                    <tr>
                      <th className="py-2 px-3">Description</th>
                      <th className="py-2 px-3 text-right">Amount (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    <tr>
                      <td className="py-2 px-3">Tuition &amp; Instruction Fee</td>
                      <td className="py-2 px-3 text-right font-mono">₹{(viewInvoice.tuition_fee || viewInvoice.amount).toLocaleString()}</td>
                    </tr>
                    {Number(viewInvoice.transport_fee) > 0 && (
                      <tr>
                        <td className="py-2 px-3">Transport Charges</td>
                        <td className="py-2 px-3 text-right font-mono">₹{Number(viewInvoice.transport_fee).toLocaleString()}</td>
                      </tr>
                    )}
                    {Number(viewInvoice.exam_fee) > 0 && (
                      <tr>
                        <td className="py-2 px-3">Exam &amp; Lab Fund</td>
                        <td className="py-2 px-3 text-right font-mono">₹{Number(viewInvoice.exam_fee).toLocaleString()}</td>
                      </tr>
                    )}
                    <tr className="bg-slate-50 font-bold border-t-2 border-slate-800">
                      <td className="py-2 px-3 text-[#122A24]">TOTAL AMOUNT</td>
                      <td className="py-2 px-3 text-right text-sm sm:text-base text-[#122A24] font-mono">
                        ₹{viewInvoice.amount.toLocaleString()}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="flex justify-between items-end pt-2 text-xs">
                <div>
                  <div className={`inline-block px-2.5 py-0.5 rounded-md border-2 font-mono font-bold uppercase tracking-wider text-[11px] ${
                    viewInvoice.status === 'PAID'
                      ? 'border-emerald-700 text-emerald-800 bg-emerald-50'
                      : 'border-amber-600 text-amber-700 bg-amber-50'
                  }`}>
                    {viewInvoice.status === 'PAID' ? '✓ PAID' : '⏳ PENDING'}
                  </div>
                </div>

                <div className="text-center">
                  <div className="w-24 sm:w-32 border-b border-slate-400 mb-1" />
                  <span className="text-[9.5px] text-slate-500 font-mono">Accounts Stamp</span>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-2">
              <button
                onClick={() => handleToggleInvoiceStatus(viewInvoice)}
                className={`w-full sm:w-auto px-4 py-2.5 text-xs font-semibold rounded-full cursor-pointer border transition-colors ${
                  viewInvoice.status === 'PAID'
                    ? 'border-amber-300 bg-amber-50 text-amber-800 hover:bg-amber-100'
                    : 'border-[#C5E2CF] bg-[#EBF5EF] text-[#1C443A] hover:bg-[#D9EDE0]'
                }`}
              >
                {viewInvoice.status === 'PAID' ? 'Mark as Pending Dues' : '✓ Mark as PAID'}
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setViewInvoice(null)}
                  className="flex-1 sm:flex-none px-4 py-2.5 border border-[#DCE8E0] bg-[#F4F8F5] rounded-full text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex-1 sm:flex-none px-5 py-2.5 bg-[#122A24] hover:bg-[#1C443A] text-white text-xs font-semibold rounded-full flex items-center justify-center gap-1.5 shadow-xs cursor-pointer border-none"
                >
                  <Printer className="h-3.5 w-3.5" /> Print Receipt
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ISSUE NEW FEE INVOICE */}
      {showAddInvoice && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white rounded-t-3xl sm:rounded-3xl border border-[#DCE8E0] p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-2 border-b border-[#E8F0EA]">
              <div>
                <span className="font-mono text-[10px] text-[#2D5A4E] font-bold uppercase tracking-wider">Accounts Desk</span>
                <h2 className="font-display font-bold text-lg text-[#122A24] mt-0.5">Issue Fee Invoice</h2>
              </div>
              <button onClick={() => setShowAddInvoice(false)} className="p-1 text-slate-400 hover:text-slate-700 border-none bg-transparent cursor-pointer">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleAddInvoice} className="space-y-3.5 text-xs">
              {students.length > 0 && (
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Select Enrolled Student</label>
                  <select
                    onChange={(e) => {
                      const s = students.find(stu => stu.id === e.target.value);
                      if (s) {
                        setInvoiceForm({
                          ...invoiceForm,
                          student_id: s.id,
                          student_name: s.full_name,
                          admission_no: s.admission_no,
                          class_name: `${s.class_name} - ${s.section}`
                        });
                      }
                    }}
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl bg-white text-xs font-medium"
                  >
                    <option value="">-- Choose student to autofill --</option>
                    {students.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.full_name} ({s.admission_no} • {s.class_name} {s.section})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block font-semibold text-[#122A24] mb-1">Student Full Name *</label>
                <input
                  type="text"
                  required
                  value={invoiceForm.student_name}
                  onChange={(e) => setInvoiceForm({ ...invoiceForm, student_name: e.target.value })}
                  placeholder="e.g. Aarav Sharma"
                  className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Admission No</label>
                  <input
                    type="text"
                    value={invoiceForm.admission_no}
                    onChange={(e) => setInvoiceForm({ ...invoiceForm, admission_no: e.target.value })}
                    placeholder="e.g. ADM-0872"
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Class &amp; Section *</label>
                  <input
                    type="text"
                    required
                    value={invoiceForm.class_name}
                    onChange={(e) => setInvoiceForm({ ...invoiceForm, class_name: e.target.value })}
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="p-3.5 bg-[#F9FCFA] rounded-2xl border border-[#DCE8E0] space-y-2.5">
                <div className="font-semibold text-[#122A24] text-xs">Fee Head Breakdown (₹)</div>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[10.5px] text-[#2D5A4E] font-medium mb-0.5">Tuition</label>
                    <input
                      type="number"
                      value={invoiceForm.tuition_fee}
                      onChange={(e) => setInvoiceForm({ ...invoiceForm, tuition_fee: Number(e.target.value) })}
                      className="w-full px-2 py-1.5 border border-[#DCE8E0] rounded-lg font-mono text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10.5px] text-[#2D5A4E] font-medium mb-0.5">Transport</label>
                    <input
                      type="number"
                      value={invoiceForm.transport_fee}
                      onChange={(e) => setInvoiceForm({ ...invoiceForm, transport_fee: Number(e.target.value) })}
                      className="w-full px-2 py-1.5 border border-[#DCE8E0] rounded-lg font-mono text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10.5px] text-[#2D5A4E] font-medium mb-0.5">Exam/Lab</label>
                    <input
                      type="number"
                      value={invoiceForm.exam_fee}
                      onChange={(e) => setInvoiceForm({ ...invoiceForm, exam_fee: Number(e.target.value) })}
                      className="w-full px-2 py-1.5 border border-[#DCE8E0] rounded-lg font-mono text-xs bg-white"
                    />
                  </div>
                </div>
                <div className="text-right font-mono font-bold text-xs text-[#122A24] pt-1.5 border-t border-[#E8F0EA]">
                  Total Payable: ₹{(Number(invoiceForm.tuition_fee || 0) + Number(invoiceForm.transport_fee || 0) + Number(invoiceForm.exam_fee || 0)).toLocaleString()}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Due Date *</label>
                  <input
                    type="date"
                    required
                    value={invoiceForm.due_date}
                    onChange={(e) => setInvoiceForm({ ...invoiceForm, due_date: e.target.value })}
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl text-xs bg-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Status</label>
                  <select
                    value={invoiceForm.status}
                    onChange={(e) => setInvoiceForm({ ...invoiceForm, status: e.target.value as any })}
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl bg-white font-semibold text-xs"
                  >
                    <option value="PENDING">PENDING (Unpaid)</option>
                    <option value="PAID">PAID (Clear)</option>
                    <option value="OVERDUE">OVERDUE</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#E8F0EA]">
                <button
                  type="button"
                  onClick={() => setShowAddInvoice(false)}
                  className="px-4 py-2.5 border border-[#DCE8E0] rounded-full text-xs font-semibold text-slate-700 hover:bg-[#EBF5EF] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#122A24] hover:bg-[#1C443A] text-white font-semibold rounded-full cursor-pointer border-none shadow-xs text-xs"
                >
                  Generate Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD CLASS */}
      {showAddClass && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white rounded-t-3xl sm:rounded-3xl border border-[#DCE8E0] p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-2 border-b border-[#E8F0EA]">
              <div>
                <span className="font-mono text-[10px] text-[#2D5A4E] font-bold uppercase tracking-wider">Curriculum Setup</span>
                <h2 className="font-display font-bold text-lg text-[#122A24] mt-0.5">Create Class Division</h2>
              </div>
              <button onClick={() => setShowAddClass(false)} className="p-1 text-slate-400 hover:text-slate-700 border-none bg-transparent cursor-pointer">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleAddClass} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Class Level *</label>
                  <select
                    required
                    value={classForm.class_name || 'Class 10'}
                    onChange={(e) => setClassForm({ ...classForm, class_name: e.target.value })}
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl bg-white text-xs font-medium"
                  >
                    <optgroup label="Pre-Primary / Foundational">
                      <option value="Nursery">Nursery</option>
                      <option value="LKG">LKG / KG-I</option>
                      <option value="UKG">UKG / KG-II</option>
                    </optgroup>
                    <optgroup label="Primary (Classes 1 to 5)">
                      <option value="Class 1">Class 1</option>
                      <option value="Class 2">Class 2</option>
                      <option value="Class 3">Class 3</option>
                      <option value="Class 4">Class 4</option>
                      <option value="Class 5">Class 5</option>
                    </optgroup>
                    <optgroup label="Middle (Classes 6 to 8)">
                      <option value="Class 6">Class 6</option>
                      <option value="Class 7">Class 7</option>
                      <option value="Class 8">Class 8</option>
                    </optgroup>
                    <optgroup label="Secondary (Classes 9 & 10)">
                      <option value="Class 9">Class 9</option>
                      <option value="Class 10">Class 10</option>
                    </optgroup>
                    <optgroup label="Senior Secondary (Classes 11 & 12)">
                      <option value="Class 11">Class 11</option>
                      <option value="Class 12">Class 12</option>
                    </optgroup>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Section *</label>
                  <select
                    required
                    value={classForm.section || 'A'}
                    onChange={(e) => setClassForm({ ...classForm, section: e.target.value })}
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl bg-white text-xs font-medium font-mono"
                  >
                    <option value="A">Section A</option>
                    <option value="B">Section B</option>
                    <option value="C">Section C</option>
                    <option value="D">Section D</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#122A24] mb-1">Class Teacher</label>
                <select
                  value={classForm.class_teacher || ''}
                  onChange={(e) => setClassForm({ ...classForm, class_teacher: e.target.value })}
                  className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl bg-white text-xs font-medium text-[#122A24] cursor-pointer"
                >
                  <option value="">-- Select Class Teacher from Faculty Roster --</option>
                  {teachers && teachers.length > 0 ? (
                    teachers
                      .filter(t => t.status !== 'INACTIVE')
                      .sort((a, b) => (a.full_name || '').localeCompare(b.full_name || ''))
                      .map((t) => (
                        <option key={t.id} value={t.full_name}>
                          {t.full_name} ({t.designation || 'Faculty'} — {t.department || t.subject_specialization || 'General'})
                        </option>
                      ))
                  ) : (
                    <option value="" disabled>No registered faculty available</option>
                  )}
                  {classForm.class_teacher && !teachers.some(t => t.full_name === classForm.class_teacher) && (
                    <option value={classForm.class_teacher}>{classForm.class_teacher} (Assigned)</option>
                  )}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Room No</label>
                  <input
                    type="text"
                    value={classForm.room_no}
                    onChange={(e) => setClassForm({ ...classForm, room_no: e.target.value })}
                    placeholder="e.g. Room 204"
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Student Capacity</label>
                  <input
                    type="number"
                    value={classForm.capacity}
                    onChange={(e) => setClassForm({ ...classForm, capacity: Number(e.target.value) })}
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#E8F0EA]">
                <button
                  type="button"
                  onClick={() => setShowAddClass(false)}
                  className="px-4 py-2.5 border border-[#DCE8E0] rounded-full text-xs font-semibold text-slate-700 hover:bg-[#EBF5EF] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#122A24] hover:bg-[#1C443A] text-white font-semibold rounded-full cursor-pointer border-none shadow-xs text-xs"
                >
                  Save Class
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD NOTICE */}
      {showAddNotice && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white rounded-t-3xl sm:rounded-3xl border border-[#DCE8E0] p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-2 border-b border-[#E8F0EA]">
              <div>
                <span className="font-mono text-[10px] text-[#2D5A4E] font-bold uppercase tracking-wider">Notice Board</span>
                <h2 className="font-display font-bold text-lg text-[#122A24] mt-0.5">Publish Circular</h2>
              </div>
              <button onClick={() => setShowAddNotice(false)} className="p-1 text-slate-400 hover:text-slate-700 border-none bg-transparent cursor-pointer">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleAddNotice} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-[#122A24] mb-1">Notice Title *</label>
                <input
                  type="text"
                  required
                  value={noticeForm.title}
                  onChange={(e) => setNoticeForm({ ...noticeForm, title: e.target.value })}
                  placeholder="e.g. Annual Sports Meet 2026-27"
                  className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl text-xs font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Target Audience</label>
                  <select
                    value={noticeForm.target_audience}
                    onChange={(e) => setNoticeForm({ ...noticeForm, target_audience: e.target.value as any })}
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl bg-white font-medium text-xs"
                  >
                    <option value="ALL">All (Everyone)</option>
                    <option value="TEACHERS">Teachers &amp; Staff</option>
                    <option value="PARENTS">Parents</option>
                    <option value="STUDENTS">Students</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Posted By</label>
                  <input
                    type="text"
                    value={noticeForm.posted_by}
                    onChange={(e) => setNoticeForm({ ...noticeForm, posted_by: e.target.value })}
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#122A24] mb-1">Notice Content *</label>
                <textarea
                  required
                  value={noticeForm.content}
                  onChange={(e) => setNoticeForm({ ...noticeForm, content: e.target.value })}
                  placeholder="Write the circular or announcement details..."
                  className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl min-h-[90px] resize-y text-xs font-sans"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#E8F0EA]">
                <button
                  type="button"
                  onClick={() => setShowAddNotice(false)}
                  className="px-4 py-2.5 border border-[#DCE8E0] rounded-full text-xs font-semibold text-slate-700 hover:bg-[#EBF5EF] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#122A24] hover:bg-[#1C443A] text-white font-semibold rounded-full cursor-pointer border-none shadow-xs text-xs"
                >
                  Publish Circular
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CUSTOMIZE USER PROFILE */}
      {showProfileModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white rounded-t-3xl sm:rounded-3xl border border-[#DCE8E0] p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-2 border-b border-[#E8F0EA]">
              <div>
                <span className="font-mono text-[10px] text-[#2D5A4E] font-bold uppercase tracking-wider">Account Credentials</span>
                <h2 className="font-display font-bold text-lg text-[#122A24] mt-0.5">Customize Profile</h2>
              </div>
              <button onClick={() => setShowProfileModal(false)} className="p-1 text-slate-400 hover:text-slate-700 border-none bg-transparent cursor-pointer">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-[#122A24] mb-1">Display Name (Principal / Administrator)</label>
                <input
                  type="text"
                  required
                  value={profileForm.full_name}
                  onChange={(e) => setProfileForm({ ...profileForm, full_name: e.target.value })}
                  placeholder="e.g. Dr. Rajesh Sharma"
                  className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Admin Username / ID</label>
                  <input
                    type="text"
                    required
                    value={profileForm.username}
                    onChange={(e) => setProfileForm({ ...profileForm, username: e.target.value })}
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Security PIN / Password</label>
                  <input
                    type="text"
                    required
                    value={profileForm.admin_pin}
                    onChange={(e) => setProfileForm({ ...profileForm, admin_pin: e.target.value })}
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Email Address</label>
                  <input
                    type="email"
                    value={profileForm.email}
                    onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
                    placeholder="admin@school.edu"
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={profileForm.phone}
                    onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                    placeholder="+91 98..."
                    className="w-full px-3 py-2.5 border border-[#DCE8E0] rounded-xl"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#E8F0EA]">
                <button
                  type="button"
                  onClick={() => setShowProfileModal(false)}
                  className="px-4 py-2.5 border border-[#DCE8E0] rounded-full text-xs font-semibold text-slate-700 hover:bg-[#EBF5EF] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#122A24] hover:bg-[#1C443A] text-white font-semibold rounded-full cursor-pointer border-none shadow-xs text-xs"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CBSE STUDENT PROMOTION & GRADUATION STUDIO */}
      {showPromotionStudio && (() => {
        const targetStudents = students.filter(s => {
          const clsMatch = s.class_name?.toLowerCase().replace(/^class\s*/i, '').trim() === promotionSourceClass.toLowerCase().replace(/^class\s*/i, '').trim() || s.class_name?.toLowerCase() === promotionSourceClass.toLowerCase();
          const secMatch = promotionSourceSection === 'ALL' || (s.section || 'A').toUpperCase() === promotionSourceSection.toUpperCase();
          return clsMatch && secMatch;
        });

        let promoteCount = 0;
        let retainCount = 0;
        let graduateCount = 0;
        let leftCount = 0;

        targetStudents.forEach(s => {
          const cfg = promotionActionsMap[s.id] || {
            action: promotionSourceClass === 'Class 12' ? 'GRADUATE' : 'PROMOTE',
            targetSection: promotionTargetSection === 'SAME' ? (s.section || 'A') : promotionTargetSection
          };
          if (cfg.action === 'PROMOTE') promoteCount++;
          else if (cfg.action === 'RETAIN') retainCount++;
          else if (cfg.action === 'GRADUATE') graduateCount++;
          else if (cfg.action === 'LEFT') leftCount++;
        });

        const isClass12 = promotionSourceClass === 'Class 12';

        return (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
            <div className="bg-white rounded-3xl border border-[#DCE8E0] p-5 sm:p-7 max-w-5xl w-full shadow-2xl space-y-5 max-h-[94vh] overflow-y-auto animate-fade-in flex flex-col">
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E8F0EA]">
                <div>
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span className="w-8 h-8 rounded-full bg-[#EBF5EF] text-[#122A24] flex items-center justify-center font-bold text-sm border border-[#C5E2CF]">
                      🎓
                    </span>
                    <h2 className="font-display font-bold text-xl sm:text-2xl text-[#122A24] tracking-tight">
                      CBSE Student Promotion &amp; Graduation Studio
                    </h2>
                    <span className="px-2.5 py-0.5 rounded-full text-[10.5px] font-mono font-bold bg-[#122A24] text-white">
                      Session Transition Studio
                    </span>
                  </div>
                  <p className="text-xs text-[#2D5A4E] mt-1">
                    Bulk promote scholars into higher CBSE grades, retain students, or graduate Class 12 batches into Alumni.
                  </p>
                </div>
                <button
                  onClick={() => setShowPromotionStudio(false)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 border-none bg-transparent cursor-pointer self-end sm:self-auto"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Step 1: Promotion Configuration Controls */}
              <div className="bg-[#F9FCFA] rounded-2xl border border-[#DCE8E0] p-4 space-y-3.5">
                <div className="font-mono text-[11px] font-bold text-[#1C443A] uppercase tracking-wider flex items-center gap-1.5">
                  <span>1. Configure Academic Progression Pipeline</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                  {/* Source Class */}
                  <div>
                    <label className="block font-semibold text-[#122A24] mb-1">Source Current Class</label>
                    <select
                      value={promotionSourceClass}
                      onChange={(e) => {
                        const nextSrc = e.target.value;
                        setPromotionSourceClass(nextSrc);
                        const autoNext = NEXT_CLASS_MAP[nextSrc] || 'Class 10';
                        setPromotionTargetClass(autoNext);
                        setPromotionActionsMap({});
                      }}
                      className="w-full px-3 py-2 bg-white border border-[#DCE8E0] rounded-xl font-medium text-[#122A24] focus:outline-none focus:border-[#10B981]"
                    >
                      <optgroup label="Pre-Primary">
                        <option value="Nursery">Nursery</option>
                        <option value="LKG">LKG</option>
                        <option value="UKG">UKG</option>
                      </optgroup>
                      <optgroup label="Primary (1-5)">
                        <option value="Class 1">Class 1</option>
                        <option value="Class 2">Class 2</option>
                        <option value="Class 3">Class 3</option>
                        <option value="Class 4">Class 4</option>
                        <option value="Class 5">Class 5</option>
                      </optgroup>
                      <optgroup label="Middle & Secondary (6-10)">
                        <option value="Class 6">Class 6</option>
                        <option value="Class 7">Class 7</option>
                        <option value="Class 8">Class 8</option>
                        <option value="Class 9">Class 9</option>
                        <option value="Class 10">Class 10</option>
                      </optgroup>
                      <optgroup label="Senior Secondary (11-12)">
                        <option value="Class 11">Class 11</option>
                        <option value="Class 12">Class 12 (Graduation Batch)</option>
                      </optgroup>
                    </select>
                  </div>

                  {/* Source Section */}
                  <div>
                    <label className="block font-semibold text-[#122A24] mb-1">Source Section</label>
                    <select
                      value={promotionSourceSection}
                      onChange={(e) => {
                        setPromotionSourceSection(e.target.value);
                        setPromotionActionsMap({});
                      }}
                      className="w-full px-3 py-2 bg-white border border-[#DCE8E0] rounded-xl font-medium text-[#122A24] focus:outline-none focus:border-[#10B981]"
                    >
                      <option value="ALL">All Sections (A, B, C, D)</option>
                      <option value="A">Section A Only</option>
                      <option value="B">Section B Only</option>
                      <option value="C">Section C Only</option>
                      <option value="D">Section D Only</option>
                    </select>
                  </div>

                  {/* Target Class */}
                  <div>
                    <label className="block font-semibold text-[#122A24] mb-1">
                      {isClass12 ? 'Target Status' : 'Target Next Class'}
                    </label>
                    {isClass12 ? (
                      <div className="w-full px-3 py-2 bg-emerald-50 border border-emerald-200 rounded-xl font-bold text-emerald-800 flex items-center gap-1.5">
                        <span>🎓 Graduated / Alumni</span>
                      </div>
                    ) : (
                      <select
                        value={promotionTargetClass}
                        onChange={(e) => setPromotionTargetClass(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-[#DCE8E0] rounded-xl font-medium text-[#122A24] focus:outline-none focus:border-[#10B981]"
                      >
                        <option value="LKG">LKG</option>
                        <option value="UKG">UKG</option>
                        {Array.from({ length: 12 }, (_, i) => i + 1).map(num => (
                          <option key={num} value={`Class ${num}`}>{`Class ${num}`}</option>
                        ))}
                      </select>
                    )}
                  </div>

                  {/* Target Academic Session */}
                  <div>
                    <label className="block font-semibold text-[#122A24] mb-1">Next Session</label>
                    <select
                      value={promotionTargetSession}
                      onChange={(e) => setPromotionTargetSession(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#DCE8E0] rounded-xl font-mono text-[#122A24] focus:outline-none focus:border-[#10B981]"
                    >
                      <option value="2027-28">Session 2027-28 (Next)</option>
                      <option value="2026-27">Session 2026-27 (Current)</option>
                    </select>
                  </div>
                </div>

                {/* Batch Action Helpers */}
                <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#E8F0EA] flex-wrap">
                  <span className="text-[11px] text-[#2D5A4E] font-medium">
                    Scholars to process: <strong className="text-[#122A24]">{targetStudents.length}</strong>
                  </span>
                  <div className="flex items-center gap-2 flex-wrap">
                    {!isClass12 ? (
                      <button
                        onClick={() => handleSetAllPromotionAction('PROMOTE')}
                        className="px-3 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-full text-xs font-semibold cursor-pointer transition-colors shadow-2xs"
                      >
                        ✓ Set All: Promote to {promotionTargetClass}
                      </button>
                    ) : (
                      <button
                        onClick={() => handleSetAllPromotionAction('GRADUATE')}
                        className="px-3 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-full text-xs font-semibold cursor-pointer transition-colors shadow-2xs"
                      >
                        🎓 Set All: Graduate as Alumni
                      </button>
                    )}
                    <button
                      onClick={() => handleSetAllPromotionAction('RETAIN')}
                      className="px-3 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-full text-xs font-semibold cursor-pointer transition-colors shadow-2xs"
                    >
                      🟡 Set All: Retain / Repeat
                    </button>
                  </div>
                </div>
              </div>

              {/* Step 2: Interactive Student Roster & Action Allocation Table */}
              <div className="rounded-2xl border border-[#DCE8E0] overflow-hidden bg-white shadow-2xs">
                <div className="p-3 bg-[#F3F7F5] border-b border-[#DCE8E0] font-mono text-[11px] font-bold text-[#1C443A] uppercase tracking-wider flex justify-between items-center">
                  <span>2. Review Scholar Status &amp; Individual Promotion Decisions</span>
                  <span>{targetStudents.length} Students</span>
                </div>

                <div className="overflow-x-auto max-h-[380px] overflow-y-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="sticky top-0 z-10 bg-[#F9FCFA] font-mono text-[10.5px] font-bold text-[#2D5A4E] uppercase border-b border-[#E8F0EA]">
                      <tr>
                        <th className="py-2 px-3 w-12">Roll</th>
                        <th className="py-2 px-3">Adm No</th>
                        <th className="py-2 px-3">Scholar Name</th>
                        <th className="py-2 px-3 text-center">Term Rec</th>
                        <th className="py-2 px-3 text-center">Fee Clearance</th>
                        <th className="py-2 px-3">Promotion Decision</th>
                        <th className="py-2 px-3 text-center">Target Sec</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#EBF2ED]">
                      {targetStudents.map((s, idx) => {
                        const cfg = promotionActionsMap[s.id] || {
                          action: isClass12 ? 'GRADUATE' : 'PROMOTE',
                          targetSection: promotionTargetSection === 'SAME' ? (s.section || 'A') : promotionTargetSection
                        };
                        const initials = (s.full_name || 'Scholar').split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();

                        return (
                          <tr key={s.id} className="hover:bg-[#F9FCFA] transition-colors">
                            <td className="py-2.5 px-3 font-mono font-bold text-[#122A24]">
                              #{s.roll_no || (idx + 1).toString().padStart(2, '0')}
                            </td>
                            <td className="py-2.5 px-3 font-mono text-[#2D5A4E]">
                              {s.admission_no}
                            </td>
                            <td className="py-2.5 px-3">
                              <div className="flex items-center gap-2">
                                <div className="w-6 h-6 rounded-full bg-[#EBF5EF] text-[#122A24] font-bold text-[9px] flex items-center justify-center border border-[#C5E2CF]">
                                  {initials}
                                </div>
                                <div className="font-semibold text-[#122A24]">{s.full_name}</div>
                              </div>
                            </td>
                            <td className="py-2.5 px-3 text-center font-mono">
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#EBF5EF] text-[#1C443A]">
                                {s.attendance_percent || 95}%
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-center font-mono">
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                s.fee_status === 'PAID'
                                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                  : 'bg-amber-50 text-amber-800 border border-amber-200'
                              }`}>
                                {s.fee_status || 'PAID'}
                              </span>
                            </td>
                            <td className="py-2.5 px-3">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                {!isClass12 ? (
                                  <button
                                    onClick={() => setPromotionActionsMap(prev => ({
                                      ...prev,
                                      [s.id]: { ...cfg, action: 'PROMOTE' }
                                    }))}
                                    className={`px-2 py-0.5 rounded-full text-[10.5px] font-mono font-bold border cursor-pointer transition-all ${
                                      cfg.action === 'PROMOTE'
                                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                                        : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50'
                                    }`}
                                  >
                                    Promote
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => setPromotionActionsMap(prev => ({
                                      ...prev,
                                      [s.id]: { ...cfg, action: 'GRADUATE' }
                                    }))}
                                    className={`px-2 py-0.5 rounded-full text-[10.5px] font-mono font-bold border cursor-pointer transition-all ${
                                      cfg.action === 'GRADUATE'
                                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                                        : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50'
                                    }`}
                                  >
                                    Graduate
                                  </button>
                                )}
                                <button
                                  onClick={() => setPromotionActionsMap(prev => ({
                                    ...prev,
                                    [s.id]: { ...cfg, action: 'RETAIN' }
                                  }))}
                                  className={`px-2 py-0.5 rounded-full text-[10.5px] font-mono font-bold border cursor-pointer transition-all ${
                                    cfg.action === 'RETAIN'
                                      ? 'bg-amber-500 text-white border-amber-500 shadow-xs'
                                      : 'bg-white text-amber-700 border-amber-200 hover:bg-amber-50'
                                  }`}
                                >
                                  Retain
                                </button>
                                <button
                                  onClick={() => setPromotionActionsMap(prev => ({
                                    ...prev,
                                    [s.id]: { ...cfg, action: 'LEFT' }
                                  }))}
                                  className={`px-2 py-0.5 rounded-full text-[10.5px] font-mono font-bold border cursor-pointer transition-all ${
                                    cfg.action === 'LEFT'
                                      ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                                      : 'bg-white text-rose-700 border-rose-200 hover:bg-rose-50'
                                  }`}
                                >
                                  TC/Left
                                </button>
                              </div>
                            </td>
                            <td className="py-2.5 px-3 text-center">
                              <select
                                value={cfg.targetSection || s.section || 'A'}
                                onChange={(e) => setPromotionActionsMap(prev => ({
                                  ...prev,
                                  [s.id]: { ...cfg, targetSection: e.target.value }
                                }))}
                                className="px-2 py-0.5 bg-white border border-[#DCE8E0] rounded-lg text-xs font-semibold text-[#122A24]"
                              >
                                <option value="A">Sec A</option>
                                <option value="B">Sec B</option>
                                <option value="C">Sec C</option>
                                <option value="D">Sec D</option>
                              </select>
                            </td>
                          </tr>
                        );
                      })}
                      {targetStudents.length === 0 && (
                        <tr>
                          <td colSpan={7} className="py-12 text-center text-xs font-mono text-[#2D5A4E]">
                            No students found enrolled in {promotionSourceClass} (Section {promotionSourceSection}). Select another class.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Step 3: Impact Summary & Execution Footer */}
              <div className="bg-[#EBF5EF] p-4 rounded-2xl border border-[#C5E2CF] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3 flex-wrap text-xs font-mono font-bold text-[#1C443A]">
                  <span className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-[#C5E2CF]">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    {promoteCount} Promoted to {promotionTargetClass}
                  </span>
                  <span className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-[#C5E2CF]">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    {retainCount} Retained in {promotionSourceClass}
                  </span>
                  {graduateCount > 0 && (
                    <span className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-[#C5E2CF]">
                      <span className="w-2 h-2 rounded-full bg-indigo-500" />
                      {graduateCount} Graduated (Alumni)
                    </span>
                  )}
                  {leftCount > 0 && (
                    <span className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-[#C5E2CF]">
                      <span className="w-2 h-2 rounded-full bg-rose-500" />
                      {leftCount} TC Issued
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <button
                    type="button"
                    onClick={() => setShowPromotionStudio(false)}
                    className="px-4 py-2 border border-[#DCE8E0] rounded-full text-xs font-semibold text-slate-700 hover:bg-white cursor-pointer bg-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleExecutePromotion}
                    disabled={promotionExecuting || targetStudents.length === 0}
                    className="px-5 py-2 bg-[#122A24] hover:bg-[#1C443A] text-white font-semibold rounded-full cursor-pointer border-none shadow-xs text-xs flex items-center gap-2 disabled:opacity-60"
                  >
                    <GraduationCap className="h-4 w-4" />
                    <span>{promotionExecuting ? 'Executing Promotion...' : 'Execute Promotion & Sync'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* MODAL: INDIVIDUAL STUDENT PROMOTION & ACADEMIC TRANSITION */}
      {individualPromotionStudent && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl border border-[#DCE8E0] p-6 sm:p-7 max-w-lg w-full shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto animate-fade-in">
            {/* Header */}
            <div className="flex justify-between items-center pb-2 border-b border-[#E8F0EA]">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-full bg-[#EBF5EF] text-[#122A24] flex items-center justify-center font-bold text-sm border border-[#C5E2CF]">
                  🎓
                </span>
                <div>
                  <span className="font-mono text-[10px] text-emerald-700 font-bold uppercase tracking-wider">
                    Individual Scholar Promotion
                  </span>
                  <h2 className="font-display font-bold text-lg text-[#122A24]">
                    {individualPromotionStudent.full_name}
                  </h2>
                </div>
              </div>
              <button
                onClick={() => setIndividualPromotionStudent(null)}
                className="p-1 text-slate-400 hover:text-slate-700 border-none bg-transparent cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Current Academic Snapshot */}
            <div className="p-3.5 bg-[#F9FCFA] rounded-2xl border border-[#DCE8E0] grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div>
                <span className="text-[10px] text-[#2D5A4E] font-mono block">Admission No</span>
                <span className="font-bold font-mono text-[#122A24]">{individualPromotionStudent.admission_no}</span>
              </div>
              <div>
                <span className="text-[10px] text-[#2D5A4E] font-mono block">Current Class</span>
                <span className="font-bold text-[#122A24]">{individualPromotionStudent.class_name} ({individualPromotionStudent.section || 'A'})</span>
              </div>
              <div>
                <span className="text-[10px] text-[#2D5A4E] font-mono block">Attendance</span>
                <span className="font-bold font-mono text-emerald-700">{individualPromotionStudent.attendance_percent || 95}%</span>
              </div>
              <div>
                <span className="text-[10px] text-[#2D5A4E] font-mono block">Fee Clearance</span>
                <span className="font-bold font-mono text-emerald-700">{individualPromotionStudent.fee_status || 'PAID'}</span>
              </div>
            </div>

            <form onSubmit={handleExecuteIndividualPromotion} className="space-y-4 text-xs">
              {/* Decision Action Pills */}
              <div>
                <label className="block font-semibold text-[#122A24] mb-1.5">Promotion Decision *</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setIndividualPromotionAction('PROMOTE')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      individualPromotionAction === 'PROMOTE'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-white text-emerald-800 border-emerald-200 hover:bg-emerald-50'
                    }`}
                  >
                    <span>🟢 Promote to Next Class</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIndividualPromotionAction('RETAIN')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      individualPromotionAction === 'RETAIN'
                        ? 'bg-amber-500 text-white border-amber-500 shadow-xs'
                        : 'bg-white text-amber-800 border-amber-200 hover:bg-amber-50'
                    }`}
                  >
                    <span>🟡 Retain in Same Class</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIndividualPromotionAction('GRADUATE')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      individualPromotionAction === 'GRADUATE'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-white text-indigo-800 border-indigo-200 hover:bg-indigo-50'
                    }`}
                  >
                    <span>🎓 Graduate (Alumni)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIndividualPromotionAction('LEFT')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      individualPromotionAction === 'LEFT'
                        ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                        : 'bg-white text-rose-800 border-rose-200 hover:bg-rose-50'
                    }`}
                  >
                    <span>🔴 TC Issued / Left</span>
                  </button>
                </div>
              </div>

              {/* Target Class & Section Configuration */}
              {individualPromotionAction === 'PROMOTE' && (
                <div className="grid grid-cols-2 gap-3 p-3.5 bg-[#F9FCFA] rounded-2xl border border-[#DCE8E0]">
                  <div>
                    <label className="block font-semibold text-[#122A24] mb-1">Target Class *</label>
                    <select
                      value={individualTargetClass}
                      onChange={(e) => setIndividualTargetClass(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#DCE8E0] rounded-xl font-medium text-[#122A24]"
                    >
                      <option value="LKG">LKG</option>
                      <option value="UKG">UKG</option>
                      {Array.from({ length: 12 }, (_, i) => i + 1).map(num => (
                        <option key={num} value={`Class ${num}`}>{`Class ${num}`}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[#122A24] mb-1">Target Section *</label>
                    <select
                      value={individualTargetSection}
                      onChange={(e) => setIndividualTargetSection(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#DCE8E0] rounded-xl font-medium text-[#122A24]"
                    >
                      <option value="A">Section A</option>
                      <option value="B">Section B</option>
                      <option value="C">Section C</option>
                      <option value="D">Section D</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Next Academic Session & Roll Number */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Target Academic Session</label>
                  <select
                    value={individualTargetSession}
                    onChange={(e) => setIndividualTargetSession(e.target.value)}
                    className="w-full px-3 py-2 border border-[#DCE8E0] rounded-xl font-mono text-[#122A24]"
                  >
                    <option value="2027-28">Session 2027-28</option>
                    <option value="2026-27">Session 2026-27</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-[#122A24] mb-1">Target Roll No (Optional)</label>
                  <input
                    type="text"
                    value={individualTargetRoll}
                    onChange={(e) => setIndividualTargetRoll(e.target.value)}
                    placeholder="e.g. 01"
                    className="w-full px-3 py-2 border border-[#DCE8E0] rounded-xl font-mono text-[#122A24]"
                  />
                </div>
              </div>

              {/* Modal Footer */}
              <div className="flex justify-end gap-2 pt-3 border-t border-[#E8F0EA]">
                <button
                  type="button"
                  onClick={() => setIndividualPromotionStudent(null)}
                  className="px-4 py-2 border border-[#DCE8E0] rounded-full text-xs font-semibold text-slate-700 hover:bg-[#EBF5EF] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={promotionExecuting}
                  className="px-5 py-2 bg-[#122A24] hover:bg-[#1C443A] text-white font-semibold rounded-full cursor-pointer border-none shadow-xs text-xs flex items-center gap-1.5 disabled:opacity-60"
                >
                  <GraduationCap className="h-4 w-4" />
                  <span>{promotionExecuting ? 'Updating Scholar...' : 'Execute Scholar Promotion'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: RESET LOGIN PIN (ADMIN POWER) */}
      {pinModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white rounded-t-3xl sm:rounded-3xl border border-[#DCE8E0] p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto animate-fade-in">
            <div className="flex justify-between items-center pb-2 border-b border-[#E8F0EA]">
              <div>
                <span className="font-mono text-[10px] text-emerald-700 font-bold uppercase tracking-wider">
                  Admin Authority • PIN Management
                </span>
                <h2 className="font-display font-bold text-lg text-[#122A24] mt-0.5">
                  Reset Login PIN
                </h2>
              </div>
              <button onClick={() => setPinModal(null)} className="p-1 text-slate-400 hover:text-slate-700 border-none bg-transparent cursor-pointer">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="p-3.5 bg-[#EBF5EF] rounded-2xl border border-[#C5E2CF] text-xs text-[#122A24]">
              <div className="font-bold text-sm text-[#122A24]">{pinModal.name}</div>
              <div className="text-[11px] font-mono text-[#2D5A4E] mt-0.5">
                Role: {pinModal.type === 'student' ? 'Student SIS Account' : 'Faculty Staff Account'}
              </div>
            </div>

            <form onSubmit={handleSaveCustomPin} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-[#122A24] mb-1">
                  New 6-Digit Passcode / Security PIN *
                </label>
                <input
                  type="text"
                  required
                  value={customPinInput}
                  onChange={(e) => setCustomPinInput(e.target.value)}
                  placeholder="e.g. 123456"
                  className="w-full px-3.5 py-2.5 border border-[#DCE8E0] rounded-xl font-mono text-sm font-bold text-[#122A24] tracking-widest text-center"
                />
                <span className="text-[10.5px] text-[#2D5A4E] mt-1 block">
                  Admin can set any 4-6 digit passcode for instant login access.
                </span>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-[#E8F0EA]">
                <button
                  type="button"
                  onClick={() => setPinModal(null)}
                  className="px-4 py-2 border border-[#DCE8E0] rounded-full text-xs font-semibold text-slate-700 hover:bg-[#EBF5EF] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#122A24] hover:bg-[#1C443A] text-white font-semibold rounded-full cursor-pointer border-none shadow-xs text-xs"
                >
                  Update PIN in Database
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* FLOATING ADMIN ACTION TOAST NOTIFICATION */}
      {actionSuccessMsg && (
        <div className="fixed top-6 right-6 z-50 bg-[#122A24] text-white px-5 py-3 rounded-2xl shadow-2xl border border-emerald-500/40 flex items-center gap-3 animate-fade-in">
          <div className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs border border-emerald-400/40">
            ⚡
          </div>
          <div>
            <div className="font-semibold text-xs text-white">Admin Power Action</div>
            <div className="text-[11px] text-emerald-300 font-medium">{actionSuccessMsg}</div>
          </div>
          <button
            onClick={() => setActionSuccessMsg('')}
            className="text-slate-400 hover:text-white border-none bg-transparent cursor-pointer ml-2 p-1"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
}

export default function ERPWorkspacePage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#122A24] text-white flex items-center justify-center font-mono">Loading Workspace...</div>}>
      <ERPWorkspaceContent />
    </Suspense>
  );
}
